#!/usr/bin/env python3
# powershell -NoProfile -Command "Get-CimInstance Win32_VideoController | Select-Object Name, AdapterRAM"
"""
StreamForge — Ultra-low-latency WebRTC Streaming Server
Target  : Windows 10 / 11 exclusively
Modes   : screen | window | webcam | both (PiP) | audio_only

INSTALL : pip install aiohttp gstreamer-bundle
RUN     : python server.py
          python server.py --port 9090
          python server.py --stun stun://custom:3478
"""

import asyncio
import ctypes
from ctypes import wintypes
import json
import logging
import os
import platform
import sys
import threading
import traceback

try:
    import gi
    gi.require_version('Gst',       '1.0')
    gi.require_version('GstWebRTC', '1.0')
    gi.require_version('GstSdp',    '1.0')
    from gi.repository import Gst, GstWebRTC, GstSdp, GLib
except Exception as e:
    print(f"\n[FATAL] GStreamer bindings introuvables : {e}")
    print("  pip install gstreamer-bundle")
    sys.exit(1)

try:
    from aiohttp import web
    import aiohttp
except ImportError:
    print("\n[FATAL] aiohttp manquant — pip install aiohttp")
    sys.exit(1)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s  %(levelname)-8s  %(message)s',
    datefmt='%H:%M:%S',
)
log = logging.getLogger('streamforge')

Gst.init(None)

# ─── Configuration ────────────────────────────────────────────────────────────

HOST         = '127.0.0.1'
PORT         = 8080
STUN_SERVER  = os.environ.get('STUN_SERVER', 'stun://stun.l.google.com:19302')
TURN_SERVER  = os.environ.get('TURN_SERVER', '')
VIDEO_DEVICE = os.environ.get('VIDEO_DEVICE', '0')
AUDIO_DEVICE = os.environ.get('AUDIO_DEVICE', '')

_GLIB_LOOP   = GLib.MainLoop()
_GLIB_THREAD = threading.Thread(target=_GLIB_LOOP.run, daemon=True, name='glib')
_GLIB_THREAD.start()

html_page = r"""<!doctype html>
<html lang="en" data-theme="dark">
  <head>
    <meta charset="UTF-8" />
    <meta
      name="viewport"
      content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"
    />
    <title>StreamForge</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&family=Space+Grotesk:wght@500;600;700&display=swap"
    />
    <style>
      /* ══════════════════════════════════════════════════
   DESIGN TOKENS
══════════════════════════════════════════════════ */
      :root {
        --font-ui: 'Outfit', sans-serif;
        --font-mono: 'DM Mono', ui-monospace, monospace;
        --font-display: 'Space Grotesk', sans-serif;

        --hdr: 52px;
        --status-h: 28px;
        --panel-w: 320px;
        --r: 8px;
        --r-sm: 5px;
        --r-lg: 12px;

        --ease: cubic-bezier(0.22, 1, 0.36, 1);
        --fast: 0.12s;
        --med: 0.22s;
        --slow: 0.38s;

        /* Accent always the same */
        --accent: #00d4a8;
        --accent-dim: rgba(0, 212, 168, 0.1);
        --accent-mid: rgba(0, 212, 168, 0.2);
        --accent-glow: rgba(0, 212, 168, 0.35);
        --green: #22c55e;
        --green-dim: rgba(34, 197, 94, 0.1);
        --red: #f43f5e;
        --red-dim: rgba(244, 63, 94, 0.1);
        --amber: #f59e0b;
        --amber-dim: rgba(245, 158, 11, 0.1);
        --blue: #3b82f6;
        --blue-dim: rgba(59, 130, 246, 0.1);
      }

      /* ── DARK THEME ──────────────────────────────────── */
      [data-theme='dark'] {
        --bg0: #080b10;
        --bg1: #0d1117;
        --bg2: #111520;
        --bg3: #161c2a;
        --bg4: #1d2535;
        --bg5: #232d42;
        --line0: rgba(255, 255, 255, 0.04);
        --line1: rgba(255, 255, 255, 0.07);
        --line2: rgba(255, 255, 255, 0.12);
        --t0: #e8eef8;
        --t1: #9eafc4;
        --t2: #5a6e85;
        --t3: #2e3f55;
        --shadow: 0 2px 16px rgba(0, 0, 0, 0.5);
        --shadow-lg: 0 8px 40px rgba(0, 0, 0, 0.7);
        --input-bg: rgba(255, 255, 255, 0.04);
      }

      /* ── LIGHT THEME ─────────────────────────────────── */
      [data-theme='light'] {
        --bg0: #f0f2f6;
        --bg1: #ffffff;
        --bg2: #f8f9fb;
        --bg3: #eef0f5;
        --bg4: #e4e7ef;
        --bg5: #d8dce8;
        --line0: rgba(0, 0, 0, 0.05);
        --line1: rgba(0, 0, 0, 0.08);
        --line2: rgba(0, 0, 0, 0.13);
        --t0: #1a2130;
        --t1: #465470;
        --t2: #8090a8;
        --t3: #bbc5d5;
        --shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
        --shadow-lg: 0 8px 32px rgba(0, 0, 0, 0.14);
        --input-bg: rgba(0, 0, 0, 0.03);
      }

      /* ── RESET ───────────────────────────────────────── */
      *,
      *::before,
      *::after {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }
      html,
      body {
        width: 100%;
        height: 100%;
        background: var(--bg0);
        color: var(--t1);
        font-family: var(--font-ui);
        font-size: 12px;
        overflow: hidden;
        -webkit-font-smoothing: antialiased;
      }
      button {
        cursor: pointer;
        border: none;
        background: none;
        font-family: var(--font-ui);
      }
      input,
      select,
      textarea {
        font-family: var(--font-ui);
        outline: none;
      }
      select {
        appearance: none;
      }
      a {
        color: inherit;
        text-decoration: none;
      }
      ::-webkit-scrollbar {
        width: 3px;
        height: 3px;
      }
      ::-webkit-scrollbar-thumb {
        background: var(--t3);
        border-radius: 2px;
      }
      ::-webkit-scrollbar-track {
        background: transparent;
      }

      /* ── LAYOUT ──────────────────────────────────────── */
      #app {
        display: grid;
        height: 100dvh;
        grid-template:
          'hdr' var(--hdr) 'stage' 1fr 'statusbar' var(--status-h)
          / 1fr;
        overflow: hidden;
        transition: grid-template-columns var(--med) var(--ease);
      }
      #app.panel-open {
        grid-template:
          'hdr hdr' var(--hdr)
          'stage panel' 1fr 'statusbar statusbar' var(--status-h) / 1fr var(
            --panel-w
          );
      }

      /* ── HEADER ──────────────────────────────────────── */
      #hdr {
        grid-area: hdr;
        height: var(--hdr);
        background: var(--bg1);
        border-bottom: 1px solid var(--line1);
        display: flex;
        align-items: center;
        gap: 4px;
        padding: 0 12px;
        overflow-x: auto;
        scrollbar-width: none;
        position: relative;
        z-index: 20;
        box-shadow: var(--shadow);
      }
      #hdr::-webkit-scrollbar {
        display: none;
      }

      .logo {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-shrink: 0;
        padding-right: 8px;
      }
      .logo-mark {
        width: 30px;
        height: 30px;
        background: linear-gradient(
          135deg,
          var(--accent),
          rgba(0, 212, 168, 0.5)
        );
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 0 16px var(--accent-glow);
      }
      .logo-mark svg {
        width: 16px;
        height: 16px;
        color: #000;
      }
      .logo-text {
        font-family: var(--font-display);
        font-size: 15px;
        font-weight: 700;
        color: var(--t0);
        letter-spacing: 0.02em;
      }
      .logo-text span {
        color: var(--accent);
      }

      .vsep {
        width: 1px;
        height: 22px;
        background: var(--line1);
        flex-shrink: 0;
        margin: 0 4px;
      }
      .grow {
        flex: 1;
      }

      /* Source group */
      .src-group {
        display: flex;
        align-items: center;
        gap: 2px;
        background: var(--bg3);
        border: 1px solid var(--line1);
        border-radius: var(--r);
        padding: 3px;
      }
      .src-btn {
        display: flex;
        align-items: center;
        gap: 5px;
        padding: 4px 10px;
        height: 28px;
        background: transparent;
        border-radius: 6px;
        color: var(--t2);
        font-family: var(--font-ui);
        font-size: 11px;
        font-weight: 500;
        letter-spacing: 0.03em;
        transition: all var(--fast) var(--ease);
        flex-shrink: 0;
        white-space: nowrap;
      }
      .src-btn svg {
        width: 13px;
        height: 13px;
        flex-shrink: 0;
      }
      .src-btn:hover {
        background: var(--bg5);
        color: var(--t0);
      }
      .src-btn.on {
        background: var(--accent-dim);
        color: var(--accent);
      }
      @media (max-width: 900px) {
        .src-btn span {
          display: none;
        }
        .src-btn {
          padding: 4px 8px;
        }
      }

      /* Quality pill */
      .q-wrap {
        position: relative;
        flex-shrink: 0;
      }
      .q-wrap::after {
        content: '';
        position: absolute;
        right: 8px;
        top: 50%;
        transform: translateY(-50%);
        border: 4px solid transparent;
        border-top: 4px solid var(--t2);
        pointer-events: none;
        margin-top: 2px;
      }
      .q-sel {
        height: 32px;
        padding: 0 28px 0 10px;
        background: var(--bg3);
        border: 1px solid var(--line1);
        border-radius: var(--r);
        color: var(--t0);
        font-family: var(--font-mono);
        font-size: 10px;
        letter-spacing: 0.08em;
        font-weight: 500;
        cursor: pointer;
        transition: border-color var(--fast);
      }
      .q-sel:hover,
      .q-sel:focus {
        border-color: var(--accent);
      }
      .q-sel option {
        background: var(--bg2);
        color: var(--t0);
      }

      /* Stream controls */
      #btn-start {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 0 16px;
        height: 32px;
        background: var(--accent);
        border: none;
        border-radius: var(--r);
        color: #050f0c;
        font-family: var(--font-ui);
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.06em;
        flex-shrink: 0;
        transition: all var(--fast) var(--ease);
        box-shadow: 0 0 20px rgba(0, 212, 168, 0.3);
      }
      #btn-start:hover {
        background: #00ffe8;
        box-shadow: 0 0 28px rgba(0, 212, 168, 0.5);
      }
      #btn-start:disabled {
        opacity: 0.3;
        pointer-events: none;
        box-shadow: none;
      }

      #btn-stop {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 0 14px;
        height: 32px;
        background: transparent;
        border: 1px solid rgba(244, 63, 94, 0.3);
        border-radius: var(--r);
        color: var(--red);
        font-family: var(--font-ui);
        font-size: 11px;
        font-weight: 600;
        letter-spacing: 0.06em;
        flex-shrink: 0;
        transition: all var(--fast) var(--ease);
      }
      #btn-stop:hover {
        background: var(--red-dim);
        border-color: var(--red);
      }
      #btn-stop:disabled {
        opacity: 0.2;
        pointer-events: none;
      }

      /* AUTO button */
      #btn-auto {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 0 12px;
        height: 32px;
        background: transparent;
        border: 1px solid var(--line2);
        border-radius: var(--r);
        color: var(--t2);
        font-family: var(--font-ui);
        font-size: 11px;
        font-weight: 600;
        letter-spacing: 0.06em;
        flex-shrink: 0;
        transition: all var(--fast) var(--ease);
        position: relative;
        overflow: hidden;
      }
      #btn-auto.on {
        background: var(--accent-dim);
        border-color: var(--accent);
        color: var(--accent);
      }
      #btn-auto.state-degraded {
        background: var(--amber-dim);
        border-color: var(--amber);
        color: var(--amber);
      }
      #btn-auto.state-critical {
        background: var(--red-dim);
        border-color: var(--red);
        color: var(--red);
        animation: pulse-red 1s infinite;
      }
      #btn-auto.state-recovering {
        background: var(--green-dim);
        border-color: var(--green);
        color: var(--green);
      }
      .auto-dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: var(--t3);
        flex-shrink: 0;
        transition: all var(--fast);
      }
      #btn-auto.on .auto-dot {
        background: var(--accent);
        box-shadow: 0 0 6px var(--accent);
        animation: blink 2s infinite;
      }
      #btn-auto.state-degraded .auto-dot {
        background: var(--amber);
        animation: blink 1s infinite;
      }
      #btn-auto.state-critical .auto-dot {
        background: var(--red);
        animation: blink 0.5s infinite;
      }
      #btn-auto.state-recovering .auto-dot {
        background: var(--green);
        animation: blink 1.5s infinite;
      }
      @keyframes pulse-red {
        0%,
        100% {
          box-shadow: 0 0 0 0 rgba(244, 63, 94, 0);
        }
        50% {
          box-shadow: 0 0 8px rgba(244, 63, 94, 0.4);
        }
      }

      /* Icon buttons */
      .ib {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        border: 1px solid var(--line1);
        border-radius: var(--r);
        color: var(--t2);
        transition: all var(--fast) var(--ease);
        flex-shrink: 0;
        position: relative;
      }
      .ib svg {
        width: 14px;
        height: 14px;
      }
      .ib:hover {
        border-color: var(--accent);
        color: var(--accent);
        background: var(--accent-dim);
      }
      .ib.on {
        background: var(--accent-dim);
        border-color: var(--accent);
        color: var(--accent);
      }
      .ib.muted {
        border-color: rgba(245, 158, 11, 0.4);
        color: var(--amber);
        background: var(--amber-dim);
      }
      .ib.danger {
        border-color: rgba(244, 63, 94, 0.3);
        color: var(--red);
      }
      .ib.rec-on {
        background: var(--red-dim);
        border-color: var(--red);
        color: var(--red);
        animation: blink 0.9s infinite;
      }
      .ib.talk-on {
        background: var(--accent-dim);
        border-color: var(--accent);
        color: var(--accent);
        animation: blink 1.2s infinite;
      }

      /* Theme toggle */
      .theme-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        border: 1px solid var(--line1);
        border-radius: var(--r);
        color: var(--t2);
        transition: all var(--fast) var(--ease);
        flex-shrink: 0;
      }
      .theme-btn:hover {
        border-color: var(--accent);
        color: var(--accent);
        background: var(--accent-dim);
      }
      .theme-btn svg {
        width: 14px;
        height: 14px;
      }

      /* Command palette trigger */
      .cmd-btn {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 0 10px;
        height: 32px;
        background: var(--input-bg);
        border: 1px solid var(--line1);
        border-radius: var(--r);
        color: var(--t2);
        font-family: var(--font-mono);
        font-size: 10px;
        transition: all var(--fast);
        flex-shrink: 0;
      }
      .cmd-btn:hover {
        border-color: var(--accent);
        color: var(--t1);
      }
      .cmd-btn kbd {
        padding: 1px 5px;
        background: var(--bg4);
        border: 1px solid var(--line2);
        border-radius: 4px;
        font-size: 9px;
        color: var(--t3);
        font-family: var(--font-mono);
      }
      @media (max-width: 768px) {
        .cmd-btn {
          display: none;
        }
      }

      /* ── STAGE ───────────────────────────────────────── */
      #stage {
        grid-area: stage;
        background: #000;
        position: relative;
        overflow: hidden;
        min-height: 0;
      }
      #stream {
        width: 100%;
        height: 100%;
        object-fit: contain;
        display: block;
        transition:
          filter var(--med),
          transform var(--med);
      }

      /* ── IDLE SCREEN ─────────────────────────────────── */
      #idle {
        position: absolute;
        inset: 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 0;
        background: radial-gradient(ellipse 70% 60% at 50% 52%, #050e14, #000);
        transition: opacity var(--med) var(--ease);
        z-index: 4;
      }
      #idle.hidden {
        opacity: 0;
        pointer-events: none;
      }
      .idle-logo {
        font-family: var(--font-display);
        font-size: clamp(42px, 7vw, 80px);
        font-weight: 700;
        line-height: 1;
        letter-spacing: -0.02em;
        color: var(--t0);
      }
      .idle-logo span {
        color: var(--accent);
        text-shadow: 0 0 60px var(--accent-glow);
      }
      .idle-sub {
        font-size: 10px;
        letter-spacing: 0.3em;
        color: var(--t3);
        margin-top: 12px;
        text-transform: uppercase;
      }
      .idle-actions {
        display: flex;
        gap: 8px;
        margin-top: 32px;
        flex-wrap: wrap;
        justify-content: center;
      }
      .idle-action {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 8px 16px;
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.07);
        border-radius: var(--r);
        color: var(--t2);
        font-size: 11px;
        font-weight: 500;
        cursor: pointer;
        transition: all var(--fast);
      }
      .idle-action:hover {
        background: var(--accent-dim);
        border-color: var(--accent);
        color: var(--accent);
      }
      .idle-action kbd {
        font-family: var(--font-mono);
        font-size: 9px;
        padding: 1px 5px;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 3px;
      }
      .idle-hint {
        margin-top: 20px;
        font-size: 10px;
        color: var(--t3);
        letter-spacing: 0.1em;
      }
      .idle-hint kbd {
        font-family: var(--font-mono);
        padding: 2px 7px;
        background: rgba(0, 212, 168, 0.08);
        border: 1px solid rgba(0, 212, 168, 0.2);
        border-radius: 4px;
        color: var(--accent);
        font-size: 10px;
      }

      /* ── AUDIO VIEW ──────────────────────────────────── */
      #audio-view {
        position: absolute;
        inset: 0;
        display: none;
        flex-direction: column;
        background: radial-gradient(circle at 50% 40%, #050e14, #000);
        z-index: 5;
        overflow: hidden;
      }
      #audio-view.on {
        display: flex;
      }
      #fs-bars {
        flex: 1;
        width: 100%;
        display: block;
      }
      #captions-box {
        padding: 32px 48px;
        background: linear-gradient(
          to top,
          rgba(0, 0, 0, 0.92) 0%,
          transparent 100%
        );
        text-align: center;
        min-height: 120px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: flex-end;
        gap: 10px;
      }
      #captions-text {
        font-size: clamp(18px, 3vw, 36px);
        font-weight: 600;
        color: #fff;
        text-shadow: 0 2px 20px rgba(0, 212, 168, 0.4);
        min-height: 1.5em;
        line-height: 1.4;
      }
      #captions-sub {
        font-family: var(--font-mono);
        font-size: 9px;
        color: var(--t3);
        letter-spacing: 0.22em;
      }
      .cap-btn {
        padding: 6px 16px;
        border-radius: 20px;
        border: 1px solid var(--accent);
        color: var(--accent);
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.1em;
        background: var(--accent-dim);
        cursor: pointer;
        transition: all var(--med);
      }
      .cap-btn:hover {
        background: var(--accent-mid);
      }
      .cap-btn.on {
        background: var(--accent);
        color: #000;
      }

      /* ── HUD OVERLAYS ────────────────────────────────── */
      #flash {
        position: absolute;
        inset: 0;
        background: #fff;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.06s;
        z-index: 11;
      }
      #flash.pop {
        opacity: 0.3;
      }

      #hud-badge {
        position: absolute;
        top: 12px;
        left: 12px;
        display: flex;
        align-items: center;
        gap: 7px;
        padding: 5px 12px;
        background: rgba(10, 12, 18, 0.8);
        backdrop-filter: blur(16px);
        border: 1px solid var(--line2);
        border-radius: 20px;
        font-family: var(--font-mono);
        font-size: 9px;
        font-weight: 500;
        letter-spacing: 0.14em;
        pointer-events: none;
        z-index: 10;
      }
      .badge-dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: var(--t3);
        flex-shrink: 0;
        transition: all var(--med);
      }
      #hud-badge.live .badge-dot {
        background: var(--red);
        box-shadow: 0 0 8px var(--red);
        animation: blink 1.4s infinite;
      }
      #hud-badge.ok .badge-dot {
        background: var(--green);
        box-shadow: 0 0 6px var(--green);
      }
      #hud-badge.err .badge-dot {
        background: var(--red);
        box-shadow: 0 0 6px var(--red);
      }
      #hud-badge.spin .badge-dot {
        background: var(--accent);
        box-shadow: 0 0 8px var(--accent);
        animation: blink 0.6s infinite;
      }

      #live-tag {
        position: absolute;
        top: 12px;
        left: 50%;
        transform: translateX(-50%);
        display: none;
        align-items: center;
        gap: 5px;
        padding: 4px 12px;
        border-radius: 20px;
        background: rgba(244, 63, 94, 0.1);
        border: 1px solid rgba(244, 63, 94, 0.4);
        font-family: var(--font-mono);
        font-size: 9px;
        font-weight: 700;
        letter-spacing: 0.18em;
        color: var(--red);
        pointer-events: none;
        z-index: 10;
      }
      #live-tag.on {
        display: flex;
      }
      #live-tag .rdot {
        width: 5px;
        height: 5px;
        border-radius: 50%;
        background: var(--red);
        animation: blink 1s infinite;
      }

      #rec-tag {
        position: absolute;
        top: 12px;
        right: 12px;
        display: none;
        align-items: center;
        gap: 5px;
        padding: 4px 12px;
        border-radius: 20px;
        background: rgba(244, 63, 94, 0.1);
        border: 1px solid rgba(244, 63, 94, 0.4);
        font-family: var(--font-mono);
        font-size: 9px;
        letter-spacing: 0.1em;
        color: var(--red);
        pointer-events: none;
        z-index: 10;
      }
      #rec-tag.on {
        display: flex;
      }
      #rec-tag .rdot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: var(--red);
        animation: blink 0.8s infinite;
      }

      #hud-stats {
        position: absolute;
        top: 50px;
        left: 12px;
        font-family: var(--font-mono);
        font-size: 10px;
        line-height: 2;
        color: rgba(0, 212, 168, 0.85);
        opacity: 0;
        pointer-events: none;
        text-shadow: 0 1px 8px rgba(0, 0, 0, 0.9);
        display: none;
        z-index: 10;
        background: rgba(8, 11, 16, 0.7);
        backdrop-filter: blur(8px);
        border: 1px solid rgba(0, 212, 168, 0.12);
        border-radius: var(--r);
        padding: 8px 12px;
      }
      #hud-stats.on {
        opacity: 1;
        display: block;
      }
      #hud-stats span {
        display: block;
      }

      #lat-display {
        position: absolute;
        bottom: 46px;
        right: 14px;
        text-align: center;
        display: none;
        z-index: 10;
      }
      #lat-display.on {
        display: block;
      }
      .lat-num {
        font-family: var(--font-display);
        font-size: 52px;
        font-weight: 700;
        line-height: 1;
        color: var(--accent);
      }
      .lat-lbl {
        font-family: var(--font-mono);
        font-size: 8px;
        letter-spacing: 0.22em;
        color: var(--t3);
        margin-top: 2px;
      }

      /* TOAST */
      #toast {
        position: absolute;
        bottom: 40px;
        left: 50%;
        transform: translateX(-50%) translateY(6px);
        padding: 8px 16px;
        font-family: var(--font-ui);
        font-size: 11px;
        font-weight: 500;
        letter-spacing: 0.02em;
        background: var(--bg2);
        border: 1px solid var(--line2);
        border-radius: var(--r);
        color: var(--t1);
        opacity: 0;
        transition: all 0.2s var(--ease);
        pointer-events: none;
        white-space: nowrap;
        max-width: 90vw;
        z-index: 20;
        box-shadow: var(--shadow-lg);
      }
      #toast.show {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
      }
      #toast.show.ok {
        border-color: var(--green);
        color: var(--green);
        background: var(--green-dim);
      }
      #toast.show.err {
        border-color: var(--red);
        color: var(--red);
        background: var(--red-dim);
      }

      /* AUTO HUD */
      #auto-hud {
        position: absolute;
        bottom: 40px;
        left: 14px;
        background: rgba(10, 12, 20, 0.9);
        backdrop-filter: blur(18px);
        border: 1px solid var(--line2);
        border-radius: var(--r-lg);
        padding: 12px 16px;
        min-width: 210px;
        display: none;
        flex-direction: column;
        gap: 8px;
        z-index: 10;
        pointer-events: none;
      }
      #auto-hud.on {
        display: flex;
      }
      .auto-hud-top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
      }
      .auto-state-label {
        font-size: 8px;
        font-family: var(--font-mono);
        letter-spacing: 0.2em;
        color: var(--t3);
        margin-bottom: 3px;
      }
      .auto-state-name {
        font-family: var(--font-display);
        font-size: 20px;
        font-weight: 700;
        letter-spacing: 0.06em;
      }
      .auto-state-name.idle {
        color: var(--t2);
      }
      .auto-state-name.watching {
        color: var(--accent);
      }
      .auto-state-name.stable {
        color: var(--green);
      }
      .auto-state-name.degraded {
        color: var(--amber);
        animation: blink 2s infinite;
      }
      .auto-state-name.critical {
        color: var(--red);
        animation: blink 0.8s infinite;
      }
      .auto-state-name.recovering {
        color: var(--green);
      }

      .score-ring {
        position: relative;
        width: 40px;
        height: 40px;
        flex-shrink: 0;
      }
      .score-ring svg {
        width: 40px;
        height: 40px;
        transform: rotate(-90deg);
      }
      .score-ring .ring-bg {
        fill: none;
        stroke: var(--bg5);
        stroke-width: 3;
      }
      .score-ring .ring-val {
        fill: none;
        stroke-width: 3;
        stroke-linecap: round;
        transition:
          stroke-dashoffset 0.8s var(--ease),
          stroke 0.4s;
      }
      .score-center {
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: var(--font-mono);
        font-size: 10px;
        font-weight: 700;
      }

      .auto-hud-level {
        display: flex;
        gap: 2px;
        align-items: center;
      }
      .alb {
        flex: 1;
        height: 3px;
        border-radius: 2px;
        background: var(--bg5);
        transition: background var(--med);
      }
      .alb.filled {
        background: var(--accent);
      }
      .alb-label {
        font-family: var(--font-mono);
        font-size: 8px;
        color: var(--t3);
        flex-shrink: 0;
        margin-right: 5px;
      }

      .auto-hud-metrics {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 2px 12px;
      }
      .ahm {
        font-family: var(--font-mono);
        font-size: 8px;
        color: var(--t3);
      }
      .ahm span {
        color: var(--t1);
        float: right;
      }
      .auto-hud-reason {
        font-size: 9px;
        color: var(--t3);
        border-top: 1px solid var(--line0);
        padding-top: 6px;
        font-style: italic;
        font-family: var(--font-mono);
      }

      /* ── STATUS BAR ──────────────────────────────────── */
      #statusbar {
        grid-area: statusbar;
        height: var(--status-h);
        background: var(--bg1);
        border-top: 1px solid var(--line0);
        display: flex;
        align-items: center;
        padding: 0 12px;
        gap: 16px;
        font-family: var(--font-mono);
        font-size: 9px;
        color: var(--t3);
        overflow: hidden;
      }
      .sb-item {
        display: flex;
        align-items: center;
        gap: 5px;
        white-space: nowrap;
      }
      .sb-item svg {
        width: 10px;
        height: 10px;
        opacity: 0.6;
      }
      .sb-val {
        color: var(--t2);
        font-weight: 500;
      }
      .sb-val.green {
        color: var(--green);
      }
      .sb-val.amber {
        color: var(--amber);
      }
      .sb-val.red {
        color: var(--red);
      }
      .sb-val.accent {
        color: var(--accent);
      }
      .sb-sep {
        width: 1px;
        height: 14px;
        background: var(--line1);
      }
      .sb-right {
        margin-left: auto;
        display: flex;
        align-items: center;
        gap: 12px;
      }
      .sb-hint {
        display: flex;
        align-items: center;
        gap: 4px;
      }
      .sb-hint kbd {
        padding: 0 4px;
        font-family: var(--font-mono);
        font-size: 8px;
        background: var(--bg4);
        border: 1px solid var(--line2);
        border-radius: 3px;
        color: var(--t3);
      }
      @media (max-width: 600px) {
        .sb-hint {
          display: none;
        }
        .sb-item:nth-child(n + 4) {
          display: none;
        }
      }

      /* ── PANEL OVERLAY ───────────────────────────────── */
      #panel-bg {
        display: none;
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.4);
        backdrop-filter: blur(4px);
        z-index: 29;
      }
      #panel-bg.on {
        display: block;
      }

      /* ── PANEL ───────────────────────────────────────── */
      #panel {
        grid-area: panel;
        background: var(--bg1);
        border-left: 1px solid var(--line1);
        display: flex;
        flex-direction: column;
        min-height: 0;
        transform: translateX(100%);
        transition: transform var(--med) var(--ease);
      }
      #app.panel-open #panel {
        transform: translateX(0);
      }

      /* Tabs */
      .p-tabs {
        display: flex;
        flex-shrink: 0;
        background: var(--bg2);
        border-bottom: 1px solid var(--line1);
        overflow-x: auto;
        scrollbar-width: none;
        gap: 2px;
        padding: 6px 8px 0;
      }
      .p-tabs::-webkit-scrollbar {
        display: none;
      }
      .ptab {
        display: flex;
        align-items: center;
        gap: 5px;
        padding: 6px 10px;
        height: 32px;
        background: transparent;
        border: 1px solid transparent;
        border-radius: var(--r-sm) var(--r-sm) 0 0;
        border-bottom: none;
        color: var(--t3);
        font-family: var(--font-ui);
        font-size: 10px;
        font-weight: 500;
        letter-spacing: 0.04em;
        cursor: pointer;
        transition: all var(--fast);
        white-space: nowrap;
        margin-bottom: -1px;
      }
      .ptab svg {
        width: 12px;
        height: 12px;
      }
      .ptab:hover {
        color: var(--t1);
      }
      .ptab.on {
        background: var(--bg1);
        border-color: var(--line1);
        border-bottom-color: var(--bg1);
        color: var(--accent);
      }
      .ptab.rec-tab.on {
        color: var(--red);
      }

      /* Panes */
      .pane {
        display: none;
        flex: 1;
        overflow-y: auto;
        flex-direction: column;
        padding: 10px 10px;
        gap: 10px;
        min-height: 0;
      }
      .pane.on {
        display: flex;
      }

      /* Sections */
      .sec {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .sec-hd {
        font-family: var(--font-ui);
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.06em;
        color: var(--t2);
        padding-bottom: 6px;
        border-bottom: 1px solid var(--line0);
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      /* KV rows */
      .kv {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1px 0;
      }
      .kv .k {
        font-size: 10px;
        color: var(--t2);
      }
      .kv .v {
        font-family: var(--font-mono);
        font-size: 10px;
        color: var(--accent);
        font-weight: 500;
      }
      .kv .v.green {
        color: var(--green);
      }
      .kv .v.red {
        color: var(--red);
      }
      .kv .v.amber {
        color: var(--amber);
      }
      .kv .v.dim {
        color: var(--t1);
      }
      .kv .v.warn {
        color: var(--amber);
      }

      /* Sliders */
      .sl-row {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .sl-head {
        display: flex;
        justify-content: space-between;
        align-items: baseline;
      }
      .sl-lbl {
        font-size: 11px;
        font-weight: 500;
        color: var(--t1);
      }
      .sl-sub {
        font-size: 9px;
        color: var(--t2);
        margin-top: 1px;
      }
      .sl-val {
        font-family: var(--font-mono);
        font-size: 12px;
        font-weight: 600;
        color: var(--accent);
        flex-shrink: 0;
        min-width: 68px;
        text-align: right;
      }
      .sl-val.green {
        color: var(--green);
      }
      .sl-val.red {
        color: var(--red);
      }

      input[type='range'] {
        -webkit-appearance: none;
        width: 100%;
        height: 3px;
        border-radius: 2px;
        cursor: pointer;
        background: linear-gradient(
          to right,
          var(--accent) var(--pct, 0%),
          var(--bg5) var(--pct, 0%)
        );
      }
      input[type='range'].gr {
        background: linear-gradient(
          to right,
          var(--green) var(--pct, 0%),
          var(--bg5) var(--pct, 0%)
        );
      }
      input[type='range'].rr {
        background: linear-gradient(
          to right,
          var(--red) var(--pct, 0%),
          var(--bg5) var(--pct, 0%)
        );
      }
      input[type='range']::-webkit-slider-thumb {
        -webkit-appearance: none;
        width: 14px;
        height: 14px;
        border-radius: 50%;
        background: var(--accent);
        border: 2px solid var(--bg1);
        box-shadow: 0 0 0 3px rgba(0, 212, 168, 0.15);
        transition:
          transform var(--fast),
          box-shadow var(--fast);
      }
      input[type='range']::-webkit-slider-thumb:hover {
        transform: scale(1.25);
        box-shadow: 0 0 0 4px rgba(0, 212, 168, 0.25);
      }
      input[type='range'].gr::-webkit-slider-thumb {
        background: var(--green);
        box-shadow: 0 0 0 3px rgba(34, 197, 94, 0.15);
      }
      input[type='range'].rr::-webkit-slider-thumb {
        background: var(--red);
        box-shadow: 0 0 0 3px rgba(244, 63, 94, 0.15);
      }

      /* Chips */
      .chips {
        display: flex;
        gap: 3px;
        flex-wrap: wrap;
      }
      .chip {
        padding: 3px 9px;
        font-size: 9px;
        font-weight: 500;
        letter-spacing: 0.06em;
        background: var(--bg3);
        border: 1px solid var(--line1);
        border-radius: 4px;
        color: var(--t2);
        cursor: pointer;
        transition: all var(--fast);
      }
      .chip:hover {
        border-color: var(--accent);
        color: var(--accent);
      }
      .chip.on {
        background: var(--accent-dim);
        border-color: var(--accent);
        color: var(--accent);
      }
      .chip.green:hover,
      .chip.green.on {
        border-color: var(--green);
        color: var(--green);
        background: var(--green-dim);
      }
      .chip.red:hover,
      .chip.red.on {
        border-color: var(--red);
        color: var(--red);
        background: var(--red-dim);
      }

      /* Form fields */
      .fr {
        display: flex;
        flex-direction: column;
        gap: 3px;
      }
      .fr label {
        font-size: 9px;
        font-weight: 600;
        color: var(--t2);
        letter-spacing: 0.1em;
        text-transform: uppercase;
      }
      .fr input,
      .fr select,
      .fr textarea {
        width: 100%;
        padding: 6px 9px;
        background: var(--input-bg);
        border: 1px solid var(--line1);
        border-radius: var(--r-sm);
        color: var(--t0);
        font-family: var(--font-mono);
        font-size: 10px;
        transition:
          border-color var(--fast),
          background var(--fast);
      }
      .fr input:focus,
      .fr select:focus,
      .fr textarea:focus {
        border-color: var(--accent);
        background: var(--bg3);
      }
      .fr select option {
        background: var(--bg2);
        color: var(--t0);
      }
      .fr textarea {
        resize: vertical;
        min-height: 46px;
      }
      .fr-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 6px;
      }

      /* Toggle */
      .toggle-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 2px 0;
      }
      .toggle-lbl {
        font-size: 11px;
        font-weight: 500;
        color: var(--t1);
      }
      .toggle-sub {
        font-size: 9px;
        color: var(--t2);
        margin-top: 1px;
      }
      .tog {
        position: relative;
        width: 34px;
        height: 18px;
        flex-shrink: 0;
        cursor: pointer;
      }
      .tog input {
        opacity: 0;
        width: 0;
        height: 0;
        position: absolute;
      }
      .tslide {
        position: absolute;
        inset: 0;
        border-radius: 9px;
        background: var(--bg5);
        border: 1px solid var(--line2);
        transition: all var(--fast);
      }
      .tslide::before {
        content: '';
        position: absolute;
        left: 2px;
        top: 50%;
        transform: translateY(-50%);
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background: var(--t2);
        transition: all var(--fast);
      }
      .tog input:checked + .tslide {
        background: var(--accent-dim);
        border-color: var(--accent);
      }
      .tog input:checked + .tslide::before {
        left: 19px;
        background: var(--accent);
      }
      .tog input:checked + .tslide.red {
        background: var(--red-dim);
        border-color: var(--red);
      }
      .tog input:checked + .tslide.red::before {
        background: var(--red);
      }

      /* Action buttons */
      .abtn {
        width: 100%;
        padding: 8px;
        margin-top: 2px;
        background: var(--accent-dim);
        border: 1px solid var(--accent);
        border-radius: var(--r);
        color: var(--accent);
        font-family: var(--font-ui);
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.08em;
        cursor: pointer;
        transition: all var(--fast);
      }
      .abtn:hover {
        background: var(--accent-mid);
      }
      .abtn.green {
        background: var(--green-dim);
        border-color: var(--green);
        color: var(--green);
      }
      .abtn.green:hover {
        background: rgba(34, 197, 94, 0.2);
      }
      .abtn.red {
        background: var(--red-dim);
        border-color: var(--red);
        color: var(--red);
      }
      .abtn.red:hover {
        background: rgba(244, 63, 94, 0.2);
      }
      .abtn.amber {
        background: var(--amber-dim);
        border-color: var(--amber);
        color: var(--amber);
      }
      .abtn:disabled {
        opacity: 0.2;
        pointer-events: none;
      }

      /* PiP grid */
      .pip-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 4px;
      }
      .pip-cell {
        padding: 8px 4px;
        text-align: center;
        font-size: 9px;
        font-weight: 500;
        letter-spacing: 0.04em;
        background: var(--bg3);
        border: 1px solid var(--line1);
        border-radius: var(--r);
        color: var(--t2);
        cursor: pointer;
        transition: all var(--fast);
      }
      .pip-cell:hover {
        border-color: var(--accent);
        color: var(--accent);
      }
      .pip-cell.on {
        background: var(--accent-dim);
        border-color: var(--accent);
        color: var(--accent);
      }

      /* Canvases */
      #viz-canvas {
        width: 100%;
        height: 52px;
        display: block;
        border-radius: var(--r);
        background: var(--bg3);
        border: 1px solid var(--line0);
      }
      canvas.spark {
        width: 100%;
        height: 34px;
        display: block;
        border-radius: var(--r);
        background: var(--bg3);
        border: 1px solid var(--line0);
      }
      canvas.auto-spark {
        width: 100%;
        height: 30px;
        display: block;
        border-radius: var(--r);
        background: var(--bg3);
        border: 1px solid var(--line0);
      }

      /* Log */
      #logbox,
      #auto-log {
        background: var(--bg2);
        border: 1px solid var(--line1);
        border-radius: var(--r);
        padding: 7px 9px;
        overflow-y: auto;
        font-family: var(--font-mono);
        font-size: 9px;
        line-height: 1.9;
      }
      #logbox {
        height: 200px;
      }
      #auto-log {
        height: 145px;
      }
      .le,
      .ale {
        display: block;
        word-break: break-all;
      }
      .le.ok,
      .ale.up {
        color: var(--green);
      }
      .le.warn,
      .ale.down {
        color: var(--amber);
      }
      .le.err,
      .ale.crit {
        color: var(--red);
      }
      .le.info,
      .ale.info {
        color: var(--t1);
      }
      .le.dim {
        color: var(--t3);
      }
      .ale.state {
        color: var(--accent);
        font-weight: 500;
      }

      /* REC tab */
      .rec-timer-display {
        font-family: var(--font-display);
        font-size: 60px;
        font-weight: 700;
        line-height: 1;
        color: var(--red);
        text-align: center;
        letter-spacing: 0.05em;
        text-shadow: 0 0 40px rgba(244, 63, 94, 0.2);
        padding: 8px 0;
      }
      .rec-status-lbl {
        text-align: center;
        font-family: var(--font-mono);
        font-size: 9px;
        font-weight: 500;
        letter-spacing: 0.18em;
        color: var(--t2);
      }
      .rec-status-lbl.on {
        color: var(--red);
      }
      #rec-segs {
        display: flex;
        flex-direction: column;
        gap: 3px;
        max-height: 180px;
        overflow-y: auto;
      }
      .rec-seg {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 6px 9px;
        background: var(--bg3);
        border: 1px solid var(--line1);
        border-radius: var(--r);
      }
      .rec-seg-name {
        font-size: 10px;
        color: var(--t1);
        font-weight: 500;
      }
      .rec-seg-dur {
        font-family: var(--font-mono);
        font-size: 8px;
        color: var(--t2);
        margin-top: 1px;
      }
      .seg-dl-btn {
        padding: 3px 9px;
        font-size: 9px;
        font-weight: 600;
        background: var(--green-dim);
        border: 1px solid var(--green);
        border-radius: 4px;
        color: var(--green);
        cursor: pointer;
        transition: all var(--fast);
      }
      .seg-dl-btn:hover {
        background: rgba(34, 197, 94, 0.2);
      }

      /* Shortcuts */
      .sc-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 2px 0;
      }
      .sc-key {
        font-family: var(--font-mono);
        font-size: 10px;
        color: var(--accent);
      }
      .sc-desc {
        font-size: 10px;
        color: var(--t2);
      }

      /* AUTO pane big state */
      .auto-big-state {
        text-align: center;
        padding: 14px 0 6px;
      }
      .auto-big-name {
        font-family: var(--font-display);
        font-size: 42px;
        font-weight: 700;
        letter-spacing: 0.08em;
        transition: color var(--med);
      }
      .auto-big-score {
        font-family: var(--font-mono);
        font-size: 11px;
        color: var(--t2);
        margin-top: 2px;
      }
      .score-bar-wrap {
        position: relative;
        height: 5px;
        background: var(--bg5);
        border-radius: 3px;
        overflow: hidden;
      }
      .score-bar-fill {
        height: 100%;
        border-radius: 3px;
        transition:
          width 0.8s var(--ease),
          background 0.4s;
      }
      .m-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 4px;
      }
      .m-cell {
        background: var(--bg3);
        border: 1px solid var(--line0);
        border-radius: var(--r);
        padding: 8px 10px;
      }
      .m-cell-lbl {
        font-family: var(--font-mono);
        font-size: 7px;
        color: var(--t3);
        letter-spacing: 0.15em;
        margin-bottom: 3px;
      }
      .m-cell-val {
        font-family: var(--font-mono);
        font-size: 15px;
        font-weight: 600;
        color: var(--t0);
      }
      .m-cell-val.ok {
        color: var(--green);
      }
      .m-cell-val.warn {
        color: var(--amber);
      }
      .m-cell-val.bad {
        color: var(--red);
      }
      .ql-strip {
        display: flex;
        gap: 2px;
      }
      .ql-node {
        flex: 1;
        padding: 5px 2px;
        text-align: center;
        font-family: var(--font-mono);
        font-size: 7px;
        font-weight: 600;
        letter-spacing: 0.04em;
        color: var(--t3);
        background: var(--bg3);
        border: 1px solid var(--line0);
        border-radius: 4px;
        cursor: pointer;
        transition: all var(--fast);
      }
      .ql-node.active {
        background: var(--accent-dim);
        border-color: var(--accent);
        color: var(--accent);
      }
      .ql-node.target {
        background: rgba(0, 212, 168, 0.04);
        border-color: rgba(0, 212, 168, 0.15);
        color: rgba(0, 212, 168, 0.4);
      }
      .ql-node:hover {
        border-color: var(--accent);
        color: var(--accent);
      }
      .aggr-labels {
        display: flex;
        justify-content: space-between;
        font-size: 8px;
        color: var(--t3);
        padding: 0 2px;
      }

      /* ══════════════════════════════════════════════════
   COMMAND PALETTE
══════════════════════════════════════════════════ */
      #cmdpal {
        position: fixed;
        inset: 0;
        display: flex;
        align-items: flex-start;
        justify-content: center;
        padding-top: 80px;
        background: rgba(0, 0, 0, 0.6);
        backdrop-filter: blur(8px);
        z-index: 100;
        opacity: 0;
        pointer-events: none;
        transition: opacity var(--fast);
      }
      #cmdpal.on {
        opacity: 1;
        pointer-events: all;
      }
      .pal-box {
        width: min(560px, 90vw);
        background: var(--bg1);
        border: 1px solid var(--line2);
        border-radius: var(--r-lg);
        box-shadow: var(--shadow-lg);
        overflow: hidden;
        transform: scale(0.97) translateY(-8px);
        transition: transform var(--fast) var(--ease);
      }
      #cmdpal.on .pal-box {
        transform: scale(1) translateY(0);
      }
      .pal-search {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 14px 16px;
        border-bottom: 1px solid var(--line1);
      }
      .pal-search svg {
        width: 16px;
        height: 16px;
        color: var(--t2);
        flex-shrink: 0;
      }
      .pal-search input {
        flex: 1;
        background: transparent;
        border: none;
        color: var(--t0);
        font-family: var(--font-ui);
        font-size: 14px;
        outline: none;
      }
      .pal-search input::placeholder {
        color: var(--t3);
      }
      .pal-esc {
        font-family: var(--font-mono);
        font-size: 9px;
        color: var(--t3);
        padding: 2px 7px;
        background: var(--bg4);
        border: 1px solid var(--line2);
        border-radius: 4px;
        flex-shrink: 0;
      }
      .pal-results {
        max-height: 380px;
        overflow-y: auto;
        padding: 6px;
      }
      .pal-group-label {
        font-family: var(--font-mono);
        font-size: 8px;
        font-weight: 600;
        letter-spacing: 0.14em;
        color: var(--t3);
        padding: 8px 10px 4px;
      }
      .pal-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 8px 10px;
        border-radius: var(--r-sm);
        cursor: pointer;
        transition: all var(--fast);
      }
      .pal-item:hover,
      .pal-item.selected {
        background: var(--accent-dim);
      }
      .pal-item:hover .pal-item-name,
      .pal-item.selected .pal-item-name {
        color: var(--accent);
      }
      .pal-item-icon {
        width: 28px;
        height: 28px;
        border-radius: 6px;
        background: var(--bg3);
        border: 1px solid var(--line1);
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        color: var(--t2);
      }
      .pal-item-icon svg {
        width: 13px;
        height: 13px;
      }
      .pal-item-name {
        font-size: 12px;
        font-weight: 500;
        color: var(--t1);
        flex: 1;
      }
      .pal-item-desc {
        font-size: 10px;
        color: var(--t3);
      }
      .pal-item-kbd {
        font-family: var(--font-mono);
        font-size: 9px;
        color: var(--t3);
        padding: 1px 6px;
        background: var(--bg4);
        border: 1px solid var(--line2);
        border-radius: 3px;
        flex-shrink: 0;
      }
      .pal-footer {
        padding: 8px 16px;
        border-top: 1px solid var(--line1);
        display: flex;
        gap: 14px;
        align-items: center;
        font-family: var(--font-mono);
        font-size: 8px;
        color: var(--t3);
      }
      .pal-footer span {
        display: flex;
        align-items: center;
        gap: 4px;
      }
      .pal-footer kbd {
        padding: 1px 5px;
        background: var(--bg4);
        border: 1px solid var(--line2);
        border-radius: 3px;
        font-size: 8px;
        font-family: var(--font-mono);
      }
      .pal-empty {
        text-align: center;
        padding: 32px;
        color: var(--t3);
        font-size: 11px;
      }

      /* ══════════════════════════════════════════════════
   SHORTCUTS OVERLAY
══════════════════════════════════════════════════ */
      #shortcuts-overlay {
        position: fixed;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(0, 0, 0, 0.7);
        backdrop-filter: blur(8px);
        z-index: 99;
        opacity: 0;
        pointer-events: none;
        transition: opacity var(--fast);
      }
      #shortcuts-overlay.on {
        opacity: 1;
        pointer-events: all;
      }
      .sc-panel {
        width: min(700px, 90vw);
        max-height: 80vh;
        overflow-y: auto;
        background: var(--bg1);
        border: 1px solid var(--line2);
        border-radius: var(--r-lg);
        box-shadow: var(--shadow-lg);
        padding: 24px;
      }
      .sc-panel-title {
        font-family: var(--font-display);
        font-size: 22px;
        font-weight: 700;
        color: var(--t0);
        margin-bottom: 20px;
      }
      .sc-panel-title span {
        color: var(--accent);
      }
      .sc-columns {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
      }
      @media (max-width: 500px) {
        .sc-columns {
          grid-template-columns: 1fr;
        }
      }
      .sc-group {
        display: flex;
        flex-direction: column;
        gap: 8px;
      }
      .sc-group-title {
        font-size: 10px;
        font-weight: 600;
        color: var(--t2);
        letter-spacing: 0.1em;
        margin-bottom: 4px;
      }
      .sck {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 4px 0;
        border-bottom: 1px solid var(--line0);
      }
      .sck:last-child {
        border-bottom: none;
      }
      .sck-keys {
        display: flex;
        gap: 3px;
      }
      .sck-key {
        font-family: var(--font-mono);
        font-size: 10px;
        padding: 2px 7px;
        background: var(--bg4);
        border: 1px solid var(--line2);
        border-radius: 4px;
        color: var(--accent);
      }
      .sck-desc {
        font-size: 10px;
        color: var(--t2);
      }
      .sc-close-btn {
        display: block;
        margin: 20px auto 0;
        padding: 8px 24px;
        background: var(--accent-dim);
        border: 1px solid var(--accent);
        border-radius: var(--r);
        color: var(--accent);
        font-size: 11px;
        font-weight: 600;
        cursor: pointer;
        transition: background var(--fast);
      }
      .sc-close-btn:hover {
        background: var(--accent-mid);
      }

      @keyframes blink {
        0%,
        100% {
          opacity: 1;
        }
        50% {
          opacity: 0.2;
        }
      }

      /* ── RESPONSIVE ──────────────────────────────────── */
      @media (max-width: 900px) {
        :root {
          --panel-w: min(340px, 100vw);
        }
        #app,
        #app.panel-open {
          grid-template:
            'hdr' var(--hdr) 'stage' 1fr 'statusbar' var(--status-h)
            / 1fr;
        }
        #panel {
          grid-area: unset;
          position: fixed;
          top: 0;
          right: 0;
          width: min(340px, 100vw);
          height: 100dvh;
          z-index: 30;
        }
      }
      @media (max-width: 600px) {
        .logo-text {
          display: none;
        }
        #btn-start span,
        #btn-stop span {
          display: none;
        }
        #btn-start,
        #btn-stop {
          padding: 0 12px;
        }
      }
      @media (max-width: 480px) {
        .q-wrap,
        .vsep:nth-child(3) {
          display: none;
        }
      }
      #stage:fullscreen {
        background: #000;
      }

      /* ACK animation */
      .sl-row.ack .sl-val {
        animation: ack 0.5s ease;
      }
      @keyframes ack {
        0%,
        100% {
          color: var(--accent);
        }
        50% {
          color: var(--green);
        }
      }
    </style>
  </head>
  <body>
    <!-- Command Palette -->
    <div id="cmdpal" onclick="if (event.target === this) closePal();">
      <div class="pal-box">
        <div class="pal-search">
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <circle cx="11" cy="11" r="8" />
            <path d="m21 21-4.35-4.35" />
          </svg>
          <input
            type="text"
            id="pal-input"
            placeholder="Type a command or search…"
            oninput="filterPal(this.value)"
            onkeydown="palKey(event)"
          />
          <span class="pal-esc">ESC</span>
        </div>
        <div class="pal-results" id="pal-results"></div>
        <div class="pal-footer">
          <span><kbd>↑↓</kbd> Navigate</span>
          <span><kbd>↵</kbd> Execute</span>
          <span><kbd>ESC</kbd> Close</span>
        </div>
      </div>
    </div>

    <!-- Shortcuts Overlay -->
    <div
      id="shortcuts-overlay"
      onclick="if (event.target === this) closeShortcuts();"
    >
      <div class="sc-panel">
        <div class="sc-panel-title">Keyboard <span>Shortcuts</span></div>
        <div class="sc-columns">
          <div class="sc-group">
            <div class="sc-group-title">STREAM CONTROL</div>
            <div class="sck">
              <div class="sck-keys"><span class="sck-key">SPACE</span></div>
              <span class="sck-desc">Start / Stop stream</span>
            </div>
            <div class="sck">
              <div class="sck-keys"><span class="sck-key">ESC</span></div>
              <span class="sck-desc">Stop stream</span>
            </div>
            <div class="sck">
              <div class="sck-keys"><span class="sck-key">Q</span></div>
              <span class="sck-desc">Toggle Autopilot</span>
            </div>
            <div class="sck">
              <div class="sck-keys"><span class="sck-key">R</span></div>
              <span class="sck-desc">Toggle Recording</span>
            </div>
          </div>
          <div class="sc-group">
            <div class="sc-group-title">SOURCE</div>
            <div class="sck">
              <div class="sck-keys"><span class="sck-key">S</span></div>
              <span class="sck-desc">Screen capture</span>
            </div>
            <div class="sck">
              <div class="sck-keys"><span class="sck-key">W</span></div>
              <span class="sck-desc">Window capture</span>
            </div>
            <div class="sck">
              <div class="sck-keys"><span class="sck-key">C</span></div>
              <span class="sck-desc">Webcam</span>
            </div>
            <div class="sck">
              <div class="sck-keys"><span class="sck-key">B</span></div>
              <span class="sck-desc">Screen + Cam</span>
            </div>
            <div class="sck">
              <div class="sck-keys"><span class="sck-key">A</span></div>
              <span class="sck-desc">Audio only</span>
            </div>
          </div>
          <div class="sc-group">
            <div class="sc-group-title">AUDIO</div>
            <div class="sck">
              <div class="sck-keys"><span class="sck-key">M</span></div>
              <span class="sck-desc">Toggle server mic</span>
            </div>
            <div class="sck">
              <div class="sck-keys"><span class="sck-key">T</span></div>
              <span class="sck-desc">Talk to PC</span>
            </div>
            <div class="sck">
              <div class="sck-keys"><span class="sck-key">U</span></div>
              <span class="sck-desc">Toggle speaker</span>
            </div>
          </div>
          <div class="sc-group">
            <div class="sc-group-title">VIEW</div>
            <div class="sck">
              <div class="sck-keys"><span class="sck-key">F</span></div>
              <span class="sck-desc">Fullscreen</span>
            </div>
            <div class="sck">
              <div class="sck-keys"><span class="sck-key">I</span></div>
              <span class="sck-desc">Stats overlay</span>
            </div>
            <div class="sck">
              <div class="sck-keys"><span class="sck-key">L</span></div>
              <span class="sck-desc">Latency meter</span>
            </div>
            <div class="sck">
              <div class="sck-keys"><span class="sck-key">P</span></div>
              <span class="sck-desc">Screenshot</span>
            </div>
            <div class="sck">
              <div class="sck-keys"><span class="sck-key">,</span></div>
              <span class="sck-desc">Toggle panel</span>
            </div>
            <div class="sck">
              <div class="sck-keys">
                <span class="sck-key">Ctrl</span><span class="sck-key">K</span>
              </div>
              <span class="sck-desc">Command palette</span>
            </div>
            <div class="sck">
              <div class="sck-keys"><span class="sck-key">?</span></div>
              <span class="sck-desc">This help screen</span>
            </div>
          </div>
        </div>
        <button class="sc-close-btn" onclick="closeShortcuts()">CLOSE</button>
      </div>
    </div>

    <div id="panel-bg" onclick="closePanel()"></div>

    <div id="app">
      <!-- ═══════ HEADER ═══════ -->
      <header id="hdr">
        <div class="logo">
          <div class="logo-mark">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2.5"
            >
              <polygon points="5 3 19 12 5 21 5 3" />
            </svg>
          </div>
          <div class="logo-text">Stream<span>Forge</span></div>
        </div>
        <div class="vsep"></div>

        <!-- Sources -->
        <div class="src-group">
          <button
            class="src-btn on"
            id="btn-screen"
            onclick="setMode('screen')"
            title="Screen [S]"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
            >
              <rect x="2" y="3" width="20" height="14" rx="2" />
              <path d="M8 21h8m-4-4v4" />
            </svg>
            <span>Screen</span>
          </button>
          <button
            class="src-btn"
            id="btn-window"
            onclick="setMode('window')"
            title="Window [W]"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
            >
              <rect x="3" y="3" width="18" height="18" rx="2" />
              <line x1="3" y1="8" x2="21" y2="8" />
              <circle cx="6.5" cy="5.5" r="1" fill="currentColor" />
              <circle cx="9.5" cy="5.5" r="1" fill="currentColor" />
            </svg>
            <span>Window</span>
          </button>
          <button
            class="src-btn"
            id="btn-webcam"
            onclick="setMode('webcam')"
            title="Webcam [C]"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
            >
              <path d="M23 7l-7 5 7 5V7z" />
              <rect x="1" y="5" width="15" height="14" rx="2" />
            </svg>
            <span>Cam</span>
          </button>
          <button
            class="src-btn"
            id="btn-both"
            onclick="setMode('both')"
            title="Both [B]"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
            >
              <rect x="2" y="3" width="20" height="14" rx="2" />
              <rect
                x="13"
                y="9"
                width="7"
                height="5"
                rx="1"
                fill="currentColor"
                opacity=".5"
              />
            </svg>
            <span>Both</span>
          </button>
          <button
            class="src-btn"
            id="btn-audio"
            onclick="setMode('audio_only')"
            title="Mic only [A]"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
            >
              <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" />
              <path d="M19 10v2a7 7 0 0 1-14 0v-2m7 9v3m-3 0h6" />
            </svg>
            <span>Mic</span>
          </button>
        </div>

        <div class="vsep"></div>
        <div class="q-wrap">
          <select class="q-sel" id="sel-quality" onchange="onPresetChange()">
            <option value="surveillance">SURV</option>
            <option value="low">LOW</option>
            <option value="medium" selected>MED</option>
            <option value="high">HIGH</option>
            <option value="ultra">ULTRA</option>
          </select>
        </div>
        <div class="vsep"></div>

        <button id="btn-start" onclick="startStream()">
          <svg width="9" height="9" viewBox="0 0 24 24" fill="currentColor">
            <polygon points="5 3 19 12 5 21 5 3" />
          </svg>
          <span>STREAM</span>
        </button>
        <button id="btn-stop" onclick="stopStream()" disabled>
          <svg width="9" height="9" viewBox="0 0 24 24" fill="currentColor">
            <rect x="3" y="3" width="18" height="18" rx="1" />
          </svg>
          <span>STOP</span>
        </button>
        <div class="vsep"></div>
        <button id="btn-auto" onclick="toggleAuto()" title="Autopilot [Q]">
          <div class="auto-dot"></div>
          <span id="btn-auto-txt">AUTO</span>
        </button>

        <div class="grow"></div>

        <!-- Quick command palette -->
        <button
          class="cmd-btn"
          onclick="openPal()"
          title="Command Palette [Ctrl+K]"
        >
          <svg
            width="12"
            height="12"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <circle cx="11" cy="11" r="8" />
            <path d="m21 21-4.35-4.35" />
          </svg>
          <span>Search</span>
          <kbd>⌘K</kbd>
        </button>
        <div class="vsep"></div>

        <button
          class="ib danger"
          id="btn-rec"
          onclick="toggleRecording()"
          title="Record [R]"
        >
          <svg viewBox="0 0 24 24" fill="currentColor">
            <circle cx="12" cy="12" r="7" />
          </svg>
        </button>
        <div class="vsep"></div>
        <button
          class="ib on"
          id="btn-mic"
          onclick="toggleMic()"
          title="Server Mic [M]"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" />
            <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
          </svg>
        </button>
        <button
          class="ib"
          id="btn-talk"
          onclick="toggleClientMic()"
          title="Talk to PC [T]"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z" />
            <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
            <line x1="12" y1="19" x2="12" y2="23" />
            <line x1="8" y1="23" x2="16" y2="23" />
          </svg>
        </button>
        <button
          class="ib on"
          id="btn-spk"
          onclick="toggleSpeaker()"
          title="Speaker [U]"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
            <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
            <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
          </svg>
        </button>
        <div class="vsep"></div>
        <button class="ib" id="btn-hud" onclick="toggleHud()" title="Stats [I]">
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
          </svg>
        </button>
        <button
          class="ib"
          id="btn-lat"
          onclick="toggleLat()"
          title="Latency [L]"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <circle cx="12" cy="12" r="10" />
            <polyline points="12 6 12 12 16 14" />
          </svg>
        </button>
        <button
          class="ib"
          id="btn-fs"
          onclick="toggleFS()"
          title="Fullscreen [F]"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <polyline points="15 3 21 3 21 9" />
            <polyline points="9 21 3 21 3 15" />
            <line x1="21" y1="3" x2="14" y2="10" />
            <line x1="3" y1="21" x2="10" y2="14" />
          </svg>
        </button>
        <button
          class="ib"
          id="btn-shot"
          onclick="takeScreenshot()"
          title="Screenshot [P]"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <path
              d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"
            />
            <circle cx="12" cy="13" r="4" />
          </svg>
        </button>
        <button
          class="ib"
          id="btn-pip-pop"
          onclick="requestPiP()"
          title="Picture-in-Picture"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <rect x="2" y="4" width="20" height="16" rx="2" />
            <rect
              x="12"
              y="12"
              width="8"
              height="6"
              rx="1"
              fill="currentColor"
              opacity=".4"
            />
          </svg>
        </button>
        <div class="vsep"></div>
        <button
          class="theme-btn"
          onclick="toggleTheme()"
          id="btn-theme"
          title="Toggle theme"
        >
          <svg
            id="theme-icon"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
          </svg>
        </button>
        <button
          class="ib"
          id="btn-sc"
          onclick="openShortcuts()"
          title="Shortcuts [?]"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <circle cx="12" cy="12" r="10" />
            <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
            <line x1="12" y1="17" x2="12.01" y2="17" />
          </svg>
        </button>
        <button
          class="ib"
          id="btn-panel"
          onclick="togglePanel()"
          title="Panel [,]"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <line x1="3" y1="6" x2="21" y2="6" />
            <line x1="3" y1="12" x2="21" y2="12" />
            <line x1="3" y1="18" x2="21" y2="18" />
          </svg>
        </button>
      </header>

      <!-- ═══════ STAGE ═══════ -->
      <div id="stage">
        <video id="stream" autoplay playsinline></video>

        <div id="audio-view">
          <canvas id="fs-bars"></canvas>
          <div id="captions-box">
            <div id="captions-text">♪ Audio stream ready</div>
            <div id="captions-sub">LIVE CAPTIONS</div>
            <button
              class="cap-btn"
              id="btn-captions"
              onclick="toggleCaptions()"
            >
              ENABLE CAPTIONS
            </button>
          </div>
        </div>

        <div id="flash"></div>

        <div id="idle">
          <div class="idle-logo">Stream<span>Forge</span></div>
          <div class="idle-sub">Ultra Low Latency · WebRTC · GStreamer</div>
          <div class="idle-actions">
            <div
              class="idle-action"
              onclick="
                setMode('screen');
                startStream();
              "
            >
              <svg
                width="13"
                height="13"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
              >
                <rect x="2" y="3" width="20" height="14" rx="2" />
                <path d="M8 21h8m-4-4v4" />
              </svg>
              Screen <kbd>S</kbd>
            </div>
            <div
              class="idle-action"
              onclick="
                setMode('webcam');
                startStream();
              "
            >
              <svg
                width="13"
                height="13"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
              >
                <path d="M23 7l-7 5 7 5V7z" />
                <rect x="1" y="5" width="15" height="14" rx="2" />
              </svg>
              Webcam <kbd>C</kbd>
            </div>
            <div
              class="idle-action"
              onclick="
                setMode('both');
                startStream();
              "
            >
              <svg
                width="13"
                height="13"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
              >
                <rect x="2" y="3" width="20" height="14" rx="2" />
                <rect
                  x="13"
                  y="9"
                  width="7"
                  height="5"
                  rx="1"
                  fill="currentColor"
                  opacity=".5"
                />
              </svg>
              Screen+Cam <kbd>B</kbd>
            </div>
            <div
              class="idle-action"
              onclick="
                setMode('audio_only');
                startStream();
              "
            >
              <svg
                width="13"
                height="13"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
              >
                <path
                  d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"
                />
                <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
              </svg>
              Audio <kbd>A</kbd>
            </div>
          </div>
          <div class="idle-hint">
            Or press <kbd>SPACE</kbd> to start with current source
          </div>
        </div>

        <!-- HUD -->
        <div id="hud-badge">
          <div class="badge-dot"></div>
          <span id="badge-txt">OFFLINE</span>
        </div>
        <div id="live-tag">
          <div class="rdot"></div>
          LIVE
        </div>
        <div id="rec-tag">
          <div class="rdot"></div>
          <span id="rec-tag-txt">REC 00:00</span>
        </div>
        <div id="hud-stats">
          <span id="hm-fps">— FPS</span>
          <span id="hm-vbr">—</span>
          <span id="hm-res">—</span>
          <span id="hm-rtt">RTT —ms</span>
        </div>
        <div id="lat-display">
          <div class="lat-num" id="lat-num">—</div>
          <div class="lat-lbl">MS LATENCY</div>
        </div>
        <div id="toast"></div>

        <!-- AUTO HUD -->
        <div id="auto-hud">
          <div class="auto-hud-top">
            <div>
              <div class="auto-state-label">AUTOPILOT</div>
              <div class="auto-state-name idle" id="ah-state">IDLE</div>
            </div>
            <div class="score-ring">
              <svg viewBox="0 0 40 40">
                <circle class="ring-bg" cx="20" cy="20" r="17" />
                <circle
                  class="ring-val"
                  id="ah-ring"
                  cx="20"
                  cy="20"
                  r="17"
                  stroke="var(--accent)"
                  stroke-dasharray="106.8"
                  stroke-dashoffset="106.8"
                />
              </svg>
              <div
                class="score-center"
                id="ah-score-num"
                style="color: var(--accent)"
              >
                0
              </div>
            </div>
          </div>
          <div class="auto-hud-level">
            <span class="alb-label">QL</span>
            <div class="alb" id="ah-l0"></div>
            <div class="alb" id="ah-l1"></div>
            <div class="alb" id="ah-l2"></div>
            <div class="alb" id="ah-l3"></div>
            <div class="alb" id="ah-l4"></div>
            <div class="alb" id="ah-l5"></div>
            <div class="alb" id="ah-l6"></div>
          </div>
          <div class="auto-hud-metrics">
            <div class="ahm">RTT <span id="ah-rtt">—</span></div>
            <div class="ahm">LOSS <span id="ah-loss">—</span></div>
            <div class="ahm">FPS <span id="ah-fps">—</span></div>
            <div class="ahm">JITTER <span id="ah-jit">—</span></div>
          </div>
          <div class="auto-hud-reason" id="ah-reason">Waiting for data…</div>
        </div>
      </div>

      <!-- ═══════ STATUS BAR ═══════ -->
      <div id="statusbar">
        <div class="sb-item">
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <circle cx="12" cy="12" r="10" />
            <polyline points="12 6 12 12 16 14" />
          </svg>
          <span id="sb-conn" class="sb-val">OFFLINE</span>
        </div>
        <div class="sb-sep"></div>
        <div class="sb-item">
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
          </svg>
          <span>FPS</span><span id="sb-fps" class="sb-val">—</span>
        </div>
        <div class="sb-item">
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <path
              d="M21.5 2h-19A1.5 1.5 0 0 0 1 3.5v17A1.5 1.5 0 0 0 2.5 22h19a1.5 1.5 0 0 0 1.5-1.5v-17A1.5 1.5 0 0 0 21.5 2z"
            />
            <path d="M1 9h22" />
          </svg>
          <span>VBR</span><span id="sb-vbr" class="sb-val">—</span>
        </div>
        <div class="sb-item">
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <rect x="2" y="3" width="20" height="14" rx="2" />
          </svg>
          <span id="sb-res" class="sb-val">—</span>
        </div>
        <div class="sb-item">
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <path d="M1 6l10.5 6L22 6" />
            <path d="M1 18l10.5-6L22 18" />
          </svg>
          <span>RTT</span><span id="sb-rtt" class="sb-val">—</span>
        </div>
        <div class="sb-sep"></div>
        <div class="sb-item" id="sb-auto-item" style="display: none">
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <path
              d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
            />
          </svg>
          <span>AUTO</span
          ><span id="sb-auto-state" class="sb-val accent">—</span>
        </div>
        <div class="sb-right">
          <div class="sb-hint"><kbd>?</kbd><span>shortcuts</span></div>
          <div class="sb-hint"><kbd>⌘K</kbd><span>commands</span></div>
          <div class="sb-hint"><kbd>SPACE</kbd><span>start/stop</span></div>
        </div>
      </div>

      <!-- ═══════ PANEL ═══════ -->
      <aside id="panel">
        <div class="p-tabs">
          <button class="ptab on" data-tab="live" onclick="setTab('live')">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
            >
              <circle cx="12" cy="12" r="3" />
              <path
                d="M12 1v4M12 19v4M4.22 4.22l2.83 2.83M16.95 16.95l2.83 2.83M1 12h4M19 12h4M4.22 19.78l2.83-2.83M16.95 7.05l2.83-2.83"
              />
            </svg>
            Live
          </button>
          <button
            class="ptab"
            data-tab="auto"
            onclick="setTab('auto')"
            id="ptab-auto"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
            >
              <path
                d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
              />
            </svg>
            Auto
          </button>
          <button class="ptab" data-tab="video" onclick="setTab('video')">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
            >
              <rect x="2" y="3" width="20" height="14" rx="2" />
              <path d="M8 21h8m-4-4v4" />
            </svg>
            Video
          </button>
          <button class="ptab" data-tab="audio" onclick="setTab('audio')">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
            >
              <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
              <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
            </svg>
            Audio
          </button>
          <button class="ptab" data-tab="net" onclick="setTab('net')">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
            >
              <path d="M5 12.55a11 11 0 0 1 14.08 0" />
              <path d="M1.42 9a16 16 0 0 1 21.16 0" />
              <path d="M8.53 16.11a6 6 0 0 1 6.95 0" />
              <circle cx="12" cy="20" r="1" fill="currentColor" />
            </svg>
            Net
          </button>
          <button class="ptab rec-tab" data-tab="rec" onclick="setTab('rec')">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
            >
              <circle cx="12" cy="12" r="6" />
            </svg>
            Rec
          </button>
          <button class="ptab" data-tab="stats" onclick="setTab('stats')">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
            >
              <line x1="18" y1="20" x2="18" y2="10" />
              <line x1="12" y1="20" x2="12" y2="4" />
              <line x1="6" y1="20" x2="6" y2="14" />
            </svg>
            Stats
          </button>
          <button class="ptab" data-tab="log" onclick="setTab('log')">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
            >
              <path
                d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"
              />
            </svg>
            Log
          </button>
        </div>

        <!-- ─── LIVE ─── -->
        <div class="pane on" id="pane-live">
          <div class="sec">
            <div class="sec-hd">Video Bitrate</div>
            <div class="sl-row" id="sl-row-vbr">
              <div class="sl-head">
                <div>
                  <div class="sl-lbl">TARGET BITRATE</div>
                  <div class="sl-sub">Applies live</div>
                </div>
                <div class="sl-val" id="vv">3.0 Mbps</div>
              </div>
              <input
                type="range"
                id="sl-vbr"
                min="100"
                max="15000"
                value="3000"
                step="100"
                oninput="onVbr(this)"
                onchange="sendVbr(this)"
              />
              <div class="chips" id="chips-vbr">
                <div class="chip" onclick="vbrChip(500)">500k</div>
                <div class="chip" onclick="vbrChip(1500)">1.5M</div>
                <div class="chip on" onclick="vbrChip(3000)">3M</div>
                <div class="chip" onclick="vbrChip(6000)">6M</div>
                <div class="chip" onclick="vbrChip(12000)">12M</div>
              </div>
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Frame Rate</div>
            <div class="sl-row" id="sl-row-fps">
              <div class="sl-head">
                <div>
                  <div class="sl-lbl">FPS CAP</div>
                  <div class="sl-sub">May restart pipeline</div>
                </div>
                <div class="sl-val" id="fv">30 fps</div>
              </div>
              <input
                type="range"
                id="sl-fps"
                min="5"
                max="120"
                value="30"
                step="1"
                oninput="onFps(this)"
                onchange="sendFps(this)"
              />
              <div class="chips" id="chips-fps">
                <div class="chip" onclick="fpsChip(15)">15</div>
                <div class="chip" onclick="fpsChip(24)">24</div>
                <div class="chip on" onclick="fpsChip(30)">30</div>
                <div class="chip" onclick="fpsChip(60)">60</div>
                <div class="chip" onclick="fpsChip(120)">120</div>
              </div>
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Audio Bitrate</div>
            <div class="sl-row" id="sl-row-abr">
              <div class="sl-head">
                <div>
                  <div class="sl-lbl">OPUS BITRATE</div>
                  <div class="sl-sub">Applies live</div>
                </div>
                <div class="sl-val" id="av">96 kbps</div>
              </div>
              <input
                type="range"
                id="sl-abr"
                min="6"
                max="320"
                value="96"
                step="2"
                oninput="onAbr(this)"
                onchange="sendAbr(this)"
              />
              <div class="chips" id="chips-abr">
                <div class="chip" onclick="abrChip(32)">32k</div>
                <div class="chip" onclick="abrChip(64)">64k</div>
                <div class="chip on" onclick="abrChip(96)">96k</div>
                <div class="chip" onclick="abrChip(128)">128k</div>
                <div class="chip" onclick="abrChip(192)">192k</div>
              </div>
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Server Mic Volume</div>
            <div class="sl-row" id="sl-row-vol">
              <div class="sl-head">
                <div>
                  <div class="sl-lbl">GAIN</div>
                  <div class="sl-sub">0–200%</div>
                </div>
                <div class="sl-val" id="volv">100%</div>
              </div>
              <input
                type="range"
                id="sl-vol"
                min="0"
                max="200"
                value="100"
                step="1"
                oninput="onVol(this)"
                onchange="sendVol(this)"
              />
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Quality Preset</div>
            <div class="chips" id="preset-chips">
              <div class="chip" onclick="applyPreset('surveillance')">SURV</div>
              <div class="chip" onclick="applyPreset('low')">LOW</div>
              <div class="chip on" onclick="applyPreset('medium')">MED</div>
              <div class="chip" onclick="applyPreset('high')">HIGH</div>
              <div class="chip" onclick="applyPreset('ultra')">ULTRA</div>
            </div>
            <div class="kv" style="margin-top: 4px">
              <span class="k">RESOLUTION</span
              ><span class="v dim" id="res-lbl">1920×1080</span>
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">PiP Position</div>
            <div class="pip-grid">
              <div class="pip-cell" data-pip="top-left" onclick="setPip(this)">
                ↖ Top Left
              </div>
              <div class="pip-cell" data-pip="top-right" onclick="setPip(this)">
                Top Right ↗
              </div>
              <div
                class="pip-cell"
                data-pip="bottom-left"
                onclick="setPip(this)"
              >
                ↙ Bot Left
              </div>
              <div
                class="pip-cell on"
                data-pip="bottom-right"
                onclick="setPip(this)"
              >
                Bot Right ↘
              </div>
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">PiP Size</div>
            <div class="fr-row">
              <div class="fr">
                <label>WIDTH px</label
                ><input
                  type="number"
                  id="pip-w"
                  value="320"
                  min="80"
                  max="1920"
                />
              </div>
              <div class="fr">
                <label>HEIGHT px</label
                ><input
                  type="number"
                  id="pip-h"
                  value="180"
                  min="60"
                  max="1080"
                />
              </div>
            </div>
          </div>
        </div>

        <!-- ─── VIDEO ─── -->
        <div class="pane" id="pane-video">
          <div class="sec">
            <div class="sec-hd">Source</div>
            <div class="fr">
              <label>VIDEO DEVICE</label
              ><input
                type="text"
                id="cfg-vdev"
                value="0"
                placeholder="/dev/video0"
              />
            </div>
            <div class="fr">
              <label>TARGET WINDOW</label>
              <div style="display: flex; gap: 4px">
                <select
                  id="cfg-wintitle"
                  style="flex: 1"
                  onchange="onWindowSelectChange()"
                >
                  <option value="">— click refresh —</option>
                </select>
                <button
                  class="chip"
                  onclick="refreshWindowList()"
                  style="height: 28px; padding: 0 10px"
                >
                  ⟳
                </button>
              </div>
            </div>
            <div class="toggle-row">
              <div>
                <div class="toggle-lbl">SHOW CURSOR</div>
                <div class="toggle-sub">Screen/Window only</div>
              </div>
              <label class="tog"
                ><input type="checkbox" id="tog-cursor" checked /><span
                  class="tslide"
                ></span
              ></label>
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Display</div>
            <div class="chips" id="fit-chips">
              <div class="chip on" onclick="setFit('contain')">CONTAIN</div>
              <div class="chip" onclick="setFit('cover')">COVER</div>
              <div class="chip" onclick="setFit('fill')">FILL</div>
              <div class="chip" onclick="setFit('none')">NONE</div>
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Zoom</div>
            <div class="sl-row" id="sl-row-zoom">
              <div class="sl-head">
                <div><div class="sl-lbl">ZOOM LEVEL</div></div>
                <div class="sl-val" id="zoom-v">100%</div>
              </div>
              <input
                type="range"
                id="sl-zoom"
                min="50"
                max="300"
                value="100"
                step="5"
                oninput="onZoom(this)"
              />
              <div class="chips">
                <div class="chip" onclick="zoomChip(75)">75%</div>
                <div class="chip on" onclick="zoomChip(100)">100%</div>
                <div class="chip" onclick="zoomChip(150)">150%</div>
                <div class="chip" onclick="zoomChip(200)">200%</div>
              </div>
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Image Filters (Local)</div>
            <div class="sl-row">
              <div class="sl-head">
                <div class="sl-lbl">BRIGHTNESS</div>
                <div class="sl-val" id="bright-v">100%</div>
              </div>
              <input
                type="range"
                id="sl-bright"
                min="0"
                max="300"
                value="100"
                step="5"
                oninput="onFilter()"
              />
            </div>
            <div class="sl-row">
              <div class="sl-head">
                <div class="sl-lbl">CONTRAST</div>
                <div class="sl-val" id="contrast-v">100%</div>
              </div>
              <input
                type="range"
                id="sl-contrast"
                min="0"
                max="300"
                value="100"
                step="5"
                oninput="onFilter()"
              />
            </div>
            <div class="sl-row">
              <div class="sl-head">
                <div class="sl-lbl">SATURATION</div>
                <div class="sl-val" id="sat-v">100%</div>
              </div>
              <input
                type="range"
                class="gr"
                id="sl-sat"
                min="0"
                max="300"
                value="100"
                step="5"
                oninput="onFilter()"
              />
            </div>
            <div class="sl-row">
              <div class="sl-head">
                <div class="sl-lbl">HUE ROTATE</div>
                <div class="sl-val" id="hue-v">0°</div>
              </div>
              <input
                type="range"
                class="gr"
                id="sl-hue"
                min="0"
                max="360"
                value="0"
                step="5"
                oninput="onFilter()"
              />
            </div>
            <button class="abtn" onclick="resetFilters()">
              RESET ALL FILTERS
            </button>
          </div>
          <div class="sec">
            <div class="sec-hd">Resolution Override</div>
            <div class="fr-row">
              <div class="fr">
                <label>WIDTH (0=preset)</label
                ><input
                  type="number"
                  id="cfg-cw"
                  value="0"
                  min="0"
                  max="7680"
                />
              </div>
              <div class="fr">
                <label>HEIGHT (0=preset)</label
                ><input
                  type="number"
                  id="cfg-ch"
                  value="0"
                  min="0"
                  max="4320"
                />
              </div>
            </div>
            <div class="fr">
              <label>FPS OVERRIDE (0=preset)</label
              ><input type="number" id="cfg-cfps" value="0" min="0" max="240" />
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Encoder</div>
            <div class="fr">
              <label>PRESET</label
              ><select id="cfg-enc-preset">
                <option value="default">Default (auto)</option>
                <option value="low-latency">Low Latency</option>
                <option value="quality">Quality</option>
                <option value="speed">Speed</option>
              </select>
            </div>
            <div class="fr">
              <label>RATE CONTROL</label
              ><select id="cfg-rcmode">
                <option value="cbr">CBR</option>
                <option value="vbr">VBR</option>
                <option value="cqp">CQP</option>
              </select>
            </div>
            <div class="fr-row">
              <div class="fr">
                <label>GOP SIZE</label
                ><input
                  type="number"
                  id="cfg-gop"
                  value="15"
                  min="1"
                  max="300"
                />
              </div>
              <div class="fr">
                <label>B-FRAMES</label
                ><input type="number" id="cfg-bf" value="0" min="0" max="4" />
              </div>
            </div>
            <div class="fr">
              <label>BITRATE OVERRIDE kbps (0=preset)</label
              ><input
                type="number"
                id="cfg-cvbr"
                value="0"
                min="0"
                max="100000"
              />
            </div>
          </div>
          <button class="abtn" onclick="applyVideoConfig()">
            APPLY VIDEO CONFIG
          </button>
        </div>

        <!-- ─── AUDIO ─── -->
        <div class="pane" id="pane-audio">
          <div class="sec">
            <div class="sec-hd">Local Volume</div>
            <div class="sl-row" id="sl-row-lvol">
              <div class="sl-head">
                <div>
                  <div class="sl-lbl">LOCAL GAIN</div>
                  <div class="sl-sub">Client-side · 0–200%</div>
                </div>
                <div class="sl-val green" id="local-vol-v">100%</div>
              </div>
              <input
                type="range"
                class="gr"
                id="sl-local-vol"
                min="0"
                max="200"
                value="100"
                step="1"
                oninput="onLocalVol(this)"
              />
              <div class="chips" id="chips-lvol">
                <div class="chip green" onclick="localVolChip(0)">Mute</div>
                <div class="chip green on" onclick="localVolChip(100)">
                  100%
                </div>
                <div class="chip green" onclick="localVolChip(150)">150%</div>
                <div class="chip green" onclick="localVolChip(200)">200%</div>
              </div>
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Visualizer</div>
            <canvas id="viz-canvas"></canvas>
            <div class="toggle-row">
              <div>
                <div class="toggle-lbl">VISUALIZER</div>
                <div class="toggle-sub">CPU when active</div>
              </div>
              <label class="tog"
                ><input
                  type="checkbox"
                  id="tog-viz"
                  onchange="toggleViz(this.checked)" /><span
                  class="tslide"
                ></span
              ></label>
            </div>
            <div class="fr">
              <label>STYLE</label
              ><select id="viz-style" onchange="S.vizStyle = this.value">
                <option value="bars">Bars</option>
                <option value="wave">Waveform</option>
                <option value="circle">Circle</option>
              </select>
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Audio Device</div>
            <div class="fr">
              <label>DEVICE ID / NAME</label
              ><input
                type="text"
                id="cfg-adev"
                value=""
                placeholder="default (leave empty)"
              />
            </div>
            <div class="fr" id="adev-list-wrap" style="display: none">
              <label>DETECTED DEVICES</label
              ><select
                id="adev-list"
                onchange="
                  document.getElementById('cfg-adev').value = this.value
                "
              >
                <option value="">— select —</option>
              </select>
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Channels &amp; Sample Rate</div>
            <div class="fr-row">
              <div class="fr">
                <label>CHANNELS</label
                ><select id="cfg-ach">
                  <option value="1" selected>Mono</option>
                  <option value="2">Stereo</option>
                </select>
              </div>
              <div class="fr">
                <label>SAMPLE RATE</label
                ><select id="cfg-arate">
                  <option value="16000">16 kHz</option>
                  <option value="32000">32 kHz</option>
                  <option value="44100">44.1 kHz</option>
                  <option value="48000" selected>48 kHz</option>
                </select>
              </div>
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Opus Codec</div>
            <div class="fr">
              <label>AUDIO TYPE</label
              ><select id="cfg-opus-type">
                <option value="voice" selected>Voice</option>
                <option value="music">Music / Generic</option>
                <option value="restricted-lowdelay">
                  Restricted Low-Delay
                </option>
              </select>
            </div>
            <div class="fr">
              <label>FRAME SIZE ms</label
              ><select id="cfg-opus-frame">
                <option value="2.5">2.5</option>
                <option value="5">5</option>
                <option value="10" selected>10</option>
                <option value="20">20</option>
                <option value="40">40</option>
                <option value="60">60</option>
              </select>
            </div>
            <div class="fr">
              <label>BITRATE OVERRIDE kbps (0=preset)</label
              ><input type="number" id="cfg-cabr" value="0" min="0" max="512" />
            </div>
            <div class="toggle-row">
              <div>
                <div class="toggle-lbl">INBAND FEC</div>
                <div class="toggle-sub">Forward error correction</div>
              </div>
              <label class="tog"
                ><input type="checkbox" id="tog-fec" checked /><span
                  class="tslide"
                ></span
              ></label>
            </div>
            <div class="toggle-row">
              <div>
                <div class="toggle-lbl">DTX</div>
                <div class="toggle-sub">Discontinuous transmission</div>
              </div>
              <label class="tog"
                ><input type="checkbox" id="tog-dtx" /><span
                  class="tslide"
                ></span
              ></label>
            </div>
            <div class="toggle-row">
              <div>
                <div class="toggle-lbl">LOOPBACK MODE</div>
                <div class="toggle-sub">Capture speaker output</div>
              </div>
              <label class="tog"
                ><input type="checkbox" id="tog-loopback" /><span
                  class="tslide"
                ></span
              ></label>
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">DSP Processing</div>
            <div
              id="dsp-warn"
              style="
                font-size: 9px;
                color: var(--amber);
                display: none;
                padding: 3px 0;
              "
            >
              ⚠ webrtcdsp not available
            </div>
            <div class="toggle-row">
              <div><div class="toggle-lbl">NOISE SUPPRESSION</div></div>
              <label class="tog"
                ><input type="checkbox" id="tog-ns" /><span
                  class="tslide"
                ></span
              ></label>
            </div>
            <div class="toggle-row">
              <div><div class="toggle-lbl">ECHO CANCELLATION</div></div>
              <label class="tog"
                ><input type="checkbox" id="tog-ec" /><span
                  class="tslide"
                ></span
              ></label>
            </div>
          </div>
          <button class="abtn" onclick="applyAudioConfig()">
            APPLY AUDIO CONFIG
          </button>
        </div>

        <!-- ─── NETWORK ─── -->
        <div class="pane" id="pane-net">
          <div class="sec">
            <div class="sec-hd">ICE / STUN / TURN</div>
            <div class="fr">
              <label>STUN SERVER</label
              ><input
                type="text"
                id="cfg-stun"
                placeholder="stun://stun.l.google.com:19302"
              />
            </div>
            <div class="fr">
              <label>TURN SERVER (optional)</label
              ><input
                type="text"
                id="cfg-turn"
                placeholder="turn://user:pass@host:3478"
              />
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Latency &amp; Buffering</div>
            <div class="sl-row">
              <div class="sl-head">
                <div>
                  <div class="sl-lbl">WEBRTCBIN LATENCY</div>
                  <div class="sl-sub">Jitter buffer ms</div>
                </div>
                <div class="sl-val" id="latms-v">0 ms</div>
              </div>
              <input
                type="range"
                id="sl-latms"
                min="0"
                max="500"
                value="0"
                step="10"
                oninput="onLatMs(this)"
              />
              <div class="chips" id="chips-latms">
                <div class="chip on" onclick="latMsChip(0)">0ms</div>
                <div class="chip" onclick="latMsChip(50)">50ms</div>
                <div class="chip" onclick="latMsChip(100)">100ms</div>
                <div class="chip" onclick="latMsChip(200)">200ms</div>
              </div>
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Auto-Reconnect</div>
            <div class="toggle-row">
              <div><div class="toggle-lbl">AUTO RECONNECT</div></div>
              <label class="tog"
                ><input type="checkbox" id="tog-autorecon" checked /><span
                  class="tslide"
                ></span
              ></label>
            </div>
            <div class="sl-row">
              <div class="sl-head">
                <div>
                  <div class="sl-lbl">RETRY INTERVAL</div>
                  <div class="sl-sub">Seconds</div>
                </div>
                <div class="sl-val" id="recon-int-v">5 s</div>
              </div>
              <input
                type="range"
                id="sl-recon-int"
                min="1"
                max="30"
                value="5"
                step="1"
                oninput="onReconInt(this)"
              />
            </div>
            <div class="kv">
              <span class="k">RETRY COUNT</span
              ><span class="v" id="recon-count">0</span>
            </div>
            <div class="kv">
              <span class="k">STATUS</span
              ><span class="v" id="recon-status">—</span>
            </div>
            <button class="abtn" onclick="reconnect()">RECONNECT NOW</button>
          </div>
          <div class="sec">
            <div class="sec-hd">Server</div>
            <div class="fr">
              <label>SERVER URL (blank = auto)</label
              ><input
                type="text"
                id="cfg-server"
                placeholder="ws://localhost:8080/ws"
              />
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Server Info</div>
            <div class="kv">
              <span class="k">PEER ID</span
              ><span class="v dim" id="n-peer">—</span>
            </div>
            <div class="kv">
              <span class="k">PLATFORM</span
              ><span class="v dim" id="n-plat">—</span>
            </div>
            <div class="kv">
              <span class="k">GSTREAMER</span
              ><span class="v dim" id="n-gst">—</span>
            </div>
            <div class="kv">
              <span class="k">ENCODER</span
              ><span class="v dim" id="n-enc">—</span>
            </div>
            <div class="kv">
              <span class="k">SCREEN SRC</span
              ><span class="v dim" id="n-scr">—</span>
            </div>
            <div class="kv">
              <span class="k">CAM SRC</span
              ><span class="v dim" id="n-cam">—</span>
            </div>
            <div class="kv">
              <span class="k">AUDIO SRC</span
              ><span class="v dim" id="n-aud">—</span>
            </div>
            <div class="kv">
              <span class="k">STUN</span
              ><span class="v dim" id="n-stun">—</span>
            </div>
            <div class="kv">
              <span class="k">webrtcdsp</span
              ><span class="v dim" id="n-dsp">—</span>
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Advanced Property</div>
            <div class="fr">
              <label>ELEMENT</label
              ><input type="text" id="adv-elem" placeholder="vencoder" />
            </div>
            <div class="fr">
              <label>PROPERTY</label
              ><input type="text" id="adv-prop" placeholder="bitrate" />
            </div>
            <div class="fr">
              <label>VALUE</label
              ><input type="text" id="adv-val" placeholder="3000" />
            </div>
            <button class="abtn" onclick="sendAdv()">SET PROPERTY</button>
          </div>
        </div>

        <!-- ─── REC ─── -->
        <div class="pane" id="pane-rec">
          <div class="sec">
            <div class="rec-status-lbl" id="rec-status-lbl">STOPPED</div>
            <div class="rec-timer-display" id="rec-timer">00:00</div>
            <button
              class="abtn red"
              id="rec-main-btn"
              onclick="toggleRecording()"
            >
              ⏺ START RECORDING
            </button>
          </div>
          <div class="sec">
            <div class="sec-hd">Format &amp; Quality</div>
            <div class="fr">
              <label>CONTAINER</label
              ><select id="rec-fmt">
                <option value="video/webm;codecs=vp9,opus">
                  WebM VP9+Opus (best)
                </option>
                <option value="video/webm;codecs=vp8,opus">
                  WebM VP8+Opus (compat)
                </option>
                <option value="video/webm">WebM (auto)</option>
                <option value="video/mp4">MP4 (if supported)</option>
              </select>
            </div>
            <div class="sl-row">
              <div class="sl-head">
                <div>
                  <div class="sl-lbl">RECORD BITRATE</div>
                  <div class="sl-sub">MediaRecorder target</div>
                </div>
                <div class="sl-val red" id="rec-bps-v">8 Mbps</div>
              </div>
              <input
                type="range"
                class="rr"
                id="sl-rec-bps"
                min="1"
                max="50"
                value="8"
                step="1"
                oninput="onRecBps(this)"
              />
              <div class="chips" id="chips-recbps">
                <div class="chip" onclick="recBpsChip(2)">2M</div>
                <div class="chip" onclick="recBpsChip(5)">5M</div>
                <div class="chip on" onclick="recBpsChip(8)">8M</div>
                <div class="chip" onclick="recBpsChip(15)">15M</div>
                <div class="chip" onclick="recBpsChip(25)">25M</div>
              </div>
            </div>
            <div class="toggle-row">
              <div>
                <div class="toggle-lbl">AUTO-SPLIT</div>
                <div class="toggle-sub">Split every N minutes</div>
              </div>
              <label class="tog"
                ><input type="checkbox" id="tog-rec-split" /><span
                  class="tslide red"
                ></span
              ></label>
            </div>
            <div class="fr">
              <label>SPLIT INTERVAL (min)</label
              ><input
                type="number"
                id="rec-split-min"
                value="10"
                min="1"
                max="120"
              />
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">
              Recordings
              <button class="chip" onclick="clearSegments()">CLEAR</button>
            </div>
            <div id="rec-segs">
              <div
                style="
                  font-size: 10px;
                  color: var(--t3);
                  padding: 12px 0;
                  text-align: center;
                "
              >
                No recordings yet
              </div>
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Stats</div>
            <div class="kv">
              <span class="k">SEGMENTS</span
              ><span class="v red" id="rec-seg-count">0</span>
            </div>
            <div class="kv">
              <span class="k">TOTAL DURATION</span
              ><span class="v red" id="rec-total-dur">0:00</span>
            </div>
            <div class="kv">
              <span class="k">ESTIMATED SIZE</span
              ><span class="v dim" id="rec-est-size">—</span>
            </div>
          </div>
        </div>

        <!-- ─── STATS ─── -->
        <div class="pane" id="pane-stats">
          <div class="sec">
            <div class="sec-hd">Connection</div>
            <div class="kv">
              <span class="k">STATUS</span><span class="v" id="st-conn">—</span>
            </div>
            <div class="kv">
              <span class="k">ICE STATE</span
              ><span class="v" id="st-ice">—</span>
            </div>
            <div class="kv">
              <span class="k">WS LATENCY</span
              ><span class="v" id="st-wslat">—</span>
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Video RX</div>
            <div class="kv">
              <span class="k">FPS</span><span class="v" id="st-fps">—</span>
            </div>
            <div class="kv">
              <span class="k">BITRATE</span><span class="v" id="st-vbr">—</span>
            </div>
            <div class="kv">
              <span class="k">RESOLUTION</span
              ><span class="v" id="st-res">—</span>
            </div>
            <div class="kv">
              <span class="k">CODEC</span
              ><span class="v dim" id="st-codec">—</span>
            </div>
            <div class="kv">
              <span class="k">PACKETS LOST</span
              ><span class="v warn" id="st-lost">—</span>
            </div>
            <div class="kv">
              <span class="k">FRAMES DECODED</span
              ><span class="v dim" id="st-frames">—</span>
            </div>
            <div class="kv">
              <span class="k">BYTES RX</span
              ><span class="v dim" id="st-bytes">—</span>
            </div>
            <canvas class="spark" id="spark" style="margin-top: 8px"></canvas>
          </div>
          <div class="sec">
            <div class="sec-hd">Audio RX</div>
            <div class="kv">
              <span class="k">BITRATE</span><span class="v" id="st-abr">—</span>
            </div>
            <div class="kv">
              <span class="k">JITTER</span><span class="v" id="st-jit">—</span>
            </div>
          </div>
          <div class="sec">
            <div class="sec-hd">Network</div>
            <div class="kv">
              <span class="k">RTT</span><span class="v" id="st-rtt">—</span>
            </div>
            <div class="kv">
              <span class="k">LATENCY</span><span class="v" id="st-lat">—</span>
            </div>
          </div>
        </div>

        <!-- ─── LOG ─── -->
        <div class="pane" id="pane-log">
          <div class="sec">
            <div class="sec-hd">
              Event Log <button class="chip" onclick="clearLog()">CLEAR</button>
            </div>
            <div id="logbox"></div>
          </div>
        </div>
      </aside>
    </div>

    <script>
      'use strict';

      // ═══════════════════════════════════════════
      //  CONFIG
      // ═══════════════════════════════════════════
      const CONFIG = {
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:stun1.l.google.com:19302' },
        ],
        presets: {
          surveillance: { w: 640, h: 360, fps: 15, vbr: 500, abr: 32 },
          low: { w: 1280, h: 720, fps: 24, vbr: 1500, abr: 64 },
          medium: { w: 1920, h: 1080, fps: 30, vbr: 3000, abr: 96 },
          high: { w: 1920, h: 1080, fps: 60, vbr: 6000, abr: 128 },
          ultra: { w: 2560, h: 1440, fps: 60, vbr: 12000, abr: 192 },
        },
      };

      // ═══════════════════════════════════════════
      //  STATE
      // ═══════════════════════════════════════════
      const S = {
        ws: null,
        pc: null,
        peerId: null,
        mode: 'screen',
        quality: 'medium',
        micOn: true,
        spkOn: true,
        clientMicTrack: null,
        streaming: false,
        hudOn: false,
        latOn: false,
        panelOn: false,
        activeTab: 'live',
        pipPos: 'bottom-right',
        vbrK: 3000,
        fpsV: 30,
        abrK: 96,
        volPct: 100,
        latMsV: 0,
        zoomPct: 100,
        fitMode: 'contain',
        filterBright: 100,
        filterContrast: 100,
        filterSat: 100,
        filterHue: 0,
        audioCtx: null,
        gainNode: null,
        analyser: null,
        _audioSrc: null,
        localVolPct: 100,
        vizOn: false,
        vizStyle: 'bars',
        vizRaf: null,
        fsVizRaf: null,
        mediaRecorder: null,
        recChunks: [],
        recStartTime: 0,
        recTimerInterval: null,
        recSplitTimer: null,
        recSegments: [],
        recBpsMbps: 8,
        recTotalSeconds: 0,
        autoRecon: true,
        reconIntSec: 5,
        reconCount: 0,
        reconTimer: null,
        speechRec: null,
        speechOn: false,
        latTmr: null,
        statsTmr: null,
        prevStats: {},
        sparkData: [],
        autoProfile: null,
        autoOn: false,
      };

      // ═══════════════════════════════════════════
      //  UTILS
      // ═══════════════════════════════════════════
      const $ = (id) => document.getElementById(id);
      const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
      const fmtK = (k) =>
        k >= 1000 ? `${(k / 1000).toFixed(1)} Mbps` : `${k} kbps`;
      const fmtB = (b) =>
        b > 1e9
          ? `${(b / 1e9).toFixed(2)} GB`
          : b > 1e6
            ? `${(b / 1e6).toFixed(1)} MB`
            : `${Math.round(b / 1e3)} KB`;
      const fmtTime = (s) =>
        `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

      function fill(el) {
        const pct = ((el.value - el.min) / (el.max - el.min)) * 100;
        el.style.setProperty('--pct', pct + '%');
      }
      function log(msg, cls = 'info') {
        const box = $('logbox');
        const ts = new Date().toLocaleTimeString('en', { hour12: false });
        const el = document.createElement('span');
        el.className = 'le ' + cls;
        el.textContent = `[${ts}] ${msg}`;
        box.appendChild(el);
        box.scrollTop = box.scrollHeight;
      }
      function clearLog() {
        $('logbox').innerHTML = '';
      }
      function setBadge(state, text) {
        $('hud-badge').className = state;
        $('badge-txt').textContent = text;
      }
      function showLive(on) {
        $('live-tag').classList.toggle('on', on);
      }
      function toast(msg, type = '', ms = 3200) {
        const el = $('toast');
        el.textContent = msg;
        el.className = `show${type ? ' ' + type : ''}`;
        clearTimeout(el._t);
        el._t = setTimeout(() => (el.className = ''), ms);
      }
      function ack(rowId) {
        const el = $(rowId);
        if (!el) return;
        el.classList.add('ack');
        setTimeout(() => el.classList.remove('ack'), 600);
      }

      // Status bar update
      function updateStatusBar(fps, vbr, res, rtt) {
        const fpsel = $('sb-fps'),
          vbrel = $('sb-vbr'),
          resel = $('sb-res'),
          rttel = $('sb-rtt');
        if (fpsel) fpsel.textContent = fps ? `${fps} fps` : '—';
        if (vbrel) vbrel.textContent = vbr ? fmtK(vbr) : '—';
        if (resel) resel.textContent = res || '—';
        if (rttel) {
          rttel.textContent = rtt ? `${rtt}ms` : '—';
          rttel.className = `sb-val ${rtt < 30 ? 'green' : rtt < 80 ? 'accent' : 'amber'}`;
        }
      }
      function setSbConn(text, cls = '') {
        const el = $('sb-conn');
        if (!el) return;
        el.textContent = text;
        el.className = `sb-val ${cls}`;
      }

      // ═══════════════════════════════════════════
      //  THEME
      // ═══════════════════════════════════════════
      let currentTheme = 'dark';
      function toggleTheme() {
        currentTheme = currentTheme === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', currentTheme);
        const icon = $('theme-icon');
        if (currentTheme === 'light') {
          icon.innerHTML =
            '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>';
        } else {
          icon.innerHTML =
            '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>';
        }
        toast(`${currentTheme === 'light' ? 'Light' : 'Dark'} theme`, '', 1500);
      }

      // ═══════════════════════════════════════════
      //  COMMAND PALETTE
      // ═══════════════════════════════════════════
      const COMMANDS = [
        {
          group: 'Stream',
          name: 'Start Streaming',
          desc: 'Begin capturing & streaming',
          kbd: 'SPACE',
          icon: '▶',
          action: () => startStream(),
        },
        {
          group: 'Stream',
          name: 'Stop Streaming',
          desc: 'Stop the current stream',
          kbd: 'ESC',
          icon: '⏹',
          action: () => stopStream(),
        },
        {
          group: 'Stream',
          name: 'Toggle Autopilot',
          desc: 'Enable/disable network adaptation',
          kbd: 'Q',
          icon: '★',
          action: () => toggleAuto(),
        },
        {
          group: 'Stream',
          name: 'Toggle Recording',
          desc: 'Start or stop recording',
          kbd: 'R',
          icon: '⏺',
          action: () => toggleRecording(),
        },
        {
          group: 'Source',
          name: 'Screen Capture',
          desc: 'Capture full screen',
          kbd: 'S',
          icon: '🖥',
          action: () => setMode('screen'),
        },
        {
          group: 'Source',
          name: 'Window Capture',
          desc: 'Capture a specific window',
          kbd: 'W',
          icon: '⬜',
          action: () => setMode('window'),
        },
        {
          group: 'Source',
          name: 'Webcam',
          desc: 'Use webcam as source',
          kbd: 'C',
          icon: '📷',
          action: () => setMode('webcam'),
        },
        {
          group: 'Source',
          name: 'Screen + Cam',
          desc: 'Screen with webcam overlay',
          kbd: 'B',
          icon: '⊞',
          action: () => setMode('both'),
        },
        {
          group: 'Source',
          name: 'Audio Only',
          desc: 'Microphone only',
          kbd: 'A',
          icon: '🎙',
          action: () => setMode('audio_only'),
        },
        {
          group: 'Preset',
          name: 'Preset: Surveillance',
          desc: '640×360 @15fps 500kbps',
          icon: '👁',
          action: () => applyPreset('surveillance'),
        },
        {
          group: 'Preset',
          name: 'Preset: Low',
          desc: '720p @24fps 1.5Mbps',
          icon: '📉',
          action: () => applyPreset('low'),
        },
        {
          group: 'Preset',
          name: 'Preset: Medium',
          desc: '1080p @30fps 3Mbps',
          icon: '📊',
          action: () => applyPreset('medium'),
        },
        {
          group: 'Preset',
          name: 'Preset: High',
          desc: '1080p @60fps 6Mbps',
          icon: '📈',
          action: () => applyPreset('high'),
        },
        {
          group: 'Preset',
          name: 'Preset: Ultra',
          desc: '1440p @60fps 12Mbps',
          icon: '🚀',
          action: () => applyPreset('ultra'),
        },
        {
          group: 'Audio',
          name: 'Toggle Server Mic',
          desc: 'Enable/disable server microphone',
          kbd: 'M',
          icon: '🎤',
          action: () => toggleMic(),
        },
        {
          group: 'Audio',
          name: 'Talk to PC',
          desc: 'Enable client microphone to PC',
          kbd: 'T',
          icon: '💬',
          action: () => toggleClientMic(),
        },
        {
          group: 'Audio',
          name: 'Toggle Speaker',
          desc: 'Enable/disable audio playback',
          kbd: 'U',
          icon: '🔊',
          action: () => toggleSpeaker(),
        },
        {
          group: 'View',
          name: 'Toggle Fullscreen',
          desc: 'Enter/exit fullscreen',
          kbd: 'F',
          icon: '⛶',
          action: () => toggleFS(),
        },
        {
          group: 'View',
          name: 'Stats Overlay',
          desc: 'Show FPS/bitrate on stage',
          kbd: 'I',
          icon: '📊',
          action: () => toggleHud(),
        },
        {
          group: 'View',
          name: 'Latency Meter',
          desc: 'Show RTT on stage',
          kbd: 'L',
          icon: '⏱',
          action: () => toggleLat(),
        },
        {
          group: 'View',
          name: 'Screenshot',
          desc: 'Save current frame as PNG',
          kbd: 'P',
          icon: '📸',
          action: () => takeScreenshot(),
        },
        {
          group: 'View',
          name: 'Picture-in-Picture',
          desc: 'Float video in PiP window',
          icon: '⊡',
          action: () => requestPiP(),
        },
        {
          group: 'View',
          name: 'Toggle Panel',
          desc: 'Open/close settings panel',
          kbd: ',',
          icon: '☰',
          action: () => togglePanel(),
        },
        {
          group: 'View',
          name: 'Toggle Theme',
          desc: 'Switch light/dark theme',
          icon: '◐',
          action: () => toggleTheme(),
        },
        {
          group: 'Panel',
          name: 'Open: Live Controls',
          desc: 'Bitrate, FPS, audio sliders',
          icon: '🎛',
          action: () => {
            openPanel();
            setTab('live');
          },
        },
        {
          group: 'Panel',
          name: 'Open: Autopilot',
          desc: 'Network adaptation settings',
          icon: '★',
          action: () => {
            openPanel();
            setTab('auto');
          },
        },
        {
          group: 'Panel',
          name: 'Open: Stats',
          desc: 'Detailed stream statistics',
          icon: '📈',
          action: () => {
            openPanel();
            setTab('stats');
          },
        },
        {
          group: 'Panel',
          name: 'Open: Recording',
          desc: 'Recording controls and segments',
          icon: '⏺',
          action: () => {
            openPanel();
            setTab('rec');
          },
        },
        {
          group: 'Network',
          name: 'Reconnect',
          desc: 'Reconnect to server now',
          icon: '↺',
          action: () => reconnect(),
        },
        {
          group: 'Network',
          name: 'Shortcuts Help',
          desc: 'Show all keyboard shortcuts',
          kbd: '?',
          icon: '?',
          action: () => openShortcuts(),
        },
      ];

      let palIndex = 0,
        palFiltered = COMMANDS;

      function openPal() {
        $('cmdpal').classList.add('on');
        $('pal-input').value = '';
        palFiltered = COMMANDS;
        palIndex = 0;
        renderPal(COMMANDS);
        setTimeout(() => $('pal-input').focus(), 50);
      }
      function closePal() {
        $('cmdpal').classList.remove('on');
      }
      function filterPal(q) {
        if (!q.trim()) {
          palFiltered = COMMANDS;
          palIndex = 0;
          renderPal(COMMANDS);
          return;
        }
        const lq = q.toLowerCase();
        palFiltered = COMMANDS.filter(
          (c) =>
            c.name.toLowerCase().includes(lq) ||
            c.desc.toLowerCase().includes(lq) ||
            (c.kbd && c.kbd.toLowerCase().includes(lq)) ||
            c.group.toLowerCase().includes(lq),
        );
        palIndex = 0;
        renderPal(palFiltered);
      }
      function renderPal(cmds) {
        const box = $('pal-results');
        if (!cmds.length) {
          box.innerHTML = '<div class="pal-empty">No commands found</div>';
          return;
        }
        const groups = {};
        cmds.forEach((c, i) => {
          if (!groups[c.group]) groups[c.group] = [];
          groups[c.group].push({ ...c, idx: i });
        });
        let html = '';
        Object.entries(groups).forEach(([g, items]) => {
          html += `<div class="pal-group-label">${g}</div>`;
          items.forEach((c) => {
            html += `<div class="pal-item${c.idx === palIndex ? ' selected' : ''}" onclick="execCmd(${c.idx})">
        <div class="pal-item-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><circle cx="12" cy="12" r="10"/></svg></div>
        <div class="pal-item-name">${c.name}</div>
        <div class="pal-item-desc">${c.desc}</div>
        ${c.kbd ? `<span class="pal-item-kbd">${c.kbd}</span>` : ''}
      </div>`;
          });
        });
        box.innerHTML = html;
      }
      function execCmd(idx) {
        const c = palFiltered[idx];
        if (c) {
          closePal();
          c.action();
        }
      }
      function palKey(e) {
        if (e.key === 'Escape') {
          closePal();
          return;
        }
        if (e.key === 'ArrowDown') {
          palIndex = Math.min(palIndex + 1, palFiltered.length - 1);
          renderPal(palFiltered);
          scrollPalSelected();
          return;
        }
        if (e.key === 'ArrowUp') {
          palIndex = Math.max(palIndex - 1, 0);
          renderPal(palFiltered);
          scrollPalSelected();
          return;
        }
        if (e.key === 'Enter') {
          execCmd(palIndex);
        }
      }
      function scrollPalSelected() {
        const sel = document.querySelector('.pal-item.selected');
        if (sel) sel.scrollIntoView({ block: 'nearest' });
      }
      function openPanel() {
        if (!S.panelOn) togglePanel();
      }

      // ═══════════════════════════════════════════
      //  SHORTCUTS OVERLAY
      // ═══════════════════════════════════════════
      function openShortcuts() {
        $('shortcuts-overlay').classList.add('on');
      }
      function closeShortcuts() {
        $('shortcuts-overlay').classList.remove('on');
      }

      // ═══════════════════════════════════════════
      //  DISPLAY
      // ═══════════════════════════════════════════
      function setFit(mode) {
        S.fitMode = mode;
        $('stream').style.objectFit = mode;
        document
          .querySelectorAll('#fit-chips .chip')
          .forEach((c) =>
            c.classList.toggle(
              'on',
              c.textContent.trim().toLowerCase() === mode,
            ),
          );
        log(`Fit → ${mode}`);
      }
      function onZoom(el) {
        S.zoomPct = +el.value;
        $('zoom-v').textContent = `${S.zoomPct}%`;
        fill(el);
        $('stream').style.transform =
          S.zoomPct !== 100 ? `scale(${S.zoomPct / 100})` : '';
      }
      function zoomChip(v) {
        $('sl-zoom').value = v;
        onZoom($('sl-zoom'));
      }
      function onFilter() {
        S.filterBright = +$('sl-bright').value;
        S.filterContrast = +$('sl-contrast').value;
        S.filterSat = +$('sl-sat').value;
        S.filterHue = +$('sl-hue').value;
        $('bright-v').textContent = `${S.filterBright}%`;
        $('contrast-v').textContent = `${S.filterContrast}%`;
        $('sat-v').textContent = `${S.filterSat}%`;
        $('hue-v').textContent = `${S.filterHue}°`;
        [$('sl-bright'), $('sl-contrast'), $('sl-sat'), $('sl-hue')].forEach(
          fill,
        );
        $('stream').style.filter =
          `brightness(${S.filterBright}%) contrast(${S.filterContrast}%) saturate(${S.filterSat}%) hue-rotate(${S.filterHue}deg)`;
      }
      function resetFilters() {
        ['sl-bright', 'sl-contrast', 'sl-sat'].forEach(
          (id) => ($(id).value = 100),
        );
        $('sl-hue').value = 0;
        onFilter();
        toast('Filters reset', 'ok', 1500);
      }

      // ═══════════════════════════════════════════
      //  PiP + SCREENSHOT
      // ═══════════════════════════════════════════
      async function requestPiP() {
        const vid = $('stream');
        if (!vid.srcObject) {
          toast('No stream active');
          return;
        }
        try {
          if (document.pictureInPictureElement) {
            await document.exitPictureInPicture();
            log('PiP closed');
          } else {
            await vid.requestPictureInPicture();
            log('PiP opened', 'ok');
            toast('PiP active', 'ok', 2000);
          }
        } catch (e) {
          toast('PiP: ' + e.message);
          log('PiP: ' + e.message, 'err');
        }
      }
      function takeScreenshot() {
        const vid = $('stream');
        if (!vid.srcObject && vid.videoWidth === 0) {
          toast('No video');
          return;
        }
        const c = document.createElement('canvas');
        c.width = vid.videoWidth || 1920;
        c.height = vid.videoHeight || 1080;
        const ctx = c.getContext('2d');
        ctx.filter = $('stream').style.filter || 'none';
        ctx.drawImage(vid, 0, 0);
        const flash = $('flash');
        flash.classList.add('pop');
        setTimeout(() => flash.classList.remove('pop'), 160);
        c.toBlob((blob) => {
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `streamforge_${Date.now()}.png`;
          a.click();
          URL.revokeObjectURL(url);
          toast('Screenshot saved', 'ok', 2000);
          log('Screenshot saved', 'ok');
        }, 'image/png');
      }

      // ═══════════════════════════════════════════
      //  WEB AUDIO + VISUALIZER
      // ═══════════════════════════════════════════
      function initAudioCtx() {
        if (S.audioCtx) return;
        try {
          S.audioCtx = new (window.AudioContext || window.webkitAudioContext)();
          S.gainNode = S.audioCtx.createGain();
          S.analyser = S.audioCtx.createAnalyser();
          S.analyser.fftSize = 256;
          S.gainNode.connect(S.analyser);
          S.analyser.connect(S.audioCtx.destination);
          log('Web Audio initialized', 'ok');
        } catch (e) {
          log('Web Audio: ' + e.message, 'warn');
        }
      }
      function connectAudioToStream() {
        const vid = $('stream');
        if (!vid.srcObject || !S.audioCtx) return;
        if (S._audioSrc)
          try {
            S._audioSrc.disconnect();
          } catch (e) {}
        try {
          S._audioSrc = S.audioCtx.createMediaStreamSource(vid.srcObject);
          S._audioSrc.connect(S.gainNode);
          vid.muted = true;
          vid.volume = 0;
        } catch (e) {
          log('Audio connect: ' + e, 'warn');
        }
      }
      function onLocalVol(el) {
        S.localVolPct = +el.value;
        $('local-vol-v').textContent = `${S.localVolPct}%`;
        fill(el);
        if (S.gainNode)
          S.gainNode.gain.setTargetAtTime(
            S.localVolPct / 100,
            S.audioCtx.currentTime,
            0.01,
          );
      }
      function localVolChip(v) {
        $('sl-local-vol').value = v;
        onLocalVol($('sl-local-vol'));
        chipSet('chips-lvol', v);
      }
      function toggleViz(on) {
        S.vizOn = on;
        if (on) {
          initAudioCtx();
          connectAudioToStream();
          startViz();
        } else stopViz();
      }
      function startViz() {
        stopViz();
        if (!S.analyser) return;
        drawViz($('viz-canvas'));
      }
      function stopViz() {
        if (S.vizRaf) {
          cancelAnimationFrame(S.vizRaf);
          S.vizRaf = null;
        }
      }
      function drawViz(canvas) {
        const ctx = canvas.getContext('2d');
        const W = canvas.offsetWidth || 320,
          H = 52;
        canvas.width = W;
        canvas.height = H;
        if (!S.analyser || !S.vizOn) {
          ctx.clearRect(0, 0, W, H);
          return;
        }
        const bufLen = S.analyser.frequencyBinCount;
        const data = new Uint8Array(bufLen);
        function frame() {
          S.vizRaf = requestAnimationFrame(frame);
          ctx.clearRect(0, 0, W, H);
          if (S.vizStyle === 'bars') {
            S.analyser.getByteFrequencyData(data);
            const bW = (W / bufLen) * 2.5;
            let x = 0;
            for (let i = 0; i < bufLen; i++) {
              const v = data[i] / 255,
                bH = v * H;
              ctx.fillStyle = `hsla(${165 + (i / bufLen) * 40},100%,55%,${0.3 + v * 0.7})`;
              ctx.fillRect(x, H - bH, bW - 1, bH);
              x += bW + 1;
            }
          } else if (S.vizStyle === 'wave') {
            S.analyser.getByteTimeDomainData(data);
            ctx.strokeStyle = 'rgba(0,212,168,0.7)';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            const sw = W / bufLen;
            let x = 0;
            for (let i = 0; i < bufLen; i++) {
              const y = ((data[i] / 128) * H) / 2;
              i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
              x += sw;
            }
            ctx.stroke();
          } else {
            S.analyser.getByteFrequencyData(data);
            const cx = W / 2,
              cy = H / 2,
              r = H * 0.3;
            ctx.strokeStyle = 'rgba(0,212,168,0.6)';
            ctx.lineWidth = 1;
            ctx.beginPath();
            for (let i = 0; i < bufLen; i++) {
              const v = data[i] / 255,
                a = i * ((2 * Math.PI) / bufLen) - Math.PI / 2;
              ctx.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
              ctx.lineTo(
                cx + Math.cos(a) * (r + v * cy * 0.8),
                cy + Math.sin(a) * (r + v * cy * 0.8),
              );
            }
            ctx.stroke();
          }
        }
        frame();
      }
      function startFsViz() {
        if (S.fsVizRaf) cancelAnimationFrame(S.fsVizRaf);
        initAudioCtx();
        setTimeout(connectAudioToStream, 300);
        const canvas = $('fs-bars'),
          ctx = canvas.getContext('2d');
        function draw() {
          S.fsVizRaf = requestAnimationFrame(draw);
          if (!S.analyser) return;
          const W = canvas.offsetWidth,
            H = canvas.offsetHeight;
          if (canvas.width !== W) canvas.width = W;
          if (canvas.height !== H) canvas.height = H;
          ctx.clearRect(0, 0, W, H);
          const bufLen = S.analyser.frequencyBinCount;
          const data = new Uint8Array(bufLen);
          S.analyser.getByteFrequencyData(data);
          const n = 80,
            bW = W / n,
            step = Math.floor(bufLen / n);
          let x = 0;
          for (let i = 0; i < n; i++) {
            let sum = 0;
            for (let j = 0; j < step; j++) sum += data[i * step + j];
            const v = sum / step / 255,
              bH = v * H;
            const hue = 160 + (i / n) * 40;
            const g = ctx.createLinearGradient(0, H - bH, 0, H);
            g.addColorStop(0, `hsla(${hue},100%,60%,${0.5 + v * 0.5})`);
            g.addColorStop(1, `hsla(${hue},100%,40%,0.2)`);
            ctx.fillStyle = g;
            ctx.beginPath();
            ctx.roundRect(x + 2, H - bH, bW - 4, bH, [6, 6, 0, 0]);
            ctx.fill();
            x += bW;
          }
        }
        draw();
      }
      function stopFsViz() {
        if (S.fsVizRaf) {
          cancelAnimationFrame(S.fsVizRaf);
          S.fsVizRaf = null;
        }
      }

      // ═══════════════════════════════════════════
      //  CAPTIONS
      // ═══════════════════════════════════════════
      function toggleCaptions() {
        S.speechOn = !S.speechOn;
        const btn = $('btn-captions');
        if (S.speechOn) {
          btn.classList.add('on');
          btn.textContent = 'DISABLE CAPTIONS';
          startSpeechRec();
        } else {
          btn.classList.remove('on');
          btn.textContent = 'ENABLE CAPTIONS';
          if (S.speechRec) S.speechRec.stop();
          $('captions-text').textContent = '♪ Captions disabled';
        }
      }
      function startSpeechRec() {
        const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SR) {
          toast('Speech Recognition not supported');
          toggleCaptions();
          return;
        }
        if (!S.speechRec) {
          S.speechRec = new SR();
          S.speechRec.continuous = true;
          S.speechRec.interimResults = true;
          S.speechRec.onresult = (ev) => {
            let interim = '',
              final = '';
            for (let i = ev.resultIndex; i < ev.results.length; i++) {
              if (ev.results[i].isFinal) final += ev.results[i][0].transcript;
              else interim += ev.results[i][0].transcript;
            }
            const t = final || interim;
            if (t.trim()) $('captions-text').textContent = t;
          };
          S.speechRec.onerror = (e) => {
            if (e.error === 'not-allowed') {
              toast('Mic access denied');
              toggleCaptions();
            }
          };
          S.speechRec.onend = () => {
            if (S.speechOn) S.speechRec.start();
          };
        }
        try {
          S.speechRec.start();
          $('captions-text').textContent = 'Listening...';
        } catch (e) {}
      }

      // ═══════════════════════════════════════════
      //  RECORDING
      // ═══════════════════════════════════════════
      function getSupportedMime() {
        const fmt = $('rec-fmt').value;
        if (MediaRecorder.isTypeSupported(fmt)) return fmt;
        for (const f of [
          'video/webm;codecs=vp9,opus',
          'video/webm;codecs=vp8,opus',
          'video/webm',
        ])
          if (MediaRecorder.isTypeSupported(f)) return f;
        return '';
      }
      function toggleRecording() {
        if (S.mediaRecorder && S.mediaRecorder.state !== 'inactive')
          stopRecording();
        else startRecording();
      }
      function startRecording() {
        const vid = $('stream');
        if (!vid.srcObject) {
          toast('Start streaming first');
          return;
        }
        const mime = getSupportedMime();
        if (!mime) {
          toast('No supported recording format');
          return;
        }
        S.recChunks = [];
        try {
          S.mediaRecorder = new MediaRecorder(vid.srcObject, {
            mimeType: mime,
            videoBitsPerSecond: S.recBpsMbps * 1_000_000,
          });
        } catch (e) {
          toast('MediaRecorder: ' + e.message);
          log('Rec: ' + e.message, 'err');
          return;
        }
        S.mediaRecorder.ondataavailable = (e) => {
          if (e.data?.size > 0) S.recChunks.push(e.data);
        };
        S.mediaRecorder.onstop = () => finalizeRec();
        S.mediaRecorder.start(1000);
        S.recStartTime = Date.now();
        setRecUI(true);
        log(`Recording started · ${mime}`, 'ok');
        toast('Recording started', 'ok', 2000);
        S.recTimerInterval = setInterval(updateRecTimer, 1000);
        if ($('tog-rec-split').checked) {
          const mins = parseInt($('rec-split-min').value) || 10;
          S.recSplitTimer = setInterval(
            () => {
              stopRecording();
              setTimeout(() => startRecording(), 800);
            },
            mins * 60 * 1000,
          );
        }
      }
      function stopRecording() {
        if (!S.mediaRecorder || S.mediaRecorder.state === 'inactive') return;
        S.mediaRecorder.stop();
        clearInterval(S.recTimerInterval);
        clearInterval(S.recSplitTimer);
        setRecUI(false);
        log('Recording stopped', 'warn');
      }
      function finalizeRec() {
        if (!S.recChunks.length) return;
        const mime = S.mediaRecorder.mimeType || 'video/webm';
        const ext = mime.includes('mp4') ? 'mp4' : 'webm';
        const blob = new Blob(S.recChunks, { type: mime });
        const dur = Math.round((Date.now() - S.recStartTime) / 1000);
        S.recTotalSeconds += dur;
        const seg = {
          index: S.recSegments.length + 1,
          blob,
          mime,
          ext,
          dur,
          name: `rec_${Date.now()}.${ext}`,
          size: blob.size,
        };
        S.recSegments.push(seg);
        S.recChunks = [];
        renderSegs();
        log(`Saved · ${fmtTime(dur)} · ${fmtB(blob.size)}`, 'ok');
      }
      function renderSegs() {
        const box = $('rec-segs');
        if (!S.recSegments.length) {
          box.innerHTML =
            '<div style="font-size:10px;color:var(--t3);padding:12px 0;text-align:center">No recordings yet</div>';
        } else {
          box.innerHTML = '';
          S.recSegments.forEach((seg, i) => {
            const d = document.createElement('div');
            d.className = 'rec-seg';
            d.innerHTML = `<div><div class="rec-seg-name">Seg ${seg.index} · ${seg.ext.toUpperCase()}</div><div class="rec-seg-dur">${fmtTime(seg.dur)} · ${fmtB(seg.size)}</div></div><button class="seg-dl-btn" onclick="dlSeg(${i})">↓ SAVE</button>`;
            box.appendChild(d);
          });
        }
        const total = S.recSegments.reduce((a, s) => a + s.size, 0);
        $('rec-seg-count').textContent = S.recSegments.length;
        $('rec-total-dur').textContent = fmtTime(S.recTotalSeconds);
        $('rec-est-size').textContent = fmtB(total);
      }
      function dlSeg(i) {
        const seg = S.recSegments[i];
        if (!seg) return;
        const url = URL.createObjectURL(seg.blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = seg.name;
        a.click();
        URL.revokeObjectURL(url);
        toast(`Downloading ${seg.name}`, 'ok', 2000);
      }
      function clearSegments() {
        S.recSegments = [];
        S.recTotalSeconds = 0;
        renderSegs();
      }
      function setRecUI(on) {
        const btn = $('rec-main-btn'),
          barBtn = $('btn-rec'),
          pill = $('rec-tag');
        if (on) {
          btn.textContent = '⏹ STOP RECORDING';
          btn.className = 'abtn';
          barBtn.classList.add('rec-on');
          pill.classList.add('on');
          $('rec-status-lbl').textContent = '● RECORDING';
          $('rec-status-lbl').classList.add('on');
          $('rec-timer').style.color = 'var(--red)';
        } else {
          btn.innerHTML = '⏺ START RECORDING';
          btn.className = 'abtn red';
          barBtn.classList.remove('rec-on');
          pill.classList.remove('on');
          $('rec-status-lbl').textContent = 'STOPPED';
          $('rec-status-lbl').classList.remove('on');
          $('rec-timer').style.color = '';
          $('rec-timer').textContent = '00:00';
        }
      }
      function updateRecTimer() {
        const e = Math.round((Date.now() - S.recStartTime) / 1000);
        const fmt = fmtTime(e);
        $('rec-timer').textContent = fmt;
        $('rec-tag-txt').textContent = 'REC ' + fmt;
        $('rec-est-size').textContent = fmtB(
          ((S.recBpsMbps * 1_000_000) / 8) * e,
        );
      }
      function onRecBps(el) {
        S.recBpsMbps = +el.value;
        $('rec-bps-v').textContent = `${S.recBpsMbps} Mbps`;
        fill(el);
      }
      function recBpsChip(v) {
        $('sl-rec-bps').value = v;
        onRecBps($('sl-rec-bps'));
        chipSet('chips-recbps', v);
      }

      // ═══════════════════════════════════════════
      //  AUTO-RECONNECT
      // ═══════════════════════════════════════════
      function onReconInt(el) {
        S.reconIntSec = +el.value;
        $('recon-int-v').textContent = `${S.reconIntSec} s`;
        fill(el);
      }
      function setReconStatus(s) {
        const el = $('recon-status'),
          m = {
            waiting: 'WAITING…',
            connecting: 'CONNECTING…',
            connected: 'CONNECTED',
            failed: 'FAILED',
          };
        el.textContent = m[s] || s;
        el.className = `v ${s === 'connected' ? 'green' : s === 'failed' ? 'red' : 'amber'}`;
      }
      function scheduleRecon() {
        if (!$('tog-autorecon').checked) return;
        clearTimeout(S.reconTimer);
        setReconStatus('waiting');
        S.reconTimer = setTimeout(async () => {
          S.reconCount++;
          $('recon-count').textContent = S.reconCount;
          setReconStatus('connecting');
          log(`Auto-reconnect #${S.reconCount}…`, 'warn');
          try {
            await connectWs();
            setBadge('ok', 'CONNECTED');
            setReconStatus('connected');
            setSbConn('CONNECTED', 'green');
          } catch (e) {
            setReconStatus('failed');
            scheduleRecon();
          }
        }, S.reconIntSec * 1000);
      }

      // ═══════════════════════════════════════════
      //  CHIPS
      // ═══════════════════════════════════════════
      function chipSet(containerId, value) {
        const str = String(value);
        document.querySelectorAll(`#${containerId} .chip`).forEach((c) => {
          const fn = c.getAttribute('onclick') || '';
          const m = fn.match(/\(([^)]+)\)/);
          const arg = m ? m[1].replace(/['"]/g, '').trim() : '';
          c.classList.toggle('on', arg === str);
        });
      }

      // ═══════════════════════════════════════════
      //  SLIDERS
      // ═══════════════════════════════════════════
      function onVbr(el) {
        S.vbrK = +el.value;
        $('vv').textContent = fmtK(S.vbrK);
        fill(el);
      }
      function sendVbr(el) {
        onVbr(el);
        sendWs({ type: 'set_video_bitrate', bitrate: S.vbrK * 1000 });
        log(`VBR → ${fmtK(S.vbrK)}`);
        ack('sl-row-vbr');
      }
      function vbrChip(k) {
        $('sl-vbr').value = k;
        sendVbr($('sl-vbr'));
        chipSet('chips-vbr', k);
      }
      function onFps(el) {
        S.fpsV = +el.value;
        $('fv').textContent = `${S.fpsV} fps`;
        fill(el);
      }
      function sendFps(el) {
        onFps(el);
        sendWs({ type: 'set_fps', fps: S.fpsV });
        log(`FPS → ${S.fpsV}`);
        ack('sl-row-fps');
      }
      function fpsChip(f) {
        $('sl-fps').value = f;
        sendFps($('sl-fps'));
        chipSet('chips-fps', f);
      }
      function onAbr(el) {
        S.abrK = +el.value;
        $('av').textContent = `${S.abrK} kbps`;
        fill(el);
      }
      function sendAbr(el) {
        onAbr(el);
        sendWs({ type: 'set_audio_bitrate', bitrate: S.abrK * 1000 });
        log(`ABR → ${S.abrK}k`);
        ack('sl-row-abr');
      }
      function abrChip(k) {
        $('sl-abr').value = k;
        sendAbr($('sl-abr'));
        chipSet('chips-abr', k);
      }
      function onVol(el) {
        S.volPct = +el.value;
        $('volv').textContent = `${S.volPct}%`;
        fill(el);
      }
      function sendVol(el) {
        onVol(el);
        sendWs({ type: 'set_audio_volume', volume: S.volPct / 100 });
        log(`Vol → ${S.volPct}%`);
        ack('sl-row-vol');
      }
      function onLatMs(el) {
        S.latMsV = +el.value;
        $('latms-v').textContent = `${S.latMsV} ms`;
        fill(el);
      }
      function latMsChip(v) {
        $('sl-latms').value = v;
        onLatMs($('sl-latms'));
        chipSet('chips-latms', v);
      }

      // ═══════════════════════════════════════════
      //  PRESETS
      // ═══════════════════════════════════════════
      function applyPreset(name, silent = false) {
        const p = CONFIG.presets[name];
        if (!p) return;
        S.quality = name;
        $('sel-quality').value = name;
        $('sl-vbr').value = p.vbr;
        S.vbrK = p.vbr;
        $('vv').textContent = fmtK(p.vbr);
        fill($('sl-vbr'));
        $('sl-fps').value = p.fps;
        S.fpsV = p.fps;
        $('fv').textContent = `${p.fps} fps`;
        fill($('sl-fps'));
        $('sl-abr').value = p.abr;
        S.abrK = p.abr;
        $('av').textContent = `${p.abr} kbps`;
        fill($('sl-abr'));
        $('res-lbl').textContent = `${p.w}×${p.h}`;
        document
          .querySelectorAll('#preset-chips .chip')
          .forEach((c) =>
            c.classList.toggle(
              'on',
              (c.getAttribute('onclick') || '').includes(`'${name}'`),
            ),
          );
        if (!silent && S.streaming && S.ws?.readyState === WebSocket.OPEN) {
          sendWs({ type: 'switch', ...buildParams() });
          log(`Preset → ${name}`, 'ok');
        } else if (!silent) log(`Preset: ${name}`);
      }
      function onPresetChange() {
        applyPreset($('sel-quality').value);
      }
      function buildParams() {
        return {
          mode: S.mode,
          audio: S.micOn,
          quality: S.quality,
          video_device: $('cfg-vdev').value.trim() || null,
          audio_device: $('cfg-adev').value.trim() || null,
          pip_position: S.pipPos,
          pip_w: parseInt($('pip-w').value) || 320,
          pip_h: parseInt($('pip-h').value) || 180,
          custom_vbr:
            (parseInt($('cfg-cvbr').value) || 0) * 1000 || S.vbrK * 1000,
          custom_abr:
            (parseInt($('cfg-cabr').value) || 0) * 1000 || S.abrK * 1000,
          custom_fps: parseInt($('cfg-cfps').value) || S.fpsV,
          custom_w: parseInt($('cfg-cw').value) || null,
          custom_h: parseInt($('cfg-ch').value) || null,
          encoder_preset: $('cfg-enc-preset').value,
          gop_size: parseInt($('cfg-gop').value) || 15,
          b_frames: parseInt($('cfg-bf').value) || 0,
          rc_mode: $('cfg-rcmode').value,
          show_cursor: $('tog-cursor').checked,
          window_title: $('cfg-wintitle').value.trim(),
          audio_channels: parseInt($('cfg-ach').value) || 1,
          audio_rate: parseInt($('cfg-arate').value) || 48000,
          opus_audio_type: $('cfg-opus-type').value,
          opus_fec: $('tog-fec').checked,
          opus_dtx: $('tog-dtx').checked,
          opus_frame_size: parseFloat($('cfg-opus-frame').value) || 10,
          noise_suppression: $('tog-ns').checked,
          echo_cancel: $('tog-ec').checked,
          audio_volume: S.volPct / 100,
          stun_server: $('cfg-stun').value.trim() || null,
          turn_server: $('cfg-turn').value.trim() || null,
          latency_ms: S.latMsV,
          loopback: $('tog-loopback').checked,
        };
      }
      function applyVideoConfig() {
        if (!S.streaming || !S.ws) {
          toast('Start streaming first');
          return;
        }
        sendWs({ type: 'switch', ...buildParams() });
        toast('Video config applied', 'ok', 2000);
        log('Video config applied', 'ok');
      }
      function applyAudioConfig() {
        if (!S.streaming || !S.ws) {
          toast('Start streaming first');
          return;
        }
        sendWs({ type: 'switch', ...buildParams() });
        toast('Audio config applied', 'ok', 2000);
        log('Audio config applied', 'ok');
      }
      function reconnect() {
        clearTimeout(S.reconTimer);
        if (S.ws)
          try {
            S.ws.close();
          } catch (e) {}
        connectWs()
          .then(() => {
            setBadge('ok', 'CONNECTED');
            setSbConn('CONNECTED', 'green');
          })
          .catch(() => {
            setBadge('err', 'OFFLINE');
            setSbConn('OFFLINE', '');
          });
      }
      function sendAdv() {
        const elem = $('adv-elem').value.trim(),
          prop = $('adv-prop').value.trim(),
          raw = $('adv-val').value.trim();
        const value = isNaN(raw) ? raw : Number(raw);
        if (!elem || !prop) {
          toast('Element and property required');
          return;
        }
        sendWs({ type: 'set_property', element: elem, property: prop, value });
        log(`set ${elem}.${prop} = ${value}`);
      }

      // ═══════════════════════════════════════════
      //  MODE / MIC / SPEAKER
      // ═══════════════════════════════════════════
      function setMode(mode) {
        S.mode = mode;
        ['screen', 'window', 'webcam', 'both', 'audio'].forEach((m) =>
          $(`btn-${m}`)?.classList.remove('on'),
        );
        $(`btn-${mode === 'audio_only' ? 'audio' : mode}`)?.classList.add('on');
        log(`Source → ${mode}`);
        if (mode === 'window') refreshWindowList();
        if (S.streaming && S.ws?.readyState === WebSocket.OPEN) {
          sendWs({ type: 'switch', ...buildParams() });
          setTimeout(showStream, 500);
        }
      }
      function onWindowSelectChange() {
        const t = $('cfg-wintitle').value;
        log(`Window → ${t}`);
        if (
          S.streaming &&
          S.mode === 'window' &&
          S.ws?.readyState === WebSocket.OPEN
        ) {
          toast(`Switching to: ${t}`, 'ok', 2000);
          sendWs({ type: 'switch', ...buildParams() });
        }
      }
      function refreshWindowList() {
        if (S.ws?.readyState === WebSocket.OPEN) {
          sendWs({ type: 'get_window_list' });
          toast('Refreshing…', '', 1500);
        } else toast('Not connected');
      }
      function toggleMic() {
        S.micOn = !S.micOn;
        $('btn-mic').classList.toggle('on', S.micOn);
        $('btn-mic').classList.toggle('muted', !S.micOn);
        log(`Server Mic → ${S.micOn ? 'ON' : 'OFF'}`);
        if (S.streaming && S.ws?.readyState === WebSocket.OPEN)
          sendWs({ type: 'switch', ...buildParams() });
      }
      async function toggleClientMic() {
        if (!S.pc || S.pc.connectionState !== 'connected') {
          toast('Not connected');
          return;
        }
        if (S.clientMicTrack) {
          S.clientMicTrack.stop();
          const sender = S.pc
            .getSenders()
            .find((s) => s.track === S.clientMicTrack);
          if (sender) S.pc.removeTrack(sender);
          S.clientMicTrack = null;
          $('btn-talk').classList.remove('talk-on');
          log('Client Mic → OFF', 'warn');
          toast('Talk to PC disabled');
          try {
            const offer = await S.pc.createOffer();
            await S.pc.setLocalDescription(offer);
            sendWs({ type: 'offer', sdp: S.pc.localDescription.sdp });
          } catch (e) {
            log(`Mic off error: ${e}`, 'err');
          }
          return;
        }
        try {
          const stream = await navigator.mediaDevices.getUserMedia({
            audio: true,
            video: false,
          });
          S.clientMicTrack = stream.getAudioTracks()[0];
          S.pc.addTrack(S.clientMicTrack, stream);
          $('btn-talk').classList.add('talk-on');
          log('Client Mic → ON', 'ok');
          toast('Talk to PC enabled', 'ok');
          const offer = await S.pc.createOffer();
          await S.pc.setLocalDescription(offer);
          sendWs({ type: 'offer', sdp: S.pc.localDescription.sdp });
          S.clientMicTrack.onended = () => {
            $('btn-talk').classList.remove('talk-on');
            S.clientMicTrack = null;
            log('Client Mic ended', 'warn');
          };
        } catch (e) {
          log(`Client Mic: ${e.message}`, 'err');
          toast('Mic access denied');
        }
      }
      function toggleSpeaker() {
        S.spkOn = !S.spkOn;
        if (!S.gainNode) $('stream').muted = !S.spkOn;
        $('btn-spk').classList.toggle('on', S.spkOn);
        $('btn-spk').classList.toggle('muted', !S.spkOn);
        if (S.gainNode)
          S.gainNode.gain.setTargetAtTime(
            S.spkOn ? S.localVolPct / 100 : 0,
            S.audioCtx.currentTime,
            0.01,
          );
        log(`Speaker → ${S.spkOn ? 'ON' : 'OFF'}`);
      }
      function setPip(el) {
        document
          .querySelectorAll('.pip-cell')
          .forEach((c) => c.classList.remove('on'));
        el.classList.add('on');
        S.pipPos = el.dataset.pip;
        log(`PiP → ${S.pipPos}`);
        if (
          S.streaming &&
          S.mode === 'both' &&
          S.ws?.readyState === WebSocket.OPEN
        )
          sendWs({ type: 'switch', ...buildParams() });
      }

      // ═══════════════════════════════════════════
      //  UI TOGGLES
      // ═══════════════════════════════════════════
      function toggleHud() {
        S.hudOn = !S.hudOn;
        $('hud-stats').classList.toggle('on', S.hudOn);
        $('btn-hud').classList.toggle('on', S.hudOn);
        if (S.hudOn) startStats();
        else stopStats();
      }
      function toggleLat() {
        S.latOn = !S.latOn;
        $('lat-display').classList.toggle('on', S.latOn);
        $('btn-lat').classList.toggle('on', S.latOn);
        if (S.latOn) startLat();
        else stopLat();
      }
      function toggleFS() {
        document.fullscreenElement
          ? document.exitFullscreen()
          : $('stage').requestFullscreen?.();
      }
      function togglePanel() {
        S.panelOn = !S.panelOn;
        $('app').classList.toggle('panel-open', S.panelOn);
        $('btn-panel').classList.toggle('on', S.panelOn);
        $('panel-bg').classList.toggle(
          'on',
          S.panelOn && window.innerWidth < 900,
        );
      }
      function closePanel() {
        S.panelOn = false;
        $('app').classList.remove('panel-open');
        $('btn-panel').classList.remove('on');
        $('panel-bg').classList.remove('on');
      }
      function setTab(tab) {
        S.activeTab = tab;
        document
          .querySelectorAll('.ptab')
          .forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
        document
          .querySelectorAll('.pane')
          .forEach((p) => p.classList.toggle('on', p.id === `pane-${tab}`));
        if (tab === 'stats' && S.streaming) startStats();
      }

      // ═══════════════════════════════════════════
      //  WEBSOCKET
      // ═══════════════════════════════════════════
      function wsUrl() {
        const c = $('cfg-server')?.value?.trim();
        if (c) return c.startsWith('ws') ? c : c.replace(/^http/, 'ws');
        return `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws`;
      }
      function connectWs() {
        return new Promise((res, rej) => {
          log(`Connecting → ${wsUrl()}`, 'dim');
          setBadge('spin', 'CONNECTING…');
          setSbConn('CONNECTING…', 'amber');
          const ws = new WebSocket(wsUrl());
          S.ws = ws;
          ws.onopen = () => {
            log('WebSocket connected', 'ok');
            res(ws);
          };
          ws.onerror = (e) => {
            log('WebSocket error', 'err');
            rej(e);
          };
          ws.onclose = (e) => {
            log(`WebSocket closed (${e.code})`, 'warn');
            setBadge('err', 'OFFLINE');
            setSbConn('OFFLINE', '');
            showLive(false);
            S.streaming = false;
            $('btn-start').disabled = false;
            $('btn-stop').disabled = true;
            if ($('tog-autorecon').checked) scheduleRecon();
          };
          ws.onmessage = ({ data }) => {
            try {
              handleMsg(JSON.parse(data));
            } catch (e) {
              log(`Parse error: ${e}`, 'err');
            }
          };
        });
      }
      function sendWs(obj) {
        if (S.ws?.readyState === WebSocket.OPEN) S.ws.send(JSON.stringify(obj));
      }

      // ═══════════════════════════════════════════
      //  SERVER MESSAGES
      // ═══════════════════════════════════════════
      async function handleMsg(msg) {
        switch (msg.type) {
          case 'hello':
            S.peerId = msg.peer_id;
            $('n-peer').textContent = msg.peer_id;
            setBadge('ok', 'CONNECTED');
            setSbConn('CONNECTED', 'green');
            log(`Connected · ${msg.peer_id}`, 'ok');
            sendWs({ type: 'get_info' });
            break;
          case 'info':
            $('n-plat').textContent =
              `${msg.platform} ${msg.platform_ver || ''}`.trim();
            $('n-gst').textContent = msg.gst_ver || '—';
            $('n-enc').textContent = msg.venc || '—';
            $('n-scr').textContent = msg.screen_src || '—';
            $('n-cam').textContent = msg.cam_src || '—';
            $('n-aud').textContent = msg.audio_src || '—';
            $('n-stun').textContent = msg.stun_server || '—';
            $('n-dsp').textContent = msg.has_webrtcdsp
              ? 'available ✓'
              : 'unavailable';
            if (!msg.has_webrtcdsp) $('dsp-warn').style.display = 'block';
            if (msg.v_device) $('cfg-vdev').value = msg.v_device;
            if (msg.a_device) $('cfg-adev').value = msg.a_device;
            if (msg.stun_server) $('cfg-stun').value = msg.stun_server;
            if (msg.turn_server) $('cfg-turn').value = msg.turn_server;
            if (msg.audio_devices?.length) {
              const sel = $('adev-list');
              msg.audio_devices.forEach((d) => {
                const o = document.createElement('option');
                o.value = d.id;
                o.textContent = d.label;
                sel.appendChild(o);
              });
              $('adev-list-wrap').style.display = 'flex';
            }
            if (msg.presets)
              Object.entries(msg.presets).forEach(([k, v]) => {
                CONFIG.presets[k] = {
                  w: v.w,
                  h: v.h,
                  fps: v.fps,
                  vbr: v.vbr / 1000,
                  abr: v.abr / 1000,
                };
              });
            log(`Server: GST ${msg.gst_ver} | enc=${msg.venc}`);
            if (msg.auto_profile) S.autoProfile = msg.auto_profile;
            if (msg.hardware_warning) {
                toast('⚠ ' + msg.hardware_warning, 'err', 8000);
                log('⚠ ' + msg.hardware_warning, 'warn');
            }
            break;
          case 'window_list': {
            const sel = $('cfg-wintitle'),
              cur = sel.value;
            sel.innerHTML = '<option value="">— select window —</option>';
            (msg.windows || []).forEach((w) => {
              const o = document.createElement('option');
              o.value = w.title;
              o.textContent = w.title;
              if (w.title === cur) o.selected = true;
              sel.appendChild(o);
            });
            log(`${(msg.windows || []).length} windows received`, 'ok');
            break;
          }
          case 'offer':
            if (!msg.sdp) {
              log('Invalid SDP', 'err');
              break;
            }
            log('SDP offer → answering');
            await handleOffer(msg.sdp);
            break;
          case 'answer':
            if (S.pc && msg.sdp) {
              try {
                await S.pc.setRemoteDescription(
                  new RTCSessionDescription({ type: 'answer', sdp: msg.sdp }),
                );
                log('SDP answer processed', 'ok');
              } catch (e) {
                log(`Answer error: ${e}`, 'err');
              }
            }
            break;
          case 'ice':
            if (S.pc && msg.candidate) {
              try {
                await S.pc.addIceCandidate({
                  candidate: msg.candidate,
                  sdpMLineIndex: msg.sdpMLineIndex,
                });
              } catch (e) {}
            }
            break;
          case 'connection_state':
            $('st-conn').textContent = msg.state.toUpperCase();
            if (msg.state === 'connected') {
              setBadge('live', '● LIVE');
              setSbConn('LIVE', 'green');
              showLive(true);
              showStream();
              startStats();
              if (S.latOn) startLat();
              if ($('tog-viz').checked) {
                initAudioCtx();
                setTimeout(connectAudioToStream, 500);
              }
            } else if (
              ['failed', 'closed', 'disconnected'].includes(msg.state)
            ) {
              setBadge('err', msg.state.toUpperCase());
              setSbConn(msg.state.toUpperCase(), '');
              showLive(false);
            }
            break;
          case 'ice_state':
            $('st-ice').textContent = msg.state.toUpperCase();
            break;
          case 'pipeline_state':
            log(
              `Pipeline → ${msg.state}`,
              msg.state === 'playing' ? 'ok' : 'dim',
            );
            break;
          case 'stopped':
            log('Stopped', 'warn');
            hideStream();
            cleanupPc();
            showLive(false);
            setBadge('ok', 'CONNECTED');
            setSbConn('CONNECTED', 'green');
            break;
          case 'restarted':
            log('Pipeline restarted', 'ok');
            toast('Pipeline restarted', 'ok', 2000);
            break;
          case 'eos':
            log('End of stream', 'warn');
            toast('Stream ended (EOS)');
            break;
          case 'pong':
            if (msg.ts !== undefined) updLat((performance.now() - msg.ts) / 2);
            break;
          case 'param_ack':
            log(
              `${msg.param}=${msg.value ?? '?'} → ${msg.ok ? 'applied' : 'FAILED'}`,
              msg.ok ? 'ok' : 'warn',
            );
            if (!msg.ok) toast(`Failed: ${msg.param}`);
            break;
          case 'error': {
            log(`Error: ${msg.message}`, 'err');
            toast(msg.message?.substring(0, 90));
            const isAudioErr =
              msg.message &&
              (msg.message.includes('wasapi') ||
                msg.message.includes('Could not open resource') ||
                msg.message.includes('Failed to open device') ||
                msg.message.includes('not-negotiated'));
            if (isAudioErr) {
              $('cfg-adev').value = '';
              const al = $('adev-list');
              if (al) al.value = '';
              log('Audio device reset to default', 'warn');
              toast('Audio device reset', '', 3000);
            }
            setBadge('err', 'ERROR');
            break;
          }
        }
      }

      // ═══════════════════════════════════════════
      //  WEBRTC
      // ═══════════════════════════════════════════
      function _buildIceServers() {
          const servers = [];
          const stun = $('cfg-stun').value.trim();
          servers.push({ urls: stun ? stun.replace('stun://', 'stun:') : 'stun:stun.l.google.com:19302' });
          const turn = $('cfg-turn').value.trim();
          if (turn) {
              const m = turn.match(/^turns?:\/\/([^:]+):([^@]+)@(.+)$/);
              if (m) servers.push({ urls: `turn:${m[3]}`, username: m[1], credential: m[2] });
          }
          return servers;
      }
      function createPc() {
        cleanupPc();
        const pc = new RTCPeerConnection({
          iceServers:  _buildIceServers(),
          sdpSemantics: 'unified-plan',
          bundlePolicy: 'max-bundle',
          rtcpMuxPolicy: 'require',
          iceCandidatePoolSize: 2,
        });
        S.pc = pc;
        pc.onicecandidate = ({ candidate }) => {
          if (candidate)
            sendWs({
              type: 'ice',
              candidate: candidate.candidate,
              sdpMLineIndex: candidate.sdpMLineIndex,
            });
        };
        pc.oniceconnectionstatechange = () => {
          $('st-ice').textContent = pc.iceConnectionState.toUpperCase();
        };
        pc.onconnectionstatechange = () => {
          const s = pc.connectionState;
          log(
            `Conn → ${s}`,
            s === 'connected' ? 'ok' : s === 'failed' ? 'err' : 'dim',
          );
          $('st-conn').textContent = s.toUpperCase();
          if (s === 'connected') {
            setBadge('live', '● LIVE');
            setSbConn('LIVE', 'green');
            showLive(true);
            showStream();
            startStats();
          }
          if (s === 'failed') {
            setBadge('err', 'FAILED');
            toast('WebRTC failed');
            showLive(false);
          }
        };
        pc.ontrack = (ev) => {
          log(`Track: ${ev.track.kind}`, 'ok');
          const vid = $('stream');
          if (ev.streams?.length) vid.srcObject = ev.streams[0];
          else {
            if (!vid.srcObject) vid.srcObject = new MediaStream();
            vid.srcObject.addTrack(ev.track);
          }
          if (
            ev.track.kind === 'video' &&
            'jitterBufferDelayHint' in ev.receiver
          )
            ev.receiver.jitterBufferDelayHint = 0;
          if ($('tog-viz').checked && ev.track.kind === 'audio') {
            initAudioCtx();
            setTimeout(connectAudioToStream, 300);
          }
          if (S.mode === 'audio_only' && ev.track.kind === 'audio')
            startFsViz();
        };
        return pc;
      }
      async function handleOffer(sdpText) {
        const pc = createPc();
        await pc.setRemoteDescription(
          new RTCSessionDescription({ type: 'offer', sdp: sdpText }),
        );
        const hasV = sdpText.includes('m=video'),
          hasA = sdpText.includes('m=audio');
        if (
          hasV &&
          !pc.getTransceivers().some((t) => t.receiver.track?.kind === 'video')
        )
          pc.addTransceiver('video', { direction: 'recvonly' });
        const ans = await pc.createAnswer({
          offerToReceiveVideo: hasV ? 1 : 0,
          offerToReceiveAudio: hasA ? 1 : 0,
          voiceActivityDetection: false,
        });
        ans.sdp = patchSdp(ans.sdp);
        await pc.setLocalDescription(ans);
        sendWs({ type: 'answer', sdp: pc.localDescription.sdp });
        log('Answer sent', 'ok');
      }
      function patchSdp(sdp) {
        return sdp
          .replace(
            /a=fmtp:96 /g,
            'a=fmtp:96 max-fr=120;max-recv-width=7680;max-recv-height=4320;',
          )
          .replace(/b=AS:\d+\r\n/g, '');
      }
      function cleanupPc() {
        if (S.pc) {
          S.pc.onicecandidate = null;
          S.pc.ontrack = null;
          S.pc.close();
          S.pc = null;
        }
        if (S.clientMicTrack) {
          S.clientMicTrack.stop();
          S.clientMicTrack = null;
          $('btn-talk').classList.remove('talk-on');
        }
      }

      // ═══════════════════════════════════════════
      //  STREAM START / STOP
      // ═══════════════════════════════════════════
      async function startStream() {
        $('btn-start').disabled = true;
        if (!S.ws || S.ws.readyState !== WebSocket.OPEN) {
          try {
            await connectWs();
          } catch (e) {
            log('Cannot connect', 'err');
            toast('Server unreachable');
            $('btn-start').disabled = false;
            return;
          }
        }
        await sleep(200);
        sendWs({ type: 'start', ...buildParams() });
        S.streaming = true;
        $('btn-stop').disabled = false;
        setBadge('spin', 'STARTING…');
        setSbConn('STARTING…', 'amber');
        log(
          `Start · ${S.mode} · ${S.quality} · ${fmtK(S.vbrK)} · ${S.fpsV}fps`,
          'ok',
        );
        if (S.latOn) startLat();
      }
      async function stopStream() {
        if (S.mediaRecorder && S.mediaRecorder.state !== 'inactive')
          stopRecording();
        sendWs({ type: 'stop' });
        cleanupPc();
        hideStream();
        S.streaming = false;
        stopStats();
        stopLat();
        showLive(false);
        setBadge('ok', 'CONNECTED');
        setSbConn('CONNECTED', 'green');
        $('btn-start').disabled = false;
        $('btn-stop').disabled = true;
        log('Stopped', 'warn');
        updateStatusBar(0, 0, '—', 0);
      }
      function showStream() {
        $('idle').classList.add('hidden');
        if (!S.gainNode) $('stream').muted = !S.spkOn;
        if (S.mode === 'audio_only') {
          $('stream').style.display = 'none';
          $('audio-view').classList.add('on');
          startFsViz();
        } else {
          $('stream').style.display = 'block';
          $('audio-view').classList.remove('on');
          stopFsViz();
        }
      }
      function hideStream() {
        $('idle').classList.remove('hidden');
        $('stream').srcObject = null;
        $('stream').style.display = 'block';
        $('audio-view').classList.remove('on');
        stopViz();
        stopFsViz();
      }

      function toggleAuto() {
        S.autoOn = !S.autoOn;
        const btn = $('btn-auto');
        btn.classList.toggle('on', S.autoOn);

        if (S.autoOn) {
          if (!S.autoProfile) {
            toast('Profil auto non reçu — reconnectez-vous');
            S.autoOn = false;
            btn.classList.remove('on');
            return;
          }
          console.log({ profile: S.autoProfile });
          // Appliquer le preset qualité recommandé
          applyPreset(S.autoProfile.quality, true);

          // Appliquer les dimensions plafonnées si présentes
          $('cfg-cw').value = S.autoProfile.custom_w || 0;
          $('cfg-ch').value = S.autoProfile.custom_h || 0;
          $('cfg-cfps').value = S.autoProfile.custom_fps || 0;

          // Appliquer les canaux audio
          if (S.autoProfile.audio_channels)
            $('cfg-ach').value = S.autoProfile.audio_channels;

          toast('Autopilot ON — profil matériel appliqué', 'ok', 2500);
          log(`Autopilot ON · qualité=${S.autoProfile.quality}`, 'ok');

          if (S.streaming && S.ws?.readyState === WebSocket.OPEN)
            sendWs({ type: 'switch', ...buildParams() });
        } else {
          // Réinitialiser les overrides
          $('cfg-cw').value = 0;
          $('cfg-ch').value = 0;
          $('cfg-cfps').value = 0;

          toast('Autopilot OFF', '', 1500);
          log('Autopilot OFF', 'warn');
        }
      }

      // ═══════════════════════════════════════════
      //  STATS LOOP
      // ═══════════════════════════════════════════
      function startStats() {
        stopStats();
        fetchStats();
        S.statsTmr = setInterval(fetchStats, 1000);
      }
      function stopStats() {
        clearInterval(S.statsTmr);
        S.statsTmr = null;
      }
      async function fetchStats() {
        if (!S.pc) return;
        try {
          const stats = await S.pc.getStats();
          let fps = 0,
            vbr = 0,
            abr = 0,
            rtt = 0,
            jit = 0,
            lost = 0,
            codec = '—',
            w = 0,
            h = 0,
            frames = 0,
            bytes = 0;
          const now = performance.now();
          stats.forEach((r) => {
            if (r.type === 'inbound-rtp') {
              if (r.kind === 'video') {
                fps = Math.round(r.framesPerSecond || 0);
                lost = r.packetsLost || 0;
                w = r.frameWidth || 0;
                h = r.frameHeight || 0;
                frames = r.framesDecoded || 0;
                bytes = r.bytesReceived || 0;
                const p = S.prevStats[r.id];
                if (p?.ts)
                  vbr = Math.round(
                    ((r.bytesReceived - p.bytesReceived) * 8) /
                      ((now - p.ts) / 1000) /
                      1000,
                  );
                S.prevStats[r.id] = { ...r, ts: now };
              }
              if (r.kind === 'audio') {
                jit = Math.round((r.jitter || 0) * 1000);
                const p = S.prevStats[r.id + 'a'];
                if (p?.ts)
                  abr = Math.round(
                    ((r.bytesReceived - p.bytesReceived) * 8) /
                      ((now - p.ts) / 1000) /
                      1000,
                  );
                S.prevStats[r.id + 'a'] = { ...r, ts: now };
              }
            }
            if (r.type === 'candidate-pair' && r.state === 'succeeded')
              rtt = Math.round((r.currentRoundTripTime || 0) * 1000);
            if (r.type === 'codec' && r.mimeType?.includes('video'))
              codec = r.mimeType.split('/')[1].toUpperCase();
          });
          const res = w ? `${w}×${h}` : '—';
          $('hm-fps').textContent = `${fps} FPS`;
          $('hm-vbr').textContent = fmtK(vbr);
          $('hm-res').textContent = res;
          $('hm-rtt').textContent = `RTT ${rtt}ms`;
          $('st-fps').textContent = `${fps} fps`;
          $('st-vbr').textContent = fmtK(vbr);
          $('st-res').textContent = res;
          $('st-codec').textContent = codec;
          $('st-lost').textContent = lost;
          $('st-frames').textContent = frames.toLocaleString();
          $('st-bytes').textContent = fmtB(bytes);
          $('st-abr').textContent = `${abr} kbps`;
          $('st-jit').textContent = `${jit} ms`;
          $('st-rtt').textContent = `${rtt} ms`;
          const rttEl = $('st-rtt');
          rttEl.className = `v ${rtt < 30 ? 'green' : rtt < 80 ? '' : 'warn'}`;
          updateStatusBar(fps, vbr, res, rtt);
          S.sparkData.push(vbr);
          if (S.sparkData.length > 80) S.sparkData.shift();
          drawSpark();
        } catch (e) {}
      }
      function drawSpark() {
        const c = $('spark');
        if (!c) return;
        const ctx = c.getContext('2d');
        const W = (c.width = c.offsetWidth || 300),
          H = (c.height = 34);
        ctx.clearRect(0, 0, W, H);
        const d = S.sparkData;
        if (d.length < 2) return;
        const mx = Math.max(...d, 1);
        ctx.beginPath();
        ctx.strokeStyle = 'rgba(0,212,168,0.75)';
        ctx.lineWidth = 1.5;
        d.forEach((v, i) => {
          const x = (i / (d.length - 1)) * W,
            y = H - (v / mx) * H * 0.88 - 2;
          i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
        });
        ctx.stroke();
        ctx.lineTo(W, H);
        ctx.lineTo(0, H);
        ctx.closePath();
        ctx.fillStyle = 'rgba(0,212,168,0.05)';
        ctx.fill();
      }

      // ═══════════════════════════════════════════
      //  LATENCY
      // ═══════════════════════════════════════════
      function startLat() {
        stopLat();
        pingOnce();
        S.latTmr = setInterval(pingOnce, 2000);
      }
      function stopLat() {
        clearInterval(S.latTmr);
        S.latTmr = null;
      }
      function pingOnce() {
        if (S.ws?.readyState === WebSocket.OPEN)
          sendWs({ type: 'ping', ts: performance.now() });
      }
      function updLat(ms) {
        const v = Math.round(ms),
          c =
            ms < 30 ? 'var(--green)' : ms < 80 ? 'var(--accent)' : 'var(--red)';
        $('lat-num').textContent = v;
        $('lat-num').style.color = c;
        $('st-lat').textContent = `${v} ms`;
        $('st-wslat').textContent = `${v} ms`;
      }

      // ═══════════════════════════════════════════
      //  KEYBOARD
      // ═══════════════════════════════════════════
      document.addEventListener('keydown', (e) => {
        if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return;
        if (e.key === '?') {
          e.preventDefault();
          openShortcuts();
          return;
        }
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
          e.preventDefault();
          openPal();
          return;
        }
        switch (e.key) {
          case ' ':
            e.preventDefault();
            S.streaming ? stopStream() : startStream();
            break;
          case 's':
            setMode('screen');
            break;
          case 'w':
            setMode('window');
            break;
          case 'b':
            setMode('both');
            break;
          case 'a':
            setMode('audio_only');
            break;
          case 'c':
            setMode('webcam');
            break;
          case 'm':
            toggleMic();
            break;
          case 't':
            toggleClientMic();
            break;
          case 'u':
            toggleSpeaker();
            break;
          case 'f':
            toggleFS();
            break;
          case 'i':
            toggleHud();
            break;
          case 'l':
            toggleLat();
            break;
          case 'p':
            takeScreenshot();
            break;
          case 'r':
            toggleRecording();
            break;
          case ',':
            togglePanel();
            break;
          case 'q':
            toggleAuto();
            break;
          case 'Escape':
            if ($('cmdpal').classList.contains('on')) {
              closePal();
              return;
            }
            if ($('shortcuts-overlay').classList.contains('on')) {
              closeShortcuts();
              return;
            }
            if (S.streaming) stopStream();
            break;
        }
      });

      // ═══════════════════════════════════════════
      //  INIT
      // ═══════════════════════════════════════════
      document.addEventListener('DOMContentLoaded', () => {
        log('StreamForge ready — press SPACE or ▶ STREAM to begin', 'ok');
        log(
          'Ctrl+K = command palette  |  ? = shortcuts  |  SPACE = start/stop',
          'dim',
        );
        applyPreset('medium', true);
        document.querySelectorAll('input[type=range]').forEach((r) => {
          fill(r);
          r.addEventListener('input', () => fill(r));
        });
        $('sl-recon-int').addEventListener('input', () =>
          onReconInt($('sl-recon-int')),
        );
        connectWs()
          .then(() => {
            setBadge('ok', 'CONNECTED');
            setSbConn('CONNECTED', 'green');
          })
          .catch(() => {
            setBadge('err', 'OFFLINE');
            setSbConn('OFFLINE', '');
            log('Server offline — running in demo mode', 'warn');
          });
      });
    </script>
  </body>
</html>
"""


# ─── DPI Awareness ───────────────────────────────────────────────────────────

def _set_dpi_awareness():
    """Rend le processus DPI-aware pour GetWindowRect en pixels physiques."""
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)   # PER_MONITOR_DPI_AWARE
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass

_set_dpi_awareness()


# ─── Utilitaires Windows ─────────────────────────────────────────────────────

def get_screen_size() -> tuple[int, int, int, int]:
    """Retourne (w, h, origin_x, origin_y) du bureau virtuel complet."""
    sm = ctypes.windll.user32.GetSystemMetrics
    return sm(78), sm(79), sm(76), sm(77)   # CX/CY/X/Y VIRTUALSCREEN


def get_window_hwnd(exact_title: str):
    """Retourne le HWND de la première fenêtre visible dont le titre correspond exactement."""
    if not exact_title:
        return None
    user32 = ctypes.windll.user32
    found  = [None]

    def cb(hwnd, _):
        if not user32.IsWindowVisible(hwnd):
            return True
        n = user32.GetWindowTextLengthW(hwnd)
        if n > 0:
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            if buf.value == exact_title:
                found[0] = hwnd
                return False
        return True

    WEFP = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    user32.EnumWindows(WEFP(cb), 0)
    return found[0]


def get_window_rect(exact_title: str) -> tuple:
    """Retourne (hwnd, (x, y, w, h)) sans les ombres DWM."""
    hwnd = get_window_hwnd(exact_title)
    if not hwnd:
        return None, None

    r = wintypes.RECT()
    try:
        ctypes.windll.dwmapi.DwmGetWindowAttribute(
            hwnd, 9, ctypes.byref(r), ctypes.sizeof(r)   # DWMWA_EXTENDED_FRAME_BOUNDS
        )
    except Exception:
        ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(r))

    return hwnd, (r.left, r.top, r.right - r.left, r.bottom - r.top)


def get_open_windows() -> list[dict]:
    """Liste toutes les fenêtres visibles et non-triviales."""
    user32  = ctypes.windll.user32
    windows = []

    def enum_cb(hwnd, _):
        if not user32.IsWindowVisible(hwnd):
            return True
        ex_style = user32.GetWindowLongW(hwnd, -20)   # GWL_EXSTYLE
        if ex_style & 0x80:                            # WS_EX_TOOLWINDOW
            return True
        n = user32.GetWindowTextLengthW(hwnd)
        if n > 0:
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            title = buf.value
            r = wintypes.RECT()
            user32.GetWindowRect(hwnd, ctypes.byref(r))
            w = r.right - r.left
            h = r.bottom - r.top
            if title and w > 50 and h > 50 and title not in ('Default IME', 'MSCTFIME UI'):
                windows.append({'title': title})
        return True

    WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    user32.EnumWindows(WNDENUMPROC(enum_cb), 0)

    windows.sort(key=lambda x: x['title'].lower())
    seen, deduped = set(), []
    for w in windows:
        if w['title'] not in seen:
            seen.add(w['title'])
            deduped.append(w)
    return deduped


# ─── Capacités GStreamer ──────────────────────────────────────────────────────

def has_elem(name: str) -> bool:
    return Gst.ElementFactory.find(name) is not None


def _is_render_device(device_id: str) -> bool:
    """Les devices de sortie Windows ont l'ID format {0.0.0.…}, la capture {0.0.1.…}."""
    return bool(device_id) and device_id.startswith('{0.0.0.')


def list_audio_devices() -> list[dict]:
    """Énumère les devices audio via GStreamer DeviceMonitor."""
    devices = []
    try:
        monitor = Gst.DeviceMonitor.new()
        monitor.add_filter("Audio/Source", None)
        monitor.start()
        for dev in monitor.get_devices():
            display = dev.get_display_name() or ''
            props   = dev.get_properties()
            dev_id  = ''
            if props:
                dev_id = (props.get_string('device.id') or
                          props.get_string('object.path') or
                          display)
            devices.append({'label': display, 'id': dev_id or display})
        monitor.stop()
    except Exception:
        pass
    return devices


def probe_caps(video_device: str = None, audio_device: str = None) -> dict:
    dev  = video_device  if video_device  is not None else VIDEO_DEVICE
    adev = audio_device  if audio_device  is not None else AUDIO_DEVICE
    caps = {}

    # ── Capture écran
    for name in ('d3d11screencapturesrc', 'd3d12screencapturesrc',
                 'gdiscreencapsrc', 'dx9screencapsrc'):
        if has_elem(name):
            caps['screen_src'] = name
            break
    else:
        caps['screen_src'] = None

    caps['screen_needs_d3d'] = caps.get('screen_src') in (
        'd3d11screencapturesrc', 'd3d12screencapturesrc'
    )

    # ── Capture fenêtre
    if has_elem('d3d11screencapturesrc'):
        caps['window_src'] = 'd3d11screencapturesrc'
    elif has_elem('gdiscreencapsrc'):
        caps['window_src'] = 'gdiscreencapsrc'
    else:
        caps['window_src'] = None

    # ── Webcam  (mfvideosrc garanti Win10/11, ksvideosrc en fallback)
    if has_elem('mfvideosrc'):
        caps['cam_src']  = f'mfvideosrc device-index={dev}'
        caps['cam_elem'] = 'mfvideosrc'
    elif has_elem('ksvideosrc'):
        caps['cam_src']  = f'ksvideosrc device-index={dev}'
        caps['cam_elem'] = 'ksvideosrc'
    else:
        caps['cam_src'] = caps['cam_elem'] = None

    # ── Audio  (wasapi2src garanti Win10 1903+)
    if has_elem('wasapi2src'):
        if adev and _is_render_device(adev):
            log.info(f'Device de sortie ({adev[:30]}…) → loopback=true automatique')
            caps['audio_src']     = f'wasapi2src device="{adev}" low-latency=false buffer-time=100000 loopback=true'
            caps['auto_loopback'] = True
        else:
            dp = f' device="{adev}"' if adev else ''
            caps['audio_src']     = f'wasapi2src{dp} low-latency=false buffer-time=100000'
            caps['auto_loopback'] = False
        caps['audio_elem'] = 'wasapi2src'
    elif has_elem('wasapisrc'):
        dp = f' device="{adev}"' if adev else ''
        caps['audio_src']  = f'wasapisrc{dp} buffer-time=100000'
        caps['audio_elem'] = 'wasapisrc'
    else:
        caps['audio_src'] = caps['audio_elem'] = None

    # ── Encodeur vidéo  (Nvidia en premier, Media Foundation garanti sinon)
    if has_elem('nvh264enc'):
        caps['venc'] = 'nvidia_h264'
    elif has_elem('mfh264enc'):
        caps['venc'] = 'mf_h264'
    else:
        caps['venc'] = 'mf_h264'   # mfh264enc est garanti Win10/11

    return caps


CAPS = probe_caps()
log.info(f"Platform  : {platform.system()} {platform.release()}")
log.info(f"Screen    : {CAPS.get('screen_src') or 'UNAVAILABLE'}")
log.info(f"Window    : {CAPS.get('window_src') or 'UNAVAILABLE'}")
log.info(f"Webcam    : {CAPS.get('cam_src')    or 'UNAVAILABLE'}")
log.info(f"Audio     : {CAPS.get('audio_src')  or 'UNAVAILABLE'}")
log.info(f"Encoder   : {CAPS.get('venc')}")


# ─── Profil automatique système ───────────────────────────────────────────────

def _wmic(args: list[str], timeout: int = 4) -> str:
    """
    Exécute une commande wmic et retourne stdout en texte brut.
    Retourne '' en cas d'échec (wmic absent, timeout, erreur WMI).
    wmic est présent sur tout Windows 10/11 mais peut être désactivé
    par une GPO — on ne compte jamais dessus de façon critique.
    """
    import subprocess
    try:
        out = subprocess.check_output(
            ['wmic'] + args,
            stderr=subprocess.DEVNULL,
            timeout=timeout,
            creationflags=0x08000000,   # CREATE_NO_WINDOW
        )
        return out.decode('utf-8', errors='replace').strip()
    except FileNotFoundError:
        log.debug('auto_profile: wmic introuvable (GPO?)')
        return ''
    except subprocess.TimeoutExpired:
        log.debug('auto_profile: wmic timeout')
        return ''
    except Exception as e:
        log.debug(f'auto_profile: wmic error — {e}')
        return ''


def _get_gpu_info() -> dict:
    """
    Retourne {'name': str, 'vram_mb': int, 'vendor': str} pour le GPU principal.
    Vendor : 'nvidia' | 'amd' | 'intel' | 'unknown'
    En cas d'échec total → valeurs minimales sûres.
    """
    fallback = {'name': 'unknown', 'vram_mb': 0, 'vendor': 'unknown'}
    try:
        raw = _wmic(['path', 'Win32_VideoController',
                     'get', 'Name,AdapterRAM', '/format:csv'])
        if not raw:
            return fallback

        best = fallback.copy()
        for line in raw.splitlines():
            line = line.strip()
            if not line or line.lower().startswith('node'):
                continue
            parts = [p.strip() for p in line.split(',')]
            # CSV format: Node, AdapterRAM, Name
            if len(parts) < 3:
                continue
            try:
                vram_mb = int(parts[1]) // (1024 * 1024) if parts[1].isdigit() else 0
            except (ValueError, IndexError):
                vram_mb = 0
            name = parts[2] if len(parts) > 2 else ''
            if not name:
                continue

            name_lower = name.lower()
            if 'nvidia' in name_lower:
                vendor = 'nvidia'
            elif 'amd' in name_lower or 'radeon' in name_lower:
                vendor = 'amd'
            elif 'intel' in name_lower:
                vendor = 'intel'
            else:
                vendor = 'unknown'

            # Préférer le GPU discret (Nvidia > AMD > Intel > inconnu)
            priority = {'nvidia': 4, 'amd': 3, 'intel': 2, 'unknown': 1}
            if priority.get(vendor, 1) > priority.get(best.get('vendor', 'unknown'), 1):
                best = {'name': name, 'vram_mb': vram_mb, 'vendor': vendor}

        return best if best['name'] != 'unknown' else fallback

    except Exception as e:
        log.debug(f'auto_profile: _get_gpu_info error — {e}')
        return fallback


def _get_ram_available_mb() -> int:
    """
    RAM disponible en Mo via GlobalMemoryStatusEx (kernel32, toujours présent).
    Retourne 2048 en cas d'échec — valeur conservative sûre.
    """
    try:
        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ('dwLength',                ctypes.c_ulong),
                ('dwMemoryLoad',            ctypes.c_ulong),
                ('ullTotalPhys',            ctypes.c_ulonglong),
                ('ullAvailPhys',            ctypes.c_ulonglong),
                ('ullTotalPageFile',        ctypes.c_ulonglong),
                ('ullAvailPageFile',        ctypes.c_ulonglong),
                ('ullTotalVirtual',         ctypes.c_ulonglong),
                ('ullAvailVirtual',         ctypes.c_ulonglong),
                ('ullAvailExtendedVirtual', ctypes.c_ulonglong),
            ]
        ms = MEMORYSTATUSEX()
        ms.dwLength = ctypes.sizeof(ms)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(ms))
        return int(ms.ullAvailPhys // (1024 * 1024))
    except Exception as e:
        log.debug(f'auto_profile: _get_ram_available_mb error — {e}')
        return 2048


def _get_cpu_info() -> dict:
    """
    Retourne {'cores': int, 'load_pct': int}.
    En cas d'échec : cores=4, load_pct=50 (valeurs moyennes sûres).
    """
    result = {'cores': 4, 'load_pct': 50}
    try:
        result['cores'] = os.cpu_count() or 4
    except Exception:
        pass

    try:
        raw = _wmic(['cpu', 'get', 'loadpercentage', '/format:csv'])
        for line in raw.splitlines():
            line = line.strip()
            if not line or line.lower().startswith('node'):
                continue
            parts = [p.strip() for p in line.split(',')]
            # CSV: Node, LoadPercentage
            if len(parts) >= 2 and parts[1].isdigit():
                result['load_pct'] = int(parts[1])
                break
    except Exception as e:
        log.debug(f'auto_profile: _get_cpu_info load error — {e}')

    return result


def _get_screen_resolution() -> tuple[int, int]:
    """
    Résolution de l'écran principal via GetSystemMetrics (user32, toujours présent).
    Retourne (1920, 1080) en cas d'échec.
    """
    try:
        w = ctypes.windll.user32.GetSystemMetrics(0)   # SM_CXSCREEN
        h = ctypes.windll.user32.GetSystemMetrics(1)   # SM_CYSCREEN
        if w > 0 and h > 0:
            return w, h
    except Exception as e:
        log.debug(f'auto_profile: _get_screen_resolution error — {e}')
    return 1920, 1080

def auto_profile() -> dict:
    """
    Analyse le matériel du PC une seule fois au démarrage et retourne
    un dict de paramètres optimaux pour zéro lag / latence minimale.

    Logique de décision :
      GPU Nvidia (VRAM ≥ 6 GB)  → ultra  (nvh264enc, 60fps, 12 Mbps)
      GPU Nvidia (VRAM < 6 GB)  → high   (nvh264enc, 60fps,  6 Mbps)
      GPU AMD / Intel Arc        → high   (mfh264enc, 60fps,  6 Mbps)
      GPU Intel intégré          → medium (mfh264enc, 30fps,  3 Mbps)
      Inconnu / très faible      → low    (mfh264enc, 24fps,  1.5 Mbps)

    Correctifs automatiques :
      CPU chargé (> 75%)  → encoder_preset = 'speed'
      RAM dispo < 1.5 GB  → descend d'un niveau de qualité
      Écran < 1080p       → plafonne la résolution au natif
    """
    log.info('auto_profile: analyse du système en cours…')

    gpu    = _get_gpu_info()
    ram_mb = _get_ram_available_mb()
    cpu    = _get_cpu_info()
    scr_w, scr_h = _get_screen_resolution()

    print(gpu)
    print(ram_mb)
    print(cpu)
    print(scr_w, scr_h)


    reasons = {
        'gpu':        f"{gpu['name']} ({gpu['vram_mb']} MB VRAM)",
        'vendor':     gpu['vendor'],
        'ram_avail_mb': ram_mb,
        'cpu_cores':  cpu['cores'],
        'cpu_load':   cpu['load_pct'],
        'screen':     f"{scr_w}×{scr_h}",
    }

    # ── Choix du preset de base selon GPU ────────────────────────────────────
    vendor   = gpu['vendor']
    vram_mb  = gpu['vram_mb']

    if vendor == 'nvidia' and vram_mb >= 6144:
        quality = 'ultra'
    elif vendor == 'nvidia':
        quality = 'high'
    elif vendor in ('amd',):
        quality = 'high'
    elif vendor == 'intel' and 'arc' in gpu['name'].lower():
        quality = 'high'
    elif vendor == 'intel':
        quality = 'medium'
    else:
        quality = 'low'

    reasons['quality_from_gpu'] = quality

    # ── Correction RAM ────────────────────────────────────────────────────────
    _quality_order = ['low', 'medium', 'high', 'ultra']
    if ram_mb < 1536:
        idx = _quality_order.index(quality)
        if idx > 0:
            quality = _quality_order[idx - 1]
            reasons['quality_downgraded_ram'] = f'RAM dispo {ram_mb} MB < 1536 MB → {quality}'
            log.warning(f"auto_profile: RAM faible ({ram_mb} MB) → qualité réduite à '{quality}'")

    # ── Correction CPU chargé ─────────────────────────────────────────────────
    encoder_preset = 'default'
    if cpu['load_pct'] > 75:
        encoder_preset = 'speed'
        reasons['encoder_preset_reason'] = f"CPU chargé à {cpu['load_pct']}% → preset speed"
        log.warning(f"auto_profile: CPU chargé ({cpu['load_pct']}%) → encoder_preset='speed'")


    # ── Résolution : toujours explicite — min(écran, plafond_preset) ──────────
    preset_data = {
        'low':    {'w': 1280, 'h': 720,  'fps': 24, 'vbr': 1_500_000},
        'medium': {'w': 1920, 'h': 1080, 'fps': 30, 'vbr': 3_000_000},
        'high':   {'w': 1920, 'h': 1080, 'fps': 60, 'vbr': 6_000_000},
        'ultra':  {'w': 2560, 'h': 1440, 'fps': 60, 'vbr':12_000_000},
    }
    p        = preset_data[quality]
    custom_w = min(p['w'], scr_w)
    custom_h = min(p['h'], scr_h)

    reasons['resolution'] = f"{custom_w}×{custom_h} (écran={scr_w}×{scr_h} plafond={p['w']}×{p['h']})"

    # ── Correction 1 : charge CPU effective avec marge streaming ─────────────
    # mfh264enc / nvh264enc consomme ~20-30% CPU supplémentaire au démarrage
    STREAMING_CPU_OVERHEAD = 25
    effective_cpu = min(100, cpu['load_pct'] + STREAMING_CPU_OVERHEAD)
    reasons['cpu_load_raw']       = cpu['load_pct']
    reasons['cpu_load_effective'] = effective_cpu

    # ── FPS : score matériel basé sur CPU effectif ────────────────────────────
    hw_score = (100 - effective_cpu) * 0.6 + min(ram_mb / 2048 * 100, 100) * 0.4

    if   hw_score >= 80: custom_fps = min(p['fps'], 60)
    elif hw_score >= 60: custom_fps = min(p['fps'], 30)
    elif hw_score >= 40: custom_fps = min(p['fps'], 24)
    elif hw_score >= 20: custom_fps = min(p['fps'], 15)
    else:                custom_fps = 15   # Correction 2 : plancher 15fps minimum

    reasons['hw_score']   = round(hw_score, 1)
    reasons['custom_fps'] = custom_fps

    # ── Correction 2 : warning si matériel insuffisant ───────────────────────
    hardware_warning = None
    if hw_score < 20:
        hardware_warning = (
            f"Matériel très limité (score={hw_score:.0f}/100) — "
            f"streaming forcé à 15fps minimum, qualité dégradée probable"
        )
        log.warning(f"auto_profile: {hardware_warning}")

    # ── Correction 3 : warning RAM critique ──────────────────────────────────
    if ram_mb < 500:
        ram_warning = (
            f"RAM disponible critique ({ram_mb} MB) — "
            f"risque de crash, fermez des applications avant de streamer"
        )
        reasons['ram_warning'] = ram_warning
        log.warning(f"auto_profile: {ram_warning}")
        if hardware_warning:
            hardware_warning += f" | RAM critique: {ram_mb} MB"
        else:
            hardware_warning = ram_warning

    if hardware_warning:
        reasons['hardware_warning'] = hardware_warning

    # ── VBR : proportionnel au débit pixel réel ──────────────────────────────
    pixel_ratio = (custom_w * custom_h * custom_fps) / (p['w'] * p['h'] * p['fps'])
    custom_vbr  = max(300_000, int(p['vbr'] * pixel_ratio))

    reasons['custom_vbr'] = custom_vbr

    log.info(
        f"auto_profile: hw_score={hw_score:.1f} cpu_eff={effective_cpu}% "
        f"→ {custom_w}×{custom_h} @{custom_fps}fps {custom_vbr//1000}kbps"
    )

    # ── Paramètres audio ──────────────────────────────────────────────────────
    # 2 canaux si CPU ok, mono sinon (économise ~30% CPU côté Opus)
    audio_channels = 2 if cpu['cores'] >= 4 and cpu['load_pct'] < 70 else 1
    reasons['audio_channels'] = audio_channels

    profile = dict(
        quality           = quality,
        encoder_preset    = encoder_preset,
        custom_w          = custom_w,
        custom_h          = custom_h,
        custom_fps        = custom_fps,
        custom_vbr        = custom_vbr,
        custom_abr        = None,
        audio_channels    = audio_channels,
        latency_ms        = 0,
        hardware_warning  = hardware_warning,   # None si matériel ok
        _reasons          = reasons,
    )

    log.info(
        f"auto_profile: quality={quality}  encoder={encoder_preset}  "
        f"audio_ch={audio_channels}  "
        f"res={'native' if not (custom_w or custom_h) else f'{custom_w}×{custom_h}'}"
    )
    return profile


# Calculé une seule fois au démarrage — jamais recalculé à chaud
AUTO_PROFILE: dict = {}
try:
    AUTO_PROFILE = auto_profile()
except Exception as e:
    log.error(f'auto_profile: échec complet — valeurs par défaut utilisées ({e})')
    AUTO_PROFILE = {
        'quality': 'medium', 'encoder_preset': 'default',
        'custom_w': None, 'custom_h': None,
        'custom_fps': None, 'custom_vbr': None, 'custom_abr': None,
        'audio_channels': 1, 'latency_ms': 0,
        '_reasons': {'error': str(e)},
    }

# ─── Presets qualité ─────────────────────────────────────────────────────────

QUALITY_PRESETS = {
    'low':    {'w': 1280, 'h': 720,  'fps': 24, 'vbr': 1_500_000, 'abr':  64_000},
    'medium': {'w': 1920, 'h': 1080, 'fps': 30, 'vbr': 3_000_000, 'abr':  96_000},
    'high':   {'w': 1920, 'h': 1080, 'fps': 60, 'vbr': 6_000_000, 'abr': 128_000},
    'ultra':  {'w': 2560, 'h': 1440, 'fps': 60, 'vbr':12_000_000, 'abr': 192_000},
}

# _Q = 'queue max-size-buffers=5 max-size-time=50000000 leaky=downstream'
_Q = 'queue max-size-buffers=2 max-size-bytes=0 max-size-time=0 leaky=downstream'

# ─── Constructeurs de pipeline ────────────────────────────────────────────────

def _make_venc(caps: dict, bitrate: int, fps: int = 30,
               encoder_preset: str = 'default',
               gop_size: int = 15) -> str:
    """
    Deux encodeurs seulement :
      - nvh264enc  si GPU Nvidia disponible  (hardware premium)
      - mfh264enc  sinon                     (Media Foundation, garanti Win10/11)
    b_frames=0 et rc_mode=cbr sont fixés : WebRTC n'aime pas les B-frames
    et CBR est le seul mode adapté au streaming temps réel.
    """
    enc = caps.get('venc', 'mf_h264')
    kbr = bitrate // 1000

    if enc == 'nvidia_h264':
        p_map = {'default': 'low-latency', 'quality': 'hq', 'speed': 'low-latency'}
        gst_p = p_map.get(encoder_preset, 'low-latency')
        return (f'nvh264enc name=vencoder bitrate={kbr} gop-size={gop_size} '
                f'zerolatency=true preset={gst_p} bframes=0 '
                f'! rtph264pay pt=96 config-interval=1')

    # mf_h264 — Media Foundation (défaut garanti)
    return (f'mfh264enc name=vencoder bitrate={kbr} low-latency=true '
            f'rc-mode=0 quality-vs-speed=0 gop-size={gop_size} '
            f'! rtph264pay pt=96 config-interval=1')


def _make_aenc(caps: dict, bitrate: int,
               audio_channels: int = 1,
               audio_rate: int = 48000,
               opus_audio_type: str = 'voice',
               opus_fec: bool = True,
               opus_dtx: bool = False,
               audio_volume: float = 1.0,
               loopback: bool = False) -> str:
    asrc = caps.get('audio_src')
    if not asrc:
        return ''

    if loopback and 'wasapi2src' in asrc:
        import re
        asrc = re.sub(r'\bloopback=\w+', '', asrc).strip()
        asrc += ' loopback=true'
        log.info(f'Audio source → loopback mode: {asrc}')

    gst_audio_type = 'generic' if opus_audio_type == 'music' else opus_audio_type
    channels  = max(1, min(2, audio_channels))
    vol_str   = f'volume name=avol volume={audio_volume:.2f} ! ' if audio_volume != 1.0 else ''
    audio_q   = 'queue max-size-buffers=0 max-size-bytes=0 max-size-time=500000000 leaky=downstream'

    return (
        f'{asrc} ! audioconvert ! audioresample ! '
        f'audio/x-raw,rate={audio_rate},channels={channels} ! '
        f'{vol_str}{audio_q} ! '
        f'opusenc name=aencoder bitrate={bitrate} audio-type={gst_audio_type} '
        f'inband-fec={"true" if opus_fec else "false"} '
        f'dtx={"true" if opus_dtx else "false"} frame-size=10 ! '
        f'rtpopuspay pt=97 ! webrtc.'
    )


def _screen_chain(caps: dict, w: int, h: int, fps: int, show_cursor: bool) -> str:
    src      = caps['screen_src']
    cursor   = 'true' if show_cursor else 'false'
    q_src    = 'queue max-size-buffers=2 leaky=downstream'
    out_caps = f'video/x-raw,width={w},height={h},framerate={fps}/1'

    if caps.get('screen_needs_d3d') and has_elem('d3d11convert'):
        return (f'{src} show-cursor={cursor} blocksize=8192 ! {q_src} ! '
                f'd3d11convert ! d3d11download ! '
                f'videoconvert ! videorate name=vrater ! {out_caps}')

    return (f'{src} show-cursor={cursor} ! {q_src} ! '
            f'videoconvert ! videoscale ! videorate name=vrater ! {out_caps}')


def _window_chain(caps: dict, w: int, h: int, fps: int,
                  show_cursor: bool, window_title: str) -> str:
    cursor   = 'true' if show_cursor else 'false'
    q_src    = 'queue max-size-buffers=2 leaky=downstream'
    out_caps = f'video/x-raw,width={w},height={h},framerate={fps}/1'

    hwnd, rect = get_window_rect(window_title)

    # ① d3d11screencapturesrc + window-handle  (hardware, le meilleur)
    if hwnd and has_elem('d3d11screencapturesrc'):
        log.info(f"[win-cap] d3d11screencapturesrc handle={hwnd} ('{window_title}')")
        return (f'd3d11screencapturesrc show-cursor={cursor} window-handle={hwnd} ! '
                f'{q_src} ! d3d11convert ! d3d11download ! '
                f'videoconvert ! videoscale ! videorate name=vrater ! {out_caps}')

    # ② gdiscreencapsrc plein écran + videocrop sur la région de la fenêtre
    if has_elem('gdiscreencapsrc'):
        if rect and hwnd:
            x, y, ww, wh = rect
            sw, sh, ox, oy = get_screen_size()
            lft = max(0, x - ox)
            top = max(0, y - oy)
            rgt = max(0, sw - lft - ww)
            bot = max(0, sh - top - wh)
            log.info(f"[win-cap] gdiscreencapsrc + videocrop l={lft} t={top} r={rgt} b={bot}")
            return (f'gdiscreencapsrc cursor={cursor} ! {q_src} ! '
                    f'videocrop left={lft} top={top} right={rgt} bottom={bot} ! '
                    f'videoconvert ! videoscale ! videorate name=vrater ! {out_caps}')
        else:
            log.warning(f"[win-cap] Fenêtre '{window_title}' introuvable → écran complet")
            return (f'gdiscreencapsrc cursor={cursor} ! {q_src} ! '
                    f'videoconvert ! videoscale ! videorate name=vrater ! {out_caps}')

    raise RuntimeError(
        "Aucun élément de capture de fenêtre disponible.\n"
        "Attendu : d3d11screencapturesrc ou gdiscreencapsrc"
    )


def build_pipeline(
    mode: str,
    audio: bool,
    quality: str           = 'medium',
    video_device: str      = None,
    audio_device: str      = None,
    pip_position: str      = 'bottom-right',
    pip_w: int             = 320,
    pip_h: int             = 180,
    custom_vbr: int        = None,
    custom_abr: int        = None,
    custom_fps: int        = None,
    custom_w: int          = None,
    custom_h: int          = None,
    encoder_preset: str    = 'default',
    gop_size: int          = 15,
    show_cursor: bool      = True,
    window_title: str      = '',
    audio_channels: int    = 1,
    audio_rate: int        = 48000,
    opus_audio_type: str   = 'voice',
    opus_fec: bool         = True,
    opus_dtx: bool         = False,
    audio_volume: float    = 1.0,
    loopback: bool         = False,
    stun_server: str       = None,
    turn_server: str       = None,
    latency_ms: int        = 0,
    **_kw

) -> str:

    preset = QUALITY_PRESETS.get(quality, QUALITY_PRESETS['medium'])
    W   = custom_w   or preset['w']
    H   = custom_h   or preset['h']
    FPS = custom_fps or preset['fps']
    vbr = custom_vbr or preset['vbr']
    abr = custom_abr or preset['abr']
    stun = stun_server or STUN_SERVER

    local_caps = probe_caps(video_device, audio_device) if (video_device or audio_device) else CAPS

    venc     = _make_venc(local_caps, vbr, FPS, encoder_preset, gop_size)
    aenc_str = (
        _make_aenc(local_caps, abr, audio_channels, audio_rate,
                   opus_audio_type, opus_fec, opus_dtx, audio_volume, loopback)
        if audio else ''
    )

    _turn = turn_server or TURN_SERVER
    webrtcbin = (f'webrtcbin name=webrtc bundle-policy=max-bundle '
                 f'latency={latency_ms} stun-server={stun}')
    if _turn:
        webrtcbin += f' turn-server={_turn}'

    vcaps = f'video/x-raw,width={W},height={H},framerate={FPS}/1'

    def _require(key: str) -> str:
        val = local_caps.get(key)
        if not val:
            raise RuntimeError(
                f"Source '{key}' indisponible — lancez server.py --diagnose"
            )
        return val

    # ── Modes ────────────────────────────────────────────────────────────────

    if mode == 'screen':
        _require('screen_src')
        sc   = _screen_chain(local_caps, W, H, FPS, show_cursor)
        pipe = f'{webrtcbin}\n{sc} ! {_Q} ! {venc} ! webrtc.\n'

    elif mode == 'window':
        _require('window_src')
        wc   = _window_chain(local_caps, W, H, FPS, show_cursor, window_title)
        pipe = f'{webrtcbin}\n{wc} ! {_Q} ! {venc} ! webrtc.\n'

    elif mode == 'webcam':
        vsrc = _require('cam_src')
        pipe = (f'{webrtcbin}\n'
                f'{vsrc} ! videoconvert ! videoscale ! videorate name=vrater ! {vcaps} ! '
                f'{_Q} ! {venc} ! webrtc.\n')

    elif mode == 'both':
        _require('screen_src')
        cam_src = _require('cam_src')
        pip_map = {
            'bottom-right': (W - pip_w - 4, H - pip_h - 4),
            'bottom-left':  (4,              H - pip_h - 4),
            'top-right':    (W - pip_w - 4, 4),
            'top-left':     (4,              4),
        }
        px, py = pip_map.get(pip_position, pip_map['bottom-right'])
        sc     = _screen_chain(local_caps, W, H, FPS, show_cursor)
        pipe   = (
            f'{webrtcbin}\n'
            f'compositor name=comp '
            f'sink_1::xpos={px} sink_1::ypos={py} '
            f'sink_1::width={pip_w} sink_1::height={pip_h} ! '
            f'videoconvert ! videorate name=vrater ! {vcaps} ! {_Q} ! '
            f'{_make_venc(local_caps, int(vbr * 1.3), FPS, encoder_preset, gop_size)} ! webrtc.\n'
            f'{sc} ! comp.sink_0\n'
            f'{cam_src} ! videoconvert ! videoscale ! videorate ! '
            f'video/x-raw,width={pip_w},height={pip_h},framerate={FPS}/1 ! comp.sink_1\n'
        )

    elif mode == 'audio_only':
        pipe     = f'{webrtcbin}\n'
        audio    = True
        aenc_str = _make_aenc(
            local_caps, abr, audio_channels, audio_rate,
            opus_audio_type, opus_fec, opus_dtx, audio_volume, loopback
        )

    else:
        raise ValueError(f'Mode inconnu : {mode!r}')

    if audio:
        if not aenc_str:
            log.warning('Audio demandé mais aucune source disponible — ignoré')
        else:
            pipe += aenc_str

    return pipe


# ─── WebRTC Peer ──────────────────────────────────────────────────────────────

class WebRTCPeer:
    def __init__(self, ws, peer_id: str, loop: asyncio.AbstractEventLoop):
        self.ws       = ws
        self.peer_id  = peer_id
        self.loop     = loop
        self.pipeline = None
        self.webrtc   = None
        self._running = False
        self.params: dict = {}

    # ── Cycle de vie ─────────────────────────────────────────────────────────

    def start(self, **params):
        self.params = params
        try:
            desc = build_pipeline(**params)
        except Exception as exc:
            log.error(f'[{self.peer_id}] Build error: {exc}')
            self._notify({'type': 'error', 'message': str(exc)})
            return

        log.info(f'[{self.peer_id}] Start mode={params.get("mode")} '
                 f'quality={params.get("quality")} loopback={params.get("loopback", False)}')
        log.debug(f'Pipeline :\n{desc}')

        try:
            self.pipeline = Gst.parse_launch(desc)
        except GLib.Error as exc:
            msg = str(exc)
            log.error(f'[{self.peer_id}] Parse error: {msg}')
            hint = ''
            if 'no element' in msg:
                elem = msg.split('"')[1] if '"' in msg else '?'
                hint = f'\nÉlément GStreamer manquant : "{elem}" — lancez --diagnose'
            self._notify({'type': 'error', 'message': msg + hint})
            return

        self.webrtc = self.pipeline.get_by_name('webrtc')
        self._connect_signals()
        bus = self.pipeline.get_bus()
        bus.add_signal_watch()
        bus.connect('message', self._on_bus_message)

        ret = self.pipeline.set_state(Gst.State.PLAYING)
        if ret == Gst.StateChangeReturn.FAILURE:
            log.error(f'[{self.peer_id}] PLAYING failed')
            self._notify({'type': 'error', 'message': 'Pipeline PLAYING failed'})
        else:
            self._running = True

    def stop(self):
        if self.pipeline:
            log.info(f'[{self.peer_id}] Stop')
            self.pipeline.set_state(Gst.State.NULL)
            self.pipeline = None
        self.webrtc   = None
        self._running = False

    # ── Contrôles dynamiques ─────────────────────────────────────────────────

    def set_video_bitrate(self, bps: int) -> bool:
        enc = self._get_elem('vencoder')
        if not enc:
            return False
        try:
            prop = 'target-bitrate' if CAPS.get('venc') == 'vp8' else 'bitrate'
            enc.set_property(prop, bps if prop == 'target-bitrate' else bps // 1000)
            self.params['custom_vbr'] = bps
            log.info(f'[{self.peer_id}] video bitrate → {bps // 1000} kbps')
            return True
        except Exception as e:
            log.error(f'[{self.peer_id}] set_video_bitrate: {e}')
            return False

    def set_audio_bitrate(self, bps: int) -> bool:
        enc = self._get_elem('aencoder')
        if not enc:
            return False
        try:
            enc.set_property('bitrate', bps)
            self.params['custom_abr'] = bps
            log.info(f'[{self.peer_id}] audio bitrate → {bps // 1000} kbps')
            return True
        except Exception as e:
            log.error(f'[{self.peer_id}] set_audio_bitrate: {e}')
            return False

    def set_fps(self, fps: int) -> bool:
        vrater = self._get_elem('vrater')
        if vrater:
            try:
                vrater.set_property('max-rate', fps)
                self.params['custom_fps'] = fps
                log.info(f'[{self.peer_id}] fps → {fps}')
                return True
            except Exception as e:
                log.error(f'[{self.peer_id}] set_fps: {e}')
                return False
        # videorate ne supporte pas max-rate dynamique : redémarrage
        self.params['custom_fps'] = fps
        self.stop()
        asyncio.run_coroutine_threadsafe(self._restart_delayed(), self.loop)
        return True

    def set_audio_volume(self, vol: float) -> bool:
        v_elem = self._get_elem('avol')
        if v_elem:
            try:
                v_elem.set_property('volume', max(0.0, min(10.0, vol)))
                self.params['audio_volume'] = vol
                return True
            except Exception:
                pass
        self.params['audio_volume'] = vol
        self.stop()
        asyncio.run_coroutine_threadsafe(self._restart_delayed(), self.loop)
        return True

    # ── WebRTC signaling ─────────────────────────────────────────────────────

    def set_answer(self, sdp_text: str):
        _, sdpmsg = GstSdp.SDPMessage.new_from_text(sdp_text)
        answer = GstWebRTC.WebRTCSessionDescription.new(
            GstWebRTC.WebRTCSDPType.ANSWER, sdpmsg
        )
        promise = Gst.Promise.new()
        self.webrtc.emit('set-remote-description', answer, promise)
        promise.interrupt()

    def set_offer(self, sdp_text: str):
        """Gère une offre entrante (ex : micro client activé)."""
        _, sdpmsg = GstSdp.SDPMessage.new_from_text(sdp_text)
        offer = GstWebRTC.WebRTCSessionDescription.new(
            GstWebRTC.WebRTCSDPType.OFFER, sdpmsg
        )
        promise = Gst.Promise.new_with_change_func(self._on_remote_offer_set, self.webrtc)
        self.webrtc.emit('set-remote-description', offer, promise)

    def _on_remote_offer_set(self, promise, element):
        promise.wait()
        promise2 = Gst.Promise.new_with_change_func(self._on_answer_created, element)
        element.emit('create-answer', None, promise2)

    def _on_answer_created(self, promise, element):
        promise.wait()
        reply = promise.get_reply()
        if not reply or not reply.has_field('answer'):
            log.error(f'[{self.peer_id}] Answer creation failed')
            return
        answer = reply.get_value('answer')
        p3 = Gst.Promise.new()
        element.emit('set-local-description', answer, p3)
        p3.interrupt()
        self._notify({'type': 'answer', 'sdp': answer.sdp.as_text()})

    def add_ice(self, candidate: str, mline_index: int):
        if self.webrtc:
            self.webrtc.emit('add-ice-candidate', mline_index, candidate)

    # ── Signaux GStreamer ─────────────────────────────────────────────────────

    def _connect_signals(self):
        self.webrtc.connect('on-negotiation-needed', self._on_negotiation_needed)
        self.webrtc.connect('on-ice-candidate',      self._on_ice_candidate)
        self.webrtc.connect('notify::connection-state',     self._on_conn_state)
        self.webrtc.connect('notify::ice-connection-state', self._on_ice_state)
        self.webrtc.connect('pad-added',             self._on_pad_added)

    def _on_pad_added(self, element, pad):
        if pad.direction != Gst.PadDirection.SRC:
            return

        caps   = pad.get_current_caps() or pad.query_caps(None)
        struct = caps.get_structure(0) if caps and caps.get_size() > 0 else None
        mtype  = struct.get_name() if struct else 'unknown'

        # webrtcbin émet application/x-rtp — lire le champ "media"
        is_audio = mtype.startswith('audio')
        if not is_audio and mtype == 'application/x-rtp' and struct:
            is_audio = (struct.get_string('media') or '') == 'audio'

        if not is_audio:
            try:
                fs = Gst.ElementFactory.make('fakesink', None)
                self.pipeline.add(fs)
                fs.sync_state_with_parent()
                pad.link(fs.get_static_pad('sink'))
            except Exception as e:
                log.error(f'[{self.peer_id}] Fakesink error: {e}')
            return

        # Flux audio micro client → haut-parleurs
        log.info(f'[{self.peer_id}] Audio RTP reçu → haut-parleurs')
        try:
            q     = Gst.ElementFactory.make('queue',          None)
            depay = Gst.ElementFactory.make('rtpopusdepay',   None)
            dec   = Gst.ElementFactory.make('opusdec',        None)
            conv  = Gst.ElementFactory.make('audioconvert',   None)
            res   = Gst.ElementFactory.make('audioresample',  None)
            sink  = (Gst.ElementFactory.make('wasapi2sink',   None) or
                     Gst.ElementFactory.make('autoaudiosink', None))

            if not all([q, depay, dec, conv, res, sink]):
                log.error(f'[{self.peer_id}] Impossible de créer les éléments audio')
                return

            q.set_property('max-size-time', 200_000_000)
            q.set_property('leaky', 2)

            for e in [q, depay, dec, conv, res, sink]:
                self.pipeline.add(e)
            Gst.Element.link_many(q, depay, dec, conv, res, sink)
            for e in [q, depay, dec, conv, res, sink]:
                e.sync_state_with_parent()

            ret = pad.link(q.get_static_pad('sink'))
            if ret == Gst.PadLinkReturn.OK:
                log.info(f'[{self.peer_id}] Micro client connecté')
            else:
                log.error(f'[{self.peer_id}] Liaison pad audio échouée: {ret}')
        except Exception as e:
            log.error(f'[{self.peer_id}] Erreur liaison audio: {e}')
            traceback.print_exc()

    def _on_negotiation_needed(self, element):
        log.info(f'[{self.peer_id}] Négociation → offer')
        promise = Gst.Promise.new_with_change_func(self._on_offer_created, element)
        element.emit('create-offer', None, promise)

    def _on_offer_created(self, promise, element):
        promise.wait()
        reply = promise.get_reply()
        if not reply or not reply.has_field('offer'):
            log.error(f'[{self.peer_id}] Offer creation failed')
            self._notify({'type': 'error', 'message': 'GStreamer ne peut pas générer le flux.'})
            return
        offer = reply.get_value('offer')
        if not offer or not offer.sdp:
            return
        p2 = Gst.Promise.new()
        element.emit('set-local-description', offer, p2)
        p2.interrupt()
        self._notify({'type': 'offer', 'sdp': offer.sdp.as_text()})

    def _on_ice_candidate(self, element, mline_index, candidate):
        self._notify({'type': 'ice', 'candidate': candidate, 'sdpMLineIndex': mline_index})

    def _on_conn_state(self, element, _):
        state = element.get_property('connection-state')
        self._notify({'type': 'connection_state', 'state': getattr(state, 'value_nick', str(state))})

    def _on_ice_state(self, element, _):
        state = element.get_property('ice-connection-state')
        self._notify({'type': 'ice_state', 'state': getattr(state, 'value_nick', str(state))})

    def _on_bus_message(self, bus, message):
        t = message.type
        if t == Gst.MessageType.ERROR:
            err, dbg = message.parse_error()
            log.error(f'[{self.peer_id}] GST ERROR: {err} | {dbg}')
            self._notify({'type': 'error', 'message': str(err)})
        elif t == Gst.MessageType.WARNING:
            w, _ = message.parse_warning()
            log.warning(f'[{self.peer_id}] GST WARN: {w}')
        elif t == Gst.MessageType.EOS:
            self._notify({'type': 'eos'})
        elif t == Gst.MessageType.STATE_CHANGED:
            if message.src == self.pipeline:
                _, new, _ = message.parse_state_changed()
                self._notify({'type': 'pipeline_state', 'state': new.value_nick})

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _get_elem(self, name: str):
        if not self.pipeline:
            return None
        elem = self.pipeline.get_by_name(name)
        if not elem:
            log.warning(f'[{self.peer_id}] Élément {name!r} introuvable')
        return elem

    async def _restart_delayed(self):
        await asyncio.sleep(0.4)
        self.start(**self.params)

    def _notify(self, msg: dict):
        asyncio.run_coroutine_threadsafe(self._send(msg), self.loop)

    async def _send(self, msg: dict):
        try:
            if not self.ws.closed:
                await self.ws.send_json(msg)
        except Exception as exc:
            log.debug(f'[{self.peer_id}] Send error: {exc}')


# ─── Signaling WebSocket ──────────────────────────────────────────────────────

peers: dict[str, WebRTCPeer] = {}
_peer_counter = 0


def _extract_params(data: dict, defaults: dict = None) -> dict:
    """
    Priorité de résolution pour chaque paramètre (du plus fort au plus faible) :
      1. données du message WebSocket (choix explicite utilisateur)
      2. defaults  (paramètres courants du peer, ex : lors d'un 'switch')
      3. AUTO_PROFILE  (profil calculé au démarrage selon le matériel)
      4. valeur codée en dur  (fallback absolu)
    """
    d  = defaults or {}
    ap = AUTO_PROFILE   # profil matériel — jamais None

    def g(key, fallback=None):
        # data > defaults > AUTO_PROFILE > fallback
        if key in data:
            return data[key]
        if key in d:
            return d[key]
        if key in ap:
            return ap[key]
        return fallback

    return dict(
        mode            = g('mode',            'screen'),
        audio           = g('audio',           True),
        quality         = g('quality',         'medium'),
        video_device    = g('video_device'),
        audio_device    = g('audio_device'),
        pip_position    = g('pip_position',    'bottom-right'),
        pip_w           = int(g('pip_w',        320)),
        pip_h           = int(g('pip_h',        180)),
        custom_vbr      = g('custom_vbr'),
        custom_abr      = g('custom_abr'),
        custom_fps      = g('custom_fps'),
        custom_w        = g('custom_w'),
        custom_h        = g('custom_h'),
        encoder_preset  = g('encoder_preset',  'default'),
        gop_size        = int(g('gop_size',     15)),
        show_cursor     = bool(g('show_cursor', True)),
        window_title    = g('window_title',     ''),
        audio_channels  = int(g('audio_channels', 1)),
        audio_rate      = int(g('audio_rate',    48000)),
        opus_audio_type = g('opus_audio_type', 'voice'),
        opus_fec        = bool(g('opus_fec',    True)),
        opus_dtx        = bool(g('opus_dtx',    False)),
        audio_volume    = float(g('audio_volume', 1.0)),
        loopback        = bool(g('loopback',    False)),
        stun_server     = g('stun_server'),
        turn_server     = g('turn_server'),
        latency_ms      = int(g('latency_ms',   0)),
    )


async def handle_message(peer: WebRTCPeer, data: dict):
    t = data.get('type', '')

    if t == 'start':
        if peer._running:
            peer.stop()
            await asyncio.sleep(0.5)
        peer.start(**_extract_params(data))

    elif t == 'stop':
        peer.stop()
        await peer.ws.send_json({'type': 'stopped'})

    elif t == 'switch':
        peer.stop()
        await asyncio.sleep(0.5)
        peer.start(**_extract_params(data, peer.params))

    elif t == 'restart':
        peer.stop()
        await asyncio.sleep(0.4)
        peer.start(**peer.params)
        await peer.ws.send_json({'type': 'restarted'})

    elif t == 'get_window_list':
        await peer.ws.send_json({'type': 'window_list', 'windows': get_open_windows()})

    elif t == 'set_video_bitrate':
        bps = int(data.get('bitrate', 3_000_000))
        ok  = peer.set_video_bitrate(bps)
        await peer.ws.send_json({'type': 'param_ack', 'param': 'video_bitrate', 'value': bps, 'ok': ok})

    elif t == 'set_audio_bitrate':
        bps = int(data.get('bitrate', 96_000))
        ok  = peer.set_audio_bitrate(bps)
        await peer.ws.send_json({'type': 'param_ack', 'param': 'audio_bitrate', 'value': bps, 'ok': ok})

    elif t == 'set_fps':
        fps = int(data.get('fps', 30))
        ok  = peer.set_fps(fps)
        await peer.ws.send_json({'type': 'param_ack', 'param': 'fps', 'value': fps, 'ok': ok})

    elif t == 'set_audio_volume':
        vol = float(data.get('volume', 1.0))
        ok  = peer.set_audio_volume(vol)
        await peer.ws.send_json({'type': 'param_ack', 'param': 'audio_volume', 'value': vol, 'ok': ok})

    elif t == 'answer':
        if peer.webrtc:
            peer.set_answer(data['sdp'])

    elif t == 'offer':
        if peer.webrtc:
            peer.set_offer(data['sdp'])

    elif t == 'ice':
        peer.add_ice(data['candidate'], data.get('sdpMLineIndex', 0))

    elif t == 'ping':
        await peer.ws.send_json({'type': 'pong', 'ts': data.get('ts')})

    elif t == 'get_info':
        avail = []
        if CAPS.get('screen_src'):                         avail.append('screen')
        if CAPS.get('window_src'):                         avail.append('window')
        if CAPS.get('cam_src'):                            avail.append('webcam')
        if CAPS.get('screen_src') and CAPS.get('cam_src'): avail.append('both')
        if CAPS.get('audio_src'):                          avail.append('audio_only')

        # AUTO_PROFILE exposé sans la clé interne _reasons
        profile_public = {k: v for k, v in AUTO_PROFILE.items() if not k.startswith('_')}

        await peer.ws.send_json({
            'type':                 'info',
            'platform':             platform.system(),
            'platform_ver':         platform.release(),
            'gst_ver':              Gst.version_string(),
            'qualities':            list(QUALITY_PRESETS.keys()),
            'presets':              QUALITY_PRESETS,
            'modes':                avail,
            'screen_src':           CAPS.get('screen_src')  or 'unavailable',
            'window_src':           CAPS.get('window_src')  or 'unavailable',
            'cam_src':              CAPS.get('cam_src')     or 'unavailable',
            'cam_elem':             CAPS.get('cam_elem')    or 'unavailable',
            'audio_src':            CAPS.get('audio_src')   or 'unavailable',
            'audio_elem':           CAPS.get('audio_elem')  or 'unavailable',
            'venc':                 CAPS.get('venc'),
            'audio_devices':        list_audio_devices(),
            'has_d3d11':            has_elem('d3d11convert'),
            'stun_server':          STUN_SERVER,
            'turn_server':          TURN_SERVER or '',
            'auto_profile':          profile_public,
            'auto_profile_reasons':  AUTO_PROFILE.get('_reasons', {}),
            'hardware_warning':      AUTO_PROFILE.get('hardware_warning'),
        })

    elif t == 'get_current_params':
        await peer.ws.send_json({'type': 'current_params', 'params': peer.params})

    else:
        log.debug(f'[{peer.peer_id}] Message inconnu : {t!r}')


async def ws_handler(request: web.Request) -> web.WebSocketResponse:
    global _peer_counter
    ws = web.WebSocketResponse(heartbeat=20, max_msg_size=0)
    await ws.prepare(request)
    _peer_counter += 1
    peer_id = f'peer-{_peer_counter:04d}'
    loop    = asyncio.get_event_loop()
    peer    = WebRTCPeer(ws, peer_id, loop)
    peers[peer_id] = peer
    log.info(f'[{peer_id}] Connexion {request.remote}')
    await ws.send_json({'type': 'hello', 'peer_id': peer_id})
    try:
        async for msg in ws:
            if msg.type == aiohttp.WSMsgType.TEXT:
                try:
                    await handle_message(peer, json.loads(msg.data))
                except json.JSONDecodeError:
                    log.warning(f'[{peer_id}] JSON invalide')
                except Exception as exc:
                    log.error(f'[{peer_id}] {exc}\n{traceback.format_exc()}')
            elif msg.type in (aiohttp.WSMsgType.ERROR, aiohttp.WSMsgType.CLOSE):
                break
    finally:
        log.info(f'[{peer_id}] Déconnexion')
        peer.stop()
        peers.pop(peer_id, None)
    return ws


# ─── Handlers HTTP ────────────────────────────────────────────────────────────

async def index_handler(request):
    return web.Response(text=html_page, content_type='text/html')

async def favicon_handler(request):
    ico = (b'\x00\x00\x01\x00\x01\x00\x01\x01\x00\x00\x01\x00\x18\x00'
           b'\x28\x00\x00\x00\x10\x00\x00\x00\x01\x00\x18\x00\x00\x00'
           b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
           b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\xff'
           b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    return web.Response(body=ico, content_type='image/x-icon')

async def status_handler(request):
    return web.json_response({
        'peers':      len(peers),
        'peer_ids':   list(peers.keys()),
        'platform':   platform.system(),
        'gst':        Gst.version_string(),
        'screen_src': CAPS.get('screen_src') or 'unavailable',
        'window_src': CAPS.get('window_src') or 'unavailable',
        'cam_src':    CAPS.get('cam_src')    or 'unavailable',
        'audio_src':  CAPS.get('audio_src')  or 'unavailable',
        'venc':       CAPS.get('venc'),
        'stun':       STUN_SERVER,
        'turn':       TURN_SERVER or None,
    })

async def diagnose_handler(request):
    elems = [
        'd3d11screencapturesrc', 'd3d12screencapturesrc', 'gdiscreencapsrc',
        'mfvideosrc', 'ksvideosrc',
        'wasapi2src', 'wasapisrc',
        'nvh264enc', 'mfh264enc',
        'webrtcbin', 'opusenc', 'rtph264pay', 'rtpopuspay',
        'videoconvert', 'videoscale', 'videorate', 'audioconvert', 'audioresample',
        'compositor', 'd3d11download', 'd3d11convert', 'volume', 'videocrop',
        'wasapi2sink', 'autoaudiosink',
    ]
    return web.json_response({
        'platform':     platform.system(),
        'gst_ver':      Gst.version_string(),
        'detected':     CAPS,
        'elements':     {e: has_elem(e) for e in elems},
        'presets':      QUALITY_PRESETS,
        'stun':         STUN_SERVER,
        'turn':         TURN_SERVER or None,
        'audio_devices': list_audio_devices(),
    })


def create_app() -> web.Application:
    app = web.Application(client_max_size=0)
    app.router.add_get('/',            index_handler)
    app.router.add_get('/ws',          ws_handler)
    app.router.add_get('/status',      status_handler)
    app.router.add_get('/diagnose',    diagnose_handler)
    app.router.add_get('/favicon.ico', favicon_handler)
    return app


# ─── Entrypoint ───────────────────────────────────────────────────────────────

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(
        description='StreamForge — WebRTC streaming server (Windows 10/11)',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument('--host',         default=HOST)
    parser.add_argument('--port',         default=PORT,         type=int)
    parser.add_argument('--device',       default=VIDEO_DEVICE, help='Index caméra')
    parser.add_argument('--audio-device', default=AUDIO_DEVICE, help='ID device WASAPI')
    parser.add_argument('--stun',         default=STUN_SERVER,  help='URI serveur STUN')
    parser.add_argument('--turn',         default=TURN_SERVER,  help='URI serveur TURN')
    parser.add_argument('--debug',        action='store_true')
    args = parser.parse_args()

    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)

    VIDEO_DEVICE = args.device
    AUDIO_DEVICE = args.audio_device
    STUN_SERVER  = args.stun
    TURN_SERVER  = args.turn
    CAPS.update(probe_caps(args.device, args.audio_device))

    scr = (CAPS['screen_src'] or 'UNAVAILABLE')[:38]
    win = (CAPS['window_src'] or 'UNAVAILABLE')[:38]
    cam = (CAPS['cam_src']    or 'UNAVAILABLE')[:38]
    aud = (CAPS['audio_src']  or 'UNAVAILABLE')[:38]

    print(f"""
  ╔════════════════════════════════════════════════════╗
  ║   StreamForge  ·  Ultra-low-latency  ·  WebRTC    ║
  ╠════════════════════════════════════════════════════╣
  ║  URL        →  http://localhost:{args.port:<19}  ║
  ║  Platform   →  {platform.system()} {platform.release():<32}  ║
  ║  GStreamer  →  {Gst.version_string():<36}  ║
  ║  Screen     →  {scr:<36}  ║
  ║  Window     →  {win:<36}  ║
  ║  Webcam     →  {cam:<36}  ║
  ║  Audio      →  {aud:<36}  ║
  ║  Encoder    →  {CAPS['venc']:<36}  ║
  ╠════════════════════════════════════════════════════╣
  ║  Diagnose   →  http://localhost:{args.port}/diagnose         ║
  ╚════════════════════════════════════════════════════╝
""")

    web.run_app(create_app(), host=args.host, port=args.port, access_log=None)